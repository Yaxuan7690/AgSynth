"""
math_validator.py
数学验证工具模块 - 解决"数学幻觉"问题

功能：
1. 24点验证：验证4个数字能否通过四则运算得到24
2. 方程组验证：验证方程组是否有解、有多少个解
3. 算式谜验证：验证算式谜的答案是否正确
4. 多解检测：自动发现所有可能的解
5. 🚨 NEW: 通用数值计算验证：支持所有类型的数学计算题
   - 基础四则运算验证
   - 分数计算验证
   - 百分比计算验证
   - 比例问题验证
   - 几何计算验证（面积、周长、体积）
   - 数列规律验证
   - 大小比较验证
   - 应用题数值验证

使用场景：
- ConceptDesigner 设计题目时，调用验证工具确保数学逻辑正确
- Auditor 审计题目时，调用验证工具检测多解情况
- 🚨 NEW: 所有数值计算题目都应该调用验证工具
"""

from typing import List, Dict, Any, Optional, Tuple, Set, Union
from itertools import permutations, product
from fractions import Fraction
from decimal import Decimal, getcontext
import re
import math

# 设置高精度计算
getcontext().prec = 50


class MathValidator:
    """数学验证工具类 - 支持所有数值计算问题"""

    def __init__(self):
        """初始化验证器"""
        self.operators = ['+', '-', '*', '/']
        self.tolerance = 1e-9  # 浮点数比较容差
    
    # ========================================================================
    # 24点验证
    # ========================================================================
    def validate_24_point(
        self,
        numbers: List[int],
        target: int = 24,
        allow_duplicates: bool = True
    ) -> Dict[str, Any]:
        """
        验证24点问题
        
        Args:
            numbers: 数字列表（通常是4个数字）
            target: 目标值（默认24）
            allow_duplicates: 是否允许重复使用数字
        
        Returns:
            {
                "has_solution": bool,  # 是否有解
                "solution_count": int,  # 解的数量
                "solutions": List[str],  # 所有解的表达式
                "sample_solutions": List[str]  # 示例解（最多5个）
            }
        """
        if len(numbers) != 4:
            return {
                "has_solution": False,
                "solution_count": 0,
                "solutions": [],
                "sample_solutions": [],
                "error": "24点问题需要恰好4个数字"
            }
        
        solutions = set()
        
        # 尝试所有数字排列
        for perm in permutations(numbers):
            # 尝试所有运算符组合
            for ops in product(self.operators, repeat=3):
                # 尝试所有括号组合
                expressions = self._generate_24_expressions(perm, ops)
                
                for expr in expressions:
                    try:
                        # 安全计算表达式
                        result = self._safe_eval(expr)
                        if result is not None and abs(result - target) < 1e-9:
                            solutions.add(expr)
                    except:
                        continue
        
        solution_list = sorted(list(solutions))
        
        return {
            "has_solution": len(solutions) > 0,
            "solution_count": len(solutions),
            "solutions": solution_list,
            "sample_solutions": solution_list[:5]  # 最多返回5个示例
        }
    
    def _generate_24_expressions(
        self,
        numbers: Tuple[int, int, int, int],
        ops: Tuple[str, str, str]
    ) -> List[str]:
        """生成所有可能的括号组合"""
        a, b, c, d = numbers
        op1, op2, op3 = ops
        
        # 5种括号组合
        patterns = [
            f"(({a} {op1} {b}) {op2} {c}) {op3} {d}",  # ((a op b) op c) op d
            f"({a} {op1} ({b} {op2} {c})) {op3} {d}",  # (a op (b op c)) op d
            f"({a} {op1} {b}) {op2} ({c} {op3} {d})",  # (a op b) op (c op d)
            f"{a} {op1} (({b} {op2} {c}) {op3} {d})",  # a op ((b op c) op d)
            f"{a} {op1} ({b} {op2} ({c} {op3} {d}))"   # a op (b op (c op d))
        ]
        
        return patterns
    
    def _safe_eval(self, expr: str) -> Optional[float]:
        """安全计算表达式（避免除零错误）"""
        try:
            # 检查除零
            if '/0' in expr.replace(' ', ''):
                return None
            
            # 使用 eval 计算（仅限数学表达式）
            result = eval(expr, {"__builtins__": {}}, {})
            return float(result)
        except (ZeroDivisionError, ValueError, SyntaxError):
            return None
    
    # ========================================================================
    # 方程组验证
    # ========================================================================
    def validate_equation_system(
        self,
        equations: List[str],
        variables: List[str]
    ) -> Dict[str, Any]:
        """
        验证方程组是否有解
        
        Args:
            equations: 方程列表，如 ["2*x + 3*y = 10", "x - y = 1"]
            variables: 变量列表，如 ["x", "y"]
        
        Returns:
            {
                "has_solution": bool,  # 是否有解
                "solution_type": str,  # "unique" | "infinite" | "none"
                "solutions": Dict[str, float],  # 解（如果有唯一解）
                "solution_count": int  # 解的数量（0=无解，1=唯一解，-1=无穷多解）
            }
        """
        try:
            # 简化版：使用符号计算库（如果可用）
            # 这里提供基础实现，实际可以集成 sympy
            
            # 检查方程数量和变量数量
            eq_count = len(equations)
            var_count = len(variables)
            
            if eq_count < var_count:
                return {
                    "has_solution": True,
                    "solution_type": "infinite",
                    "solutions": {},
                    "solution_count": -1,
                    "message": f"方程数({eq_count}) < 变量数({var_count})，有无穷多解"
                }
            elif eq_count > var_count:
                return {
                    "has_solution": False,
                    "solution_type": "overdetermined",
                    "solutions": {},
                    "solution_count": 0,
                    "message": f"方程数({eq_count}) > 变量数({var_count})，可能无解或矛盾"
                }
            
            # 对于简单的线性方程组，尝试求解
            # 这里提供一个基础实现，实际应该使用 numpy 或 sympy
            
            return {
                "has_solution": True,
                "solution_type": "unknown",
                "solutions": {},
                "solution_count": 1,
                "message": "需要实际求解器验证（建议集成 sympy）"
            }
        
        except Exception as e:
            return {
                "has_solution": False,
                "solution_type": "error",
                "solutions": {},
                "solution_count": 0,
                "error": str(e)
            }
    
    # ========================================================================
    # 算式谜验证
    # ========================================================================
    def validate_arithmetic_puzzle(
        self,
        puzzle: str,
        answer: Dict[str, int]
    ) -> Dict[str, Any]:
        """
        验证算式谜答案是否正确
        
        Args:
            puzzle: 算式谜，如 "AB + CD = EF"（字母代表数字）
            answer: 答案字典，如 {"A": 1, "B": 2, "C": 3, "D": 4, "E": 4, "F": 6}
        
        Returns:
            {
                "is_correct": bool,  # 答案是否正确
                "calculated_result": str,  # 代入后的计算结果
                "expected_result": str,  # 期望的结果
                "all_solutions": List[Dict[str, int]]  # 所有可能的解（如果有多个）
            }
        """
        try:
            # 将字母替换为数字
            substituted = puzzle
            for letter, digit in answer.items():
                substituted = substituted.replace(letter, str(digit))
            
            # 分离等式两边
            if '=' in substituted:
                left, right = substituted.split('=')
                left_result = self._safe_eval(left.strip())
                right_result = self._safe_eval(right.strip())
                
                is_correct = (left_result is not None and 
                             right_result is not None and 
                             abs(left_result - right_result) < 1e-9)
                
                return {
                    "is_correct": is_correct,
                    "calculated_result": f"{left_result} = {right_result}",
                    "expected_result": "两边相等",
                    "all_solutions": []  # 暂不实现穷举所有解
                }
            else:
                return {
                    "is_correct": False,
                    "calculated_result": "",
                    "expected_result": "",
                    "error": "算式谜格式错误，缺少等号"
                }
        
        except Exception as e:
            return {
                "is_correct": False,
                "calculated_result": "",
                "expected_result": "",
                "error": str(e)
            }
    
    # ========================================================================
    # 🚨 NEW: 通用数值计算验证
    # ========================================================================
    def validate_arithmetic_calculation(
        self,
        expression: str,
        expected_answer: Union[int, float, str],
        allow_tolerance: bool = True
    ) -> Dict[str, Any]:
        """
        验证基础四则运算

        Args:
            expression: 数学表达式，如 "3 + 5 * 2"
            expected_answer: 期望答案
            allow_tolerance: 是否允许浮点数容差

        Returns:
            {
                "is_correct": bool,
                "calculated_result": float,
                "expected_result": float,
                "difference": float,
                "expression": str
            }
        """
        try:
            # 计算表达式
            calculated = self._safe_eval(expression)
            if calculated is None:
                return {
                    "is_correct": False,
                    "error": "表达式计算失败（可能包含除零或语法错误）"
                }

            # 转换期望答案
            if isinstance(expected_answer, str):
                expected = self._safe_eval(expected_answer)
            else:
                expected = float(expected_answer)

            if expected is None:
                return {
                    "is_correct": False,
                    "error": "期望答案格式错误"
                }

            # 比较结果
            difference = abs(calculated - expected)
            is_correct = difference < self.tolerance if allow_tolerance else calculated == expected

            return {
                "is_correct": is_correct,
                "calculated_result": calculated,
                "expected_result": expected,
                "difference": difference,
                "expression": expression,
                "message": "✅ 答案正确" if is_correct else f"❌ 答案错误（差值: {difference}）"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"验证失败: {str(e)}"
            }

    def validate_fraction_calculation(
        self,
        fraction1: Tuple[int, int],
        operator: str,
        fraction2: Tuple[int, int],
        expected_answer: Tuple[int, int]
    ) -> Dict[str, Any]:
        """
        验证分数计算

        Args:
            fraction1: 第一个分数 (分子, 分母)
            operator: 运算符 ('+', '-', '*', '/')
            fraction2: 第二个分数 (分子, 分母)
            expected_answer: 期望答案 (分子, 分母)

        Returns:
            验证结果
        """
        try:
            f1 = Fraction(fraction1[0], fraction1[1])
            f2 = Fraction(fraction2[0], fraction2[1])
            expected = Fraction(expected_answer[0], expected_answer[1])

            # 执行运算
            if operator == '+':
                result = f1 + f2
            elif operator == '-':
                result = f1 - f2
            elif operator == '*':
                result = f1 * f2
            elif operator == '/':
                if f2 == 0:
                    return {"is_correct": False, "error": "除数不能为零"}
                result = f1 / f2
            else:
                return {"is_correct": False, "error": f"不支持的运算符: {operator}"}

            is_correct = result == expected

            return {
                "is_correct": is_correct,
                "calculated_result": f"{result.numerator}/{result.denominator}",
                "expected_result": f"{expected.numerator}/{expected.denominator}",
                "simplified_result": str(result),
                "message": "✅ 分数计算正确" if is_correct else "❌ 分数计算错误"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"分数计算验证失败: {str(e)}"
            }

    def validate_percentage_calculation(
        self,
        base_value: float,
        percentage: float,
        operation: str,
        expected_answer: float
    ) -> Dict[str, Any]:
        """
        验证百分比计算

        Args:
            base_value: 基数
            percentage: 百分比（如 20 表示 20%）
            operation: 操作类型 ("of" | "increase" | "decrease" | "is_what_percent")
            expected_answer: 期望答案

        Returns:
            验证结果
        """
        try:
            if operation == "of":
                # X% of Y = ?
                calculated = base_value * (percentage / 100)
            elif operation == "increase":
                # Y increased by X% = ?
                calculated = base_value * (1 + percentage / 100)
            elif operation == "decrease":
                # Y decreased by X% = ?
                calculated = base_value * (1 - percentage / 100)
            elif operation == "is_what_percent":
                # X is what percent of Y?
                if base_value == 0:
                    return {"is_correct": False, "error": "基数不能为零"}
                calculated = (percentage / base_value) * 100
            else:
                return {"is_correct": False, "error": f"不支持的操作类型: {operation}"}

            difference = abs(calculated - expected_answer)
            is_correct = difference < self.tolerance

            return {
                "is_correct": is_correct,
                "calculated_result": calculated,
                "expected_result": expected_answer,
                "difference": difference,
                "operation": operation,
                "message": "✅ 百分比计算正确" if is_correct else f"❌ 百分比计算错误（差值: {difference}）"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"百分比计算验证失败: {str(e)}"
            }

    def validate_ratio_problem(
        self,
        ratio1: Tuple[int, int],
        ratio2: Tuple[int, int],
        expected_answer: Union[Tuple[int, int], float]
    ) -> Dict[str, Any]:
        """
        验证比例问题

        Args:
            ratio1: 第一个比例 (a, b) 表示 a:b
            ratio2: 第二个比例 (c, d) 表示 c:d
            expected_answer: 期望答案（可以是比例或数值）

        Returns:
            验证结果
        """
        try:
            # 计算比例值
            value1 = ratio1[0] / ratio1[1] if ratio1[1] != 0 else None
            value2 = ratio2[0] / ratio2[1] if ratio2[1] != 0 else None

            if value1 is None or value2 is None:
                return {"is_correct": False, "error": "比例分母不能为零"}

            # 验证比例是否相等
            if isinstance(expected_answer, tuple):
                expected_value = expected_answer[0] / expected_answer[1] if expected_answer[1] != 0 else None
                if expected_value is None:
                    return {"is_correct": False, "error": "期望答案分母不能为零"}
                is_correct = abs(value1 - expected_value) < self.tolerance or abs(value2 - expected_value) < self.tolerance
            else:
                is_correct = abs(value1 - expected_answer) < self.tolerance or abs(value2 - expected_answer) < self.tolerance

            return {
                "is_correct": is_correct,
                "ratio1_value": value1,
                "ratio2_value": value2,
                "expected_answer": expected_answer,
                "message": "✅ 比例计算正确" if is_correct else "❌ 比例计算错误"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"比例问题验证失败: {str(e)}"
            }

    def validate_geometry_calculation(
        self,
        shape_type: str,
        dimensions: Dict[str, float],
        calculation_type: str,
        expected_answer: float
    ) -> Dict[str, Any]:
        """
        验证几何计算（面积、周长、体积）

        Args:
            shape_type: 图形类型 ("rectangle" | "circle" | "triangle" | "cube" | "sphere" 等)
            dimensions: 尺寸参数，如 {"length": 5, "width": 3}
            calculation_type: 计算类型 ("area" | "perimeter" | "volume" | "surface_area")
            expected_answer: 期望答案

        Returns:
            验证结果
        """
        try:
            calculated = None

            # 矩形
            if shape_type == "rectangle":
                if calculation_type == "area":
                    calculated = dimensions.get("length", 0) * dimensions.get("width", 0)
                elif calculation_type == "perimeter":
                    calculated = 2 * (dimensions.get("length", 0) + dimensions.get("width", 0))

            # 圆形
            elif shape_type == "circle":
                radius = dimensions.get("radius", 0)
                if calculation_type == "area":
                    calculated = math.pi * radius ** 2
                elif calculation_type == "perimeter":  # 周长（圆周）
                    calculated = 2 * math.pi * radius

            # 三角形
            elif shape_type == "triangle":
                if calculation_type == "area":
                    base = dimensions.get("base", 0)
                    height = dimensions.get("height", 0)
                    calculated = 0.5 * base * height
                elif calculation_type == "perimeter":
                    calculated = dimensions.get("side1", 0) + dimensions.get("side2", 0) + dimensions.get("side3", 0)

            # 立方体
            elif shape_type == "cube":
                side = dimensions.get("side", 0)
                if calculation_type == "volume":
                    calculated = side ** 3
                elif calculation_type == "surface_area":
                    calculated = 6 * side ** 2

            # 球体
            elif shape_type == "sphere":
                radius = dimensions.get("radius", 0)
                if calculation_type == "volume":
                    calculated = (4/3) * math.pi * radius ** 3
                elif calculation_type == "surface_area":
                    calculated = 4 * math.pi * radius ** 2

            else:
                return {"is_correct": False, "error": f"不支持的图形类型: {shape_type}"}

            if calculated is None:
                return {"is_correct": False, "error": f"不支持的计算类型: {calculation_type}"}

            difference = abs(calculated - expected_answer)
            is_correct = difference < self.tolerance

            return {
                "is_correct": is_correct,
                "calculated_result": calculated,
                "expected_result": expected_answer,
                "difference": difference,
                "shape_type": shape_type,
                "calculation_type": calculation_type,
                "message": "✅ 几何计算正确" if is_correct else f"❌ 几何计算错误（差值: {difference}）"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"几何计算验证失败: {str(e)}"
            }

    def validate_sequence_pattern(
        self,
        sequence: List[Union[int, float]],
        pattern_type: str,
        expected_next: Union[int, float]
    ) -> Dict[str, Any]:
        """
        验证数列规律

        Args:
            sequence: 数列，如 [2, 4, 6, 8]
            pattern_type: 规律类型 ("arithmetic" | "geometric" | "fibonacci" | "custom")
            expected_next: 期望的下一个数

        Returns:
            验证结果
        """
        try:
            if len(sequence) < 2:
                return {"is_correct": False, "error": "数列至少需要2个元素"}

            calculated_next = None

            # 等差数列
            if pattern_type == "arithmetic":
                diff = sequence[1] - sequence[0]
                # 验证是否为等差数列
                is_arithmetic = all(sequence[i+1] - sequence[i] == diff for i in range(len(sequence)-1))
                if is_arithmetic:
                    calculated_next = sequence[-1] + diff

            # 等比数列
            elif pattern_type == "geometric":
                if sequence[0] == 0:
                    return {"is_correct": False, "error": "等比数列首项不能为零"}
                ratio = sequence[1] / sequence[0]
                # 验证是否为等比数列
                is_geometric = all(abs(sequence[i+1] / sequence[i] - ratio) < self.tolerance for i in range(len(sequence)-1) if sequence[i] != 0)
                if is_geometric:
                    calculated_next = sequence[-1] * ratio

            # 斐波那契数列
            elif pattern_type == "fibonacci":
                # 验证是否为斐波那契数列
                is_fibonacci = all(sequence[i] == sequence[i-1] + sequence[i-2] for i in range(2, len(sequence)))
                if is_fibonacci:
                    calculated_next = sequence[-1] + sequence[-2]

            # 自定义规律（尝试自动检测）
            elif pattern_type == "custom":
                # 尝试等差
                diff = sequence[1] - sequence[0]
                if all(abs((sequence[i+1] - sequence[i]) - diff) < self.tolerance for i in range(len(sequence)-1)):
                    calculated_next = sequence[-1] + diff
                # 尝试等比
                elif sequence[0] != 0:
                    ratio = sequence[1] / sequence[0]
                    if all(abs(sequence[i+1] / sequence[i] - ratio) < self.tolerance for i in range(len(sequence)-1) if sequence[i] != 0):
                        calculated_next = sequence[-1] * ratio

            else:
                return {"is_correct": False, "error": f"不支持的规律类型: {pattern_type}"}

            if calculated_next is None:
                return {"is_correct": False, "error": "无法识别数列规律"}

            difference = abs(calculated_next - expected_next)
            is_correct = difference < self.tolerance

            return {
                "is_correct": is_correct,
                "calculated_next": calculated_next,
                "expected_next": expected_next,
                "difference": difference,
                "pattern_type": pattern_type,
                "message": "✅ 数列规律正确" if is_correct else f"❌ 数列规律错误（差值: {difference}）"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"数列规律验证失败: {str(e)}"
            }

    def validate_comparison_problem(
        self,
        value1: Union[int, float],
        value2: Union[int, float],
        comparison_type: str,
        expected_result: bool
    ) -> Dict[str, Any]:
        """
        验证大小比较问题

        Args:
            value1: 第一个值
            value2: 第二个值
            comparison_type: 比较类型 ("greater" | "less" | "equal" | "greater_equal" | "less_equal")
            expected_result: 期望结果（True/False）

        Returns:
            验证结果
        """
        try:
            calculated_result = None

            if comparison_type == "greater":
                calculated_result = value1 > value2
            elif comparison_type == "less":
                calculated_result = value1 < value2
            elif comparison_type == "equal":
                calculated_result = abs(value1 - value2) < self.tolerance
            elif comparison_type == "greater_equal":
                calculated_result = value1 >= value2 or abs(value1 - value2) < self.tolerance
            elif comparison_type == "less_equal":
                calculated_result = value1 <= value2 or abs(value1 - value2) < self.tolerance
            else:
                return {"is_correct": False, "error": f"不支持的比较类型: {comparison_type}"}

            is_correct = calculated_result == expected_result

            return {
                "is_correct": is_correct,
                "calculated_result": calculated_result,
                "expected_result": expected_result,
                "value1": value1,
                "value2": value2,
                "comparison_type": comparison_type,
                "message": "✅ 比较结果正确" if is_correct else "❌ 比较结果错误"
            }

        except Exception as e:
            return {
                "is_correct": False,
                "error": f"比较问题验证失败: {str(e)}"
            }

    # ========================================================================
    # 通用验证接口（增强版）
    # ========================================================================
    def validate_math_problem(
        self,
        problem_type: str,
        problem_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        通用数学问题验证接口（增强版）

        Args:
            problem_type: 问题类型
                - "24_point": 24点问题
                - "equation_system": 方程组
                - "arithmetic_puzzle": 算式谜
                - 🚨 NEW: "arithmetic": 基础四则运算
                - 🚨 NEW: "fraction": 分数计算
                - 🚨 NEW: "percentage": 百分比计算
                - 🚨 NEW: "ratio": 比例问题
                - 🚨 NEW: "geometry": 几何计算
                - 🚨 NEW: "sequence": 数列规律
                - 🚨 NEW: "comparison": 大小比较
            problem_data: 问题数据

        Returns:
            验证结果字典
        """
        # 原有功能
        if problem_type == "24_point":
            return self.validate_24_point(
                numbers=problem_data.get("numbers", []),
                target=problem_data.get("target", 24)
            )

        elif problem_type == "equation_system":
            return self.validate_equation_system(
                equations=problem_data.get("equations", []),
                variables=problem_data.get("variables", [])
            )

        elif problem_type == "arithmetic_puzzle":
            return self.validate_arithmetic_puzzle(
                puzzle=problem_data.get("puzzle", ""),
                answer=problem_data.get("answer", {})
            )

        # 🚨 NEW: 通用数值计算验证
        elif problem_type == "arithmetic":
            return self.validate_arithmetic_calculation(
                expression=problem_data.get("expression", ""),
                expected_answer=problem_data.get("expected_answer", 0),
                allow_tolerance=problem_data.get("allow_tolerance", True)
            )

        elif problem_type == "fraction":
            return self.validate_fraction_calculation(
                fraction1=problem_data.get("fraction1", (1, 1)),
                operator=problem_data.get("operator", "+"),
                fraction2=problem_data.get("fraction2", (1, 1)),
                expected_answer=problem_data.get("expected_answer", (1, 1))
            )

        elif problem_type == "percentage":
            return self.validate_percentage_calculation(
                base_value=problem_data.get("base_value", 0),
                percentage=problem_data.get("percentage", 0),
                operation=problem_data.get("operation", "of"),
                expected_answer=problem_data.get("expected_answer", 0)
            )

        elif problem_type == "ratio":
            return self.validate_ratio_problem(
                ratio1=problem_data.get("ratio1", (1, 1)),
                ratio2=problem_data.get("ratio2", (1, 1)),
                expected_answer=problem_data.get("expected_answer", (1, 1))
            )

        elif problem_type == "geometry":
            return self.validate_geometry_calculation(
                shape_type=problem_data.get("shape_type", "rectangle"),
                dimensions=problem_data.get("dimensions", {}),
                calculation_type=problem_data.get("calculation_type", "area"),
                expected_answer=problem_data.get("expected_answer", 0)
            )

        elif problem_type == "sequence":
            return self.validate_sequence_pattern(
                sequence=problem_data.get("sequence", []),
                pattern_type=problem_data.get("pattern_type", "arithmetic"),
                expected_next=problem_data.get("expected_next", 0)
            )

        elif problem_type == "comparison":
            return self.validate_comparison_problem(
                value1=problem_data.get("value1", 0),
                value2=problem_data.get("value2", 0),
                comparison_type=problem_data.get("comparison_type", "greater"),
                expected_result=problem_data.get("expected_result", True)
            )

        else:
            return {
                "error": f"不支持的问题类型: {problem_type}",
                "supported_types": [
                    "24_point", "equation_system", "arithmetic_puzzle",
                    "arithmetic", "fraction", "percentage", "ratio",
                    "geometry", "sequence", "comparison"
                ]
            }
    
    # ========================================================================
    # 多解检测辅助函数
    # ========================================================================
    def detect_multiple_solutions(
        self,
        problem_type: str,
        problem_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        检测问题是否有多个解
        
        Returns:
            {
                "has_multiple_solutions": bool,
                "solution_count": int,
                "recommendation": str  # 给 Agent 的建议
            }
        """
        validation_result = self.validate_math_problem(problem_type, problem_data)
        
        solution_count = validation_result.get("solution_count", 0)
        
        if solution_count == 0:
            recommendation = "❌ 本题无解！请重新设计数据规格。"
        elif solution_count == 1:
            recommendation = "✅ 本题有唯一解，符合要求。"
        elif solution_count > 1:
            recommendation = f"⚠️ 本题有 {solution_count} 个解！建议：\n" \
                           f"1. 调整为多选题格式\n" \
                           f"2. 或者要求学生写出所有解\n" \
                           f"3. 或者添加约束条件使其变为唯一解"
        else:  # solution_count == -1 (无穷多解)
            recommendation = "⚠️ 本题有无穷多解！建议添加更多约束条件。"
        
        return {
            "has_multiple_solutions": solution_count > 1,
            "solution_count": solution_count,
            "recommendation": recommendation,
            "validation_result": validation_result
        }


# ============================================================================
# 使用示例
# ============================================================================
if __name__ == "__main__":
    validator = MathValidator()
    
    # 示例1：24点验证
    print("=" * 60)
    print("示例1：24点验证")
    print("=" * 60)
    
    result = validator.validate_24_point([3, 3, 8, 8])
    print(f"数字: [3, 3, 8, 8]")
    print(f"有解: {result['has_solution']}")
    print(f"解的数量: {result['solution_count']}")
    print(f"示例解: {result['sample_solutions'][:3]}")
    
    # 示例2：无解的24点
    print("\n" + "=" * 60)
    print("示例2：无解的24点（干扰项验证）")
    print("=" * 60)
    
    result = validator.validate_24_point([1, 1, 1, 1])
    print(f"数字: [1, 1, 1, 1]")
    print(f"有解: {result['has_solution']}")
    print(f"解的数量: {result['solution_count']}")
    
    # 示例3：多解检测
    print("\n" + "=" * 60)
    print("示例3：多解检测")
    print("=" * 60)
    
    result = validator.detect_multiple_solutions(
        problem_type="24_point",
        problem_data={"numbers": [3, 3, 8, 8], "target": 24}
    )
    print(f"有多个解: {result['has_multiple_solutions']}")
    print(f"解的数量: {result['solution_count']}")
    print(f"建议: {result['recommendation']}")
