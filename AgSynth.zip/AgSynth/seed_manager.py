"""
seed_manager.py
种子题新鲜度管理模块

功能：
1. 追踪每个种子题的失败次数
2. 自动标记"Hard Seed"（连续失败 3 次）
3. 支持暂时移出池子或切换高级模型
4. 持久化存储种子题状态
5. 线程安全的状态管理（支持并发场景）
"""
import json
import os
import threading
from typing import Dict, Any, List, Optional
from datetime import datetime


class SeedManager:
    """
    种子题新鲜度管理器
    
    职责：
    1. 记录种子题的成功/失败历史
    2. 识别"Hard Seed"（连续失败 3 次）
    3. 提供种子题过滤和模型升级策略
    """
    
    def __init__(self, state_file: str = "seed_state.json", target_count_per_seed: int = 3):
        """
        初始化种子题管理器

        Args:
            state_file: 种子题状态文件路径
            target_count_per_seed: 每个种子题的目标生成数量（默认3道）
        """
        self.state_file = state_file
        self.target_count_per_seed = target_count_per_seed
        self._lock = threading.Lock()  # 线程锁，确保并发安全
        self.seed_states = self._load_state()
    
    def _load_state(self) -> Dict[str, Any]:
        """加载种子题状态"""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"⚠️ Failed to load seed state: {e}")
                return {}
        return {}
    
    def _save_state(self) -> None:
        """保存种子题状态（线程安全 + 原子写入）"""
        with self._lock:  # 使用锁保护，确保并发安全
            try:
                # 深拷贝字典，避免在序列化过程中字典被修改
                import copy
                state_snapshot = copy.deepcopy(self.seed_states)

                # 使用原子写入：先写临时文件，再替换
                tmp_path = self.state_file + ".tmp"
                with open(tmp_path, 'w', encoding='utf-8') as f:
                    json.dump(state_snapshot, f, indent=2, ensure_ascii=False)

                # 原子替换（跨平台兼容）
                os.replace(tmp_path, self.state_file)
            except Exception as e:
                print(f"⚠️ Failed to save seed state: {e}")
                # 清理临时文件
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except:
                        pass
    
    def get_seed_id(self, seed_question: dict) -> str:
        """
        提取种子题的唯一标识符（支持多种字段名格式）

        Args:
            seed_question: 种子题目字典

        Returns:
            种子题 ID（优先使用 name/Name 字段）
        """
        # 优先使用 name/Name 字段（支持大小写）
        seed_id = (seed_question.get("name") or seed_question.get("Name") or
                   seed_question.get("id") or seed_question.get("ID") or
                   seed_question.get("image_path") or seed_question.get("image", "unknown"))
        return str(seed_id)
    
    def record_success(self, seed_question: dict) -> None:
        """
        记录种子题生成成功
        
        Args:
            seed_question: 种子题目字典
        """
        seed_id = self.get_seed_id(seed_question)
        
        if seed_id not in self.seed_states:
            self.seed_states[seed_id] = {
                "total_attempts": 0,
                "success_count": 0,
                "consecutive_failures": 0,
                "is_hard_seed": False,
                "last_success_time": None,
                "last_failure_time": None,
                "failure_history": []
            }
        
        state = self.seed_states[seed_id]
        state["total_attempts"] += 1
        state["success_count"] += 1
        state["consecutive_failures"] = 0  # 重置连续失败计数
        state["last_success_time"] = datetime.now().isoformat()
        
        # 如果之前是 Hard Seed，现在成功了，可以考虑恢复
        # 恢复条件：连续成功（无失败）+ 总成功次数 ≥ 2 + 成功率 > 50%
        if state["is_hard_seed"]:
            success_rate = state["success_count"] / state["total_attempts"] if state["total_attempts"] > 0 else 0
            if state["consecutive_failures"] == 0 and state["success_count"] >= 2 and success_rate > 0.5:
                state["is_hard_seed"] = False
                print(f"✅ Seed '{seed_id}' recovered from Hard Seed status (success rate: {success_rate:.1%})")
        
        self._save_state()
    
    def record_failure(self, seed_question: dict, failure_reason: str = "") -> None:
        """
        记录种子题生成失败
        
        Args:
            seed_question: 种子题目字典
            failure_reason: 失败原因
        """
        seed_id = self.get_seed_id(seed_question)
        
        if seed_id not in self.seed_states:
            self.seed_states[seed_id] = {
                "total_attempts": 0,
                "success_count": 0,
                "consecutive_failures": 0,
                "is_hard_seed": False,
                "last_success_time": None,
                "last_failure_time": None,
                "failure_history": []
            }
        
        state = self.seed_states[seed_id]
        state["total_attempts"] += 1
        state["consecutive_failures"] += 1
        state["last_failure_time"] = datetime.now().isoformat()
        state["failure_history"].append({
            "time": datetime.now().isoformat(),
            "reason": failure_reason
        })
        
        # 保留最近 10 次失败记录
        if len(state["failure_history"]) > 10:
            state["failure_history"] = state["failure_history"][-10:]
        
        # 🚨 已禁用：不再标记 Hard Seed（避免所有种子题都被标记为不可用）
        # 注释掉 Hard Seed 标记逻辑，保持所有种子题可用
        # if state["consecutive_failures"] >= 3 and not state["is_hard_seed"]:
        #     state["is_hard_seed"] = True
        #     print(f"🚨 Seed '{seed_id}' marked as HARD SEED (3 consecutive failures)")
        #     print(f"   Recent failures: {[f['reason'][:50] for f in state['failure_history'][-3:]]}")
        
        self._save_state()
    
    def is_hard_seed(self, seed_question: dict) -> bool:
        """
        判断是否为 Hard Seed
        
        Args:
            seed_question: 种子题目字典
        
        Returns:
            True=Hard Seed, False=正常种子题
        """
        seed_id = self.get_seed_id(seed_question)
        return self.seed_states.get(seed_id, {}).get("is_hard_seed", False)
    
    def get_consecutive_failures(self, seed_question: dict) -> int:
        """
        获取连续失败次数
        
        Args:
            seed_question: 种子题目字典
        
        Returns:
            连续失败次数
        """
        seed_id = self.get_seed_id(seed_question)
        return self.seed_states.get(seed_id, {}).get("consecutive_failures", 0)
    
    def filter_seeds(self, seed_questions: List[dict], skip_hard_seeds: bool = True) -> List[dict]:
        """
        过滤种子题列表
        
        Args:
            seed_questions: 种子题目列表
            skip_hard_seeds: 是否跳过 Hard Seed
        
        Returns:
            过滤后的种子题列表
        """
        if not skip_hard_seeds:
            return seed_questions
        
        filtered = []
        skipped = []
        
        for seed in seed_questions:
            if self.is_hard_seed(seed):
                skipped.append(self.get_seed_id(seed))
            else:
                filtered.append(seed)
        
        if skipped:
            print(f"⏭️  Skipped {len(skipped)} Hard Seeds: {skipped}")
        
        return filtered
    
    def should_upgrade_model(self, seed_question: dict) -> bool:
        """
        判断是否应该升级模型
        
        Args:
            seed_question: 种子题目字典
        
        Returns:
            True=应该升级模型, False=使用默认模型
        """
        # 如果是 Hard Seed，建议升级模型
        return self.is_hard_seed(seed_question)
    
    def get_seed_stats(self, seed_question: dict) -> Dict[str, Any]:
        """
        获取种子题统计信息
        
        Args:
            seed_question: 种子题目字典
        
        Returns:
            统计信息字典
        """
        seed_id = self.get_seed_id(seed_question)
        state = self.seed_states.get(seed_id, {})
        
        return {
            "seed_id": seed_id,
            "total_attempts": state.get("total_attempts", 0),
            "success_count": state.get("success_count", 0),
            "consecutive_failures": state.get("consecutive_failures", 0),
            "is_hard_seed": state.get("is_hard_seed", False),
            "success_rate": (
                state.get("success_count", 0) / state.get("total_attempts", 1)
                if state.get("total_attempts", 0) > 0 else 0
            ),
            "last_success_time": state.get("last_success_time"),
            "last_failure_time": state.get("last_failure_time")
        }
    
    def get_all_stats(self) -> Dict[str, Any]:
        """
        获取所有种子题的统计信息
        
        Returns:
            统计摘要
        """
        total_seeds = len(self.seed_states)
        hard_seeds = sum(1 for s in self.seed_states.values() if s.get("is_hard_seed", False))
        total_attempts = sum(s.get("total_attempts", 0) for s in self.seed_states.values())
        total_successes = sum(s.get("success_count", 0) for s in self.seed_states.values())
        
        return {
            "total_seeds": total_seeds,
            "hard_seeds": hard_seeds,
            "normal_seeds": total_seeds - hard_seeds,
            "total_attempts": total_attempts,
            "total_successes": total_successes,
            "overall_success_rate": total_successes / total_attempts if total_attempts > 0 else 0,
            "hard_seed_list": [
                seed_id for seed_id, state in self.seed_states.items()
                if state.get("is_hard_seed", False)
            ]
        }
    
    def reset_seed(self, seed_question: dict) -> None:
        """
        重置种子题状态（用于手动恢复）
        
        Args:
            seed_question: 种子题目字典
        """
        seed_id = self.get_seed_id(seed_question)
        if seed_id in self.seed_states:
            self.seed_states[seed_id]["consecutive_failures"] = 0
            self.seed_states[seed_id]["is_hard_seed"] = False
            self._save_state()
            print(f"🔄 Seed '{seed_id}' status reset")
    
    def get_next_seed_to_generate(self, seed_questions: List[dict]) -> Optional[dict]:
        """
        获取下一个需要生成题目的种子题（基于配额策略）

        策略：优先选择"成功生成数量最少"的种子题，确保每个种子题都能达到目标数量

        Args:
            seed_questions: 种子题列表

        Returns:
            下一个需要生成的种子题，如果所有种子题都已达到配额则返回 None
        """
        if not seed_questions:
            return None

        # 统计每个种子题的成功生成数量
        seed_success_counts = []
        for seed in seed_questions:
            seed_id = self.get_seed_id(seed)
            success_count = self.seed_states.get(seed_id, {}).get("success_count", 0)
            seed_success_counts.append((seed, success_count))

        # 找出成功数量最少的种子题
        min_success_count = min(count for _, count in seed_success_counts)

        # 如果所有种子题都已达到目标数量，返回 None
        if min_success_count >= self.target_count_per_seed:
            return None

        # 从成功数量最少的种子题中随机选择一个（避免总是选择第一个）
        import random
        candidates = [seed for seed, count in seed_success_counts if count == min_success_count]
        return random.choice(candidates)

    def get_generation_progress(self, seed_questions: List[dict]) -> Dict[str, Any]:
        """
        获取生成进度统计

        Args:
            seed_questions: 种子题列表

        Returns:
            进度统计信息
        """
        total_target = len(seed_questions) * self.target_count_per_seed
        total_generated = sum(
            self.seed_states.get(self.get_seed_id(seed), {}).get("success_count", 0)
            for seed in seed_questions
        )

        seed_progress = []
        for seed in seed_questions:
            seed_id = self.get_seed_id(seed)
            success_count = self.seed_states.get(seed_id, {}).get("success_count", 0)
            seed_progress.append({
                "seed_id": seed_id,
                "success_count": success_count,
                "target_count": self.target_count_per_seed,
                "progress": f"{success_count}/{self.target_count_per_seed}",
                "completed": success_count >= self.target_count_per_seed
            })

        return {
            "total_target": total_target,
            "total_generated": total_generated,
            "progress_percentage": (total_generated / total_target * 100) if total_target > 0 else 0,
            "seed_progress": seed_progress,
            "completed_seeds": sum(1 for s in seed_progress if s["completed"]),
            "total_seeds": len(seed_questions)
        }

    def export_report(self, output_path: str = "seed_report.json") -> None:
        """
        导出种子题分析报告

        Args:
            output_path: 报告输出路径
        """
        report = {
            "generated_at": datetime.now().isoformat(),
            "summary": self.get_all_stats(),
            "seed_details": {}
        }

        for seed_id, state in self.seed_states.items():
            report["seed_details"][seed_id] = {
                **state,
                "success_rate": (
                    state.get("success_count", 0) / state.get("total_attempts", 1)
                    if state.get("total_attempts", 0) > 0 else 0
                )
            }

        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            print(f"📊 Seed report exported to: {output_path}")
        except Exception as e:
            print(f"⚠️ Failed to export report: {e}")
