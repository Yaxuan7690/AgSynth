"""检查代码中是否存在 MemoryManager/ReflectionEngine/memory_logs"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
keywords = ["MemoryManager", "ReflectionEngine", "memory_logs", "simple_reflection"]

for fname in sorted(os.listdir(BASE_DIR)):
    if not fname.endswith(".py") or fname.startswith("_"):
        continue
    fpath = os.path.join(BASE_DIR, fname)
    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f, 1):
            for kw in keywords:
                if kw.lower() in line.lower():
                    print(f"  [{fname}] L{i}: {line.strip()[:100]}")

os.remove(os.path.abspath(__file__))
