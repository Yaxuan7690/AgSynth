"""
auto_fixer.py
自动修复器 - 解决问题 A、B、C 的自动修复

核心功能：
1. 自动修复棋盘坐标逻辑错误
2. 自动调整画布布局（防止超出边界）
3. 自动修复数据漂移（锁定核心数据）
"""
from typing import Dict, Any, List, Tuple, Optional
import re
import json


class AutoFixer:
    """自动修复器 - 智能修复常见错误"""
    
    def __init__(self):
        """初始化修复器"""
        pass
    
    # ========================================================================
    # 问题 A：棋盘逻辑自动修复
    # ========================================================================
    
    def fix_board_coordinates(
        self,
        concept_design: dict,
        fix_suggestions: dict,
        board_size: Tuple[int, int] = (15, 15)
    ) -> Dict[str, Any]:
        """
        自动修复棋盘坐标错误
        
        修复策略：
        1. 超出边界 → 调整到边界内
        2. 重复坐标 → 微调位置
        3. 连线错误 → 重新生成连续坐标
        
        Args:
            concept_design: ConceptDesigner 的输出
            fix_suggestions: 验证器提供的修复建议
            board_size: 棋盘大小
        
        Returns:
            修复后的 concept_design
        """
        action = fix_suggestions.get('action', '')
        
        if action == 'adjust_coordinates':
            # 修复超出边界的坐标
            return self._adjust_out_of_bounds(concept_design, board_size)
        
        elif action == 'remove_duplicates':
            # 修复重复坐标
            return self._remove_duplicate_coords(concept_design)
        
        elif action == 'fix_winning_path':
            # 修复获胜路径
            return self._fix_winning_path(concept_design, fix_suggestions)
        
        return concept_design
    
    def _adjust_out_of_bounds(
        self,
        concept_design: dict,
        board_size: Tuple[int, int]
    ) -> Dict[str, Any]:
        """调整超出边界的坐标"""
        # 🔒 类型安全：确保 data_specs 是字符串
        concept_data = concept_design.get('concept_design', {})
        if isinstance(concept_data, dict):
            data_specs = concept_data.get('data_specifications', '')
        else:
            data_specs = str(concept_data)

        # 确保 data_specs 是字符串
        if not isinstance(data_specs, str):
            data_specs = str(data_specs)

        # 提取所有坐标
        pattern = r'\((\d+),\s*(\d+)\)'
        matches = re.findall(pattern, data_specs)
        
        # 修复每个坐标
        for match in matches:
            x, y = int(match[0]), int(match[1])
            new_x = max(0, min(x, board_size[0] - 1))
            new_y = max(0, min(y, board_size[1] - 1))
            
            if (x, y) != (new_x, new_y):
                # 替换坐标
                old_coord = f"({x}, {y})"
                new_coord = f"({new_x}, {new_y})"
                data_specs = data_specs.replace(old_coord, new_coord)
        
        # 更新 concept_design
        if 'concept_design' in concept_design and isinstance(concept_design['concept_design'], dict):
            concept_design['concept_design']['data_specifications'] = data_specs
        
        return concept_design
    
    def _remove_duplicate_coords(self, concept_design: dict) -> Dict[str, Any]:
        """移除重复坐标（微调位置）"""
        # 🔒 类型安全：确保 data_specs 是字符串
        concept_data = concept_design.get('concept_design', {})
        if isinstance(concept_data, dict):
            data_specs = concept_data.get('data_specifications', '')
        else:
            data_specs = str(concept_data)

        # 确保 data_specs 是字符串
        if not isinstance(data_specs, str):
            data_specs = str(data_specs)

        # 提取所有坐标及其位置
        pattern = r'(\w+)[:\s]*\((\d+),\s*(\d+)\)'
        matches = list(re.finditer(pattern, data_specs))
        
        seen_coords = {}
        replacements = []
        
        for match in matches:
            name = match.group(1)
            x, y = int(match.group(2)), int(match.group(3))
            coord = (x, y)
            
            if coord in seen_coords:
                # 重复坐标，微调位置
                new_x, new_y = self._find_nearby_empty_coord(coord, seen_coords)
                replacements.append((match.group(0), f"{name}: ({new_x}, {new_y})"))
                seen_coords[(new_x, new_y)] = name
            else:
                seen_coords[coord] = name
        
        # 应用替换
        for old, new in replacements:
            data_specs = data_specs.replace(old, new, 1)
        
        # 更新 concept_design
        if 'concept_design' in concept_design and isinstance(concept_design['concept_design'], dict):
            concept_design['concept_design']['data_specifications'] = data_specs
        
        return concept_design
    
    def _find_nearby_empty_coord(
        self,
        coord: Tuple[int, int],
        occupied: Dict[Tuple[int, int], str]
    ) -> Tuple[int, int]:
        """找到附近的空坐标"""
        x, y = coord
        offsets = [(1, 0), (0, 1), (-1, 0), (0, -1), (1, 1), (-1, -1), (1, -1), (-1, 1)]
        
        for dx, dy in offsets:
            new_coord = (x + dx, y + dy)
            if new_coord not in occupied and new_coord[0] >= 0 and new_coord[1] >= 0:
                return new_coord
        
        # 如果附近都被占用，返回原坐标 + (2, 2)
        return (x + 2, y + 2)
    
    def _fix_winning_path(
        self,
        concept_design: dict,
        fix_suggestions: dict
    ) -> Dict[str, Any]:
        """修复获胜路径（重新生成连续坐标）"""
        current_path = fix_suggestions.get('current_path', [])

        if not current_path or len(current_path) < 5:
            return concept_design

        # 生成新的连续坐标（水平线）
        start_x, start_y = current_path[0]
        new_path = [(start_x + i, start_y) for i in range(5)]

        # 🔒 类型安全：确保 data_specs 是字符串
        concept_data = concept_design.get('concept_design', {})
        if isinstance(concept_data, dict):
            data_specs = concept_data.get('data_specifications', '')
        else:
            data_specs = str(concept_data)

        # 确保 data_specs 是字符串
        if not isinstance(data_specs, str):
            data_specs = str(data_specs)

        # 简单替换：将前5个坐标替换为新路径
        pattern = r'\((\d+),\s*(\d+)\)'
        matches = list(re.finditer(pattern, data_specs))
        
        for i, (match, new_coord) in enumerate(zip(matches[:5], new_path)):
            old_coord = match.group(0)
            new_coord_str = f"({new_coord[0]}, {new_coord[1]})"
            data_specs = data_specs.replace(old_coord, new_coord_str, 1)
        
        # 更新 concept_design
        if 'concept_design' in concept_design and isinstance(concept_design['concept_design'], dict):
            concept_design['concept_design']['data_specifications'] = data_specs
        
        return concept_design
    
    # ========================================================================
    # 问题 B：画布布局自动修复
    # ========================================================================
    
    def fix_canvas_layout(
        self,
        visual_spec: dict,
        fix_suggestions: dict,
        canvas_size: Tuple[float, float] = (12.0, 12.0)
    ) -> Dict[str, Any]:
        """
        自动修复画布布局错误
        
        修复策略：
        1. 超出边界 → 向内移动
        2. 元素重叠 → 增加间距
        3. 标注遮挡 → 调整标注位置
        
        Args:
            visual_spec: VisualSpecifier 的输出
            fix_suggestions: 验证器提供的修复建议
            canvas_size: 画布大小
        
        Returns:
            修复后的 visual_spec
        """
        action = fix_suggestions.get('action', '')
        
        if action == 'adjust_positions':
            # 修复超出边界的元素
            return self._adjust_element_positions(visual_spec, fix_suggestions, canvas_size)
        
        elif action == 'increase_spacing':
            # 修复元素重叠
            return self._increase_element_spacing(visual_spec, fix_suggestions)
        
        return visual_spec
    
    def _adjust_element_positions(
        self,
        visual_spec: dict,
        fix_suggestions: dict,
        canvas_size: Tuple[float, float]
    ) -> Dict[str, Any]:
        """调整元素位置（防止超出边界）"""
        spec_text = str(visual_spec.get('detailed_image_specification', ''))
        min_margin = fix_suggestions.get('min_margin', 0.5)
        
        # 提取所有坐标
        pattern = r'at\s+\(([0-9.]+),\s*([0-9.]+)\)'
        matches = list(re.finditer(pattern, spec_text, re.IGNORECASE))
        
        replacements = []
        for match in matches:
            x, y = float(match.group(1)), float(match.group(2))
            
            # 调整 X 坐标
            if x < min_margin:
                new_x = min_margin
            elif x > canvas_size[0] - min_margin:
                new_x = canvas_size[0] - min_margin
            else:
                new_x = x
            
            # 调整 Y 坐标
            if y < min_margin:
                new_y = min_margin
            elif y > canvas_size[1] - min_margin:
                new_y = canvas_size[1] - min_margin
            else:
                new_y = y
            
            if (x, y) != (new_x, new_y):
                old_coord = match.group(0)
                new_coord = f"at ({new_x:.2f}, {new_y:.2f})"
                replacements.append((old_coord, new_coord))
        
        # 应用替换
        for old, new in replacements:
            spec_text = spec_text.replace(old, new, 1)
        
        # 更新 visual_spec
        visual_spec['detailed_image_specification'] = spec_text
        
        return visual_spec
    
    def _increase_element_spacing(
        self,
        visual_spec: dict,
        fix_suggestions: dict
    ) -> Dict[str, Any]:
        """增加元素间距（防止重叠）"""
        spec_text = str(visual_spec.get('detailed_image_specification', ''))
        overlaps = fix_suggestions.get('overlaps', [])
        
        # 简化策略：将所有 Y 坐标增加 0.5 单位间距
        pattern = r'at\s+\(([0-9.]+),\s*([0-9.]+)\)'
        matches = list(re.finditer(pattern, spec_text, re.IGNORECASE))
        
        replacements = []
        for i, match in enumerate(matches):
            x, y = float(match.group(1)), float(match.group(2))
            new_y = y + i * 0.5  # 每个元素增加 0.5 单位间距
            
            old_coord = match.group(0)
            new_coord = f"at ({x:.2f}, {new_y:.2f})"
            replacements.append((old_coord, new_coord))
        
        # 应用替换
        for old, new in replacements:
            spec_text = spec_text.replace(old, new, 1)
        
        # 更新 visual_spec
        visual_spec['detailed_image_specification'] = spec_text
        
        return visual_spec
    
    # ========================================================================
    # 问题 C：数据漂移自动修复
    # ========================================================================
    
    def fix_data_drift(
        self,
        visual_spec: dict,
        concept_design: dict
    ) -> Dict[str, Any]:
        """
        自动修复数据漂移（强制使用锁定数据）
        
        修复策略：
        1. 提取 locked_data_fields
        2. 强制覆盖 visual_spec 中的 data_values
        3. 更新 detailed_image_specification 中的数值
        
        Args:
            visual_spec: VisualSpecifier 的输出
            concept_design: ConceptDesigner 的输出（包含 locked_data_fields）
        
        Returns:
            修复后的 visual_spec
        """
        locked_data = concept_design.get('locked_data_fields', {})
        
        if not locked_data:
            return visual_spec  # 没有锁定数据，跳过修复
        
        # 强制覆盖 data_values
        data_values = visual_spec.get('data_values', {})
        
        for field_name, locked_value in locked_data.items():
            # 在 data_values 中查找并替换
            for key in data_values.keys():
                if field_name.lower() in key.lower():
                    data_values[key] = locked_value
        
        # 更新 visual_spec
        visual_spec['data_values'] = data_values
        
        # 同时更新 detailed_image_specification 中的数值
        spec_text = str(visual_spec.get('detailed_image_specification', ''))
        
        for field_name, locked_value in locked_data.items():
            # 简单替换：将所有数字替换为锁定值
            # 注意：这是一个简化实现，实际可能需要更精确的匹配
            if isinstance(locked_value, (int, float)):
                # 查找并替换数字
                pattern = rf'\b\d+\b'
                # 这里需要更智能的替换逻辑，暂时跳过
                pass
        
        return visual_spec
    
    # ========================================================================
    # 通用修复接口
    # ========================================================================
    
    def auto_fix(
        self,
        concept_design: dict,
        visual_spec: dict,
        validation_errors: List[str],
        fix_suggestions: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        自动修复所有检测到的错误
        
        Args:
            concept_design: ConceptDesigner 的输出
            visual_spec: VisualSpecifier 的输出
            validation_errors: 验证错误列表
            fix_suggestions: 修复建议字典
        
        Returns:
            (fixed_concept_design, fixed_visual_spec)
        """
        fixed_concept = concept_design.copy()
        fixed_visual = visual_spec.copy()
        
        # 修复棋盘逻辑错误
        if 'board_logic' in fix_suggestions:
            fixed_concept = self.fix_board_coordinates(
                fixed_concept,
                fix_suggestions['board_logic']
            )
        
        # 修复画布布局错误
        if 'canvas_layout' in fix_suggestions:
            fixed_visual = self.fix_canvas_layout(
                fixed_visual,
                fix_suggestions['canvas_layout']
            )
        
        # 修复数据漂移
        fixed_visual = self.fix_data_drift(fixed_visual, fixed_concept)
        
        return fixed_concept, fixed_visual
