
from typing import Dict, Any, Optional, List, Tuple
from utils import chat_completion, vision_completion, multi_vision_completion, AGENT_MODELS
from math_validator import MathValidator
from board_validator import BoardValidator


class FullProcessAuditorAgent:
    """
    全流程审计智能体 - Agent 5 增强版
    
    职责：
    1. 阶段 1 审计：ConceptDesigner 的逻辑严密性审计
    2. 阶段 2 审计：VisualSpecifier 的设计合理性审计
    3. 阶段 3 审计：Painter 的图像质量审计
    4. 阶段 4 审计：QA Generator 的图文一致性审计
    5. 最终评分：综合质量评分（保留原职能）
    
    审计模式：
    - 即时拦截（Middleware Mode）：在每个阶段后立即审计
    - 记忆累积（Experience Record）：记录每个阶段的打回原因
    - 最终评分（Final Rating）：全流程通过后进行综合评分
    """
    
    def __init__(self):
        """初始化审计智能体"""
        self.audit_history = []  # 记录审计历史
        self.math_validator = MathValidator()  # 🚨 数学验证工具
        self.board_validator = BoardValidator()  # 🚨 NEW: 棋盘逻辑验证工具
    
    # ========================================================================
    # 阶段 1 审计：ConceptDesigner 逻辑审计
    # ========================================================================
    def audit_stage1_concept(
        self,
        concept_design: dict,
        seed_questions: List[dict],
        difficulty: str
    ) -> Tuple[bool, Optional[str]]:
        """
        阶段 1 审计：对 ConceptDesigner 的逻辑审计
        
        身份：高级数学逻辑专家
        
        审查重点：
        1. 数学闭环性：根据数据规格和逻辑内核，是否能计算出唯一解？
        2. 逻辑一致性：提取的逻辑内核是否与种子题等价？
        3. 创新合法性：设计的新题目概念是否避开"简单改数字"雷区？
        
        Args:
            concept_design: ConceptDesigner 的输出
            seed_questions: 种子题目列表
            difficulty: 难度要求
        
        Returns:
            (pass_check, feedback)
            - pass_check: True=通过审计, False=需要打回
            - feedback: 审计反馈（打回时提供详细原因）
        """
        sys_prompt = (
            "You are a **Senior Mathematical Logic Expert** conducting Stage 1 Audit.\n\n"
            "## 🎯 Your Mission\n\n"
            "Audit the **logic rigor and mathematical closure** of the concept design.\n\n"
            "## 📋 Audit Checklist\n\n"
            "### 1. Mathematical Closure (数学闭环性) - RELAXED MODE\n"
            "- **Question**: Is the concept design CONCRETE and SPECIFIC enough?\n"
            "- **🎯 NEW: Focus on CONCRETENESS, not mathematical uniqueness!**\n"
            "  - **IMPORTANT**: Stage 1 should produce a CONCRETE question, not just a question type!\n"
            "  - **Expected Answer**: Can be descriptive (e.g., 'Option B', 'Red circle', 'Position (3,5)')\n"
            "  - **Multiple Solutions**: ACCEPTABLE (Stage 4 will handle answer format)\n"
            "  - **Descriptive Answers**: ACCEPTABLE (e.g., 'The path goes through 3 targets')\n"
            "- **Check for**:\n"
            "  - ❌ REJECT: Abstract description without concrete values (e.g., 'some objects with different weights')\n"
            "  - ❌ REJECT: Missing critical data (e.g., 'objects on a board' without specifying how many)\n"
            "  - ❌ REJECT: Contradictory conditions (e.g., 'A > B' and 'B > A')\n"
            "  - ✅ ACCEPT: Concrete values with descriptive answer (e.g., '3 red apples, 5 blue balls' → 'Total: 8 objects')\n"
            "  - ✅ ACCEPT: Multiple solutions with clear answer format (e.g., 'Any path through 3 targets')\n\n"
            "- **🔧 Python Validation Tool Available**:\n"
            "  - If the problem involves 24-point, equation systems, or arithmetic puzzles\n"
            "  - Use the math_verification_hint field to trigger Python validation\n"
            "  - The validator will return: solution_count, sample_solutions, recommendation\n\n"
            "### 1.5. Internal Consistency (内部一致性) - NEW!\n"
            "- **Question**: Are all data points CONSISTENT throughout the entire concept design?\n"
            "- **Critical Check**: Extract ALL mentions of the SAME entity and verify they have the SAME value\n"
            "- **Examples of Contradictions to Detect**:\n"
            "  - ❌ \"White pieces have NOT formed a line\" (main description) BUT \"White has WON\" (notes)\n"
            "  - ❌ \"Collect 4 targets\" (logic kernel) BUT \"Badge shows 3\" (data specifications)\n"
            "  - ❌ \"Object A weighs 5kg\" (list) BUT \"Object A weighs 6kg\" (constraints)\n"
            "  - ❌ \"3 objects\" (quantity) BUT lists 4 objects (data)\n"
            "- **Verification Protocol**:\n"
            "  1. Extract all key entities (objects, targets, pieces, etc.)\n"
            "  2. For each entity, collect ALL mentions with their values\n"
            "  3. Check if the SAME entity has DIFFERENT values in different parts\n"
            "  4. Check if logical states are COHERENT (e.g., \"not connected\" should NOT imply \"won\")\n"
            "  5. Check if counts MATCH (e.g., \"4 targets\" should list exactly 4 items)\n\n"
            "### 2. Logic Consistency (逻辑一致性)\n"
            "- **Question**: Is the extracted logic kernel truly EQUIVALENT to the seed question?\n"
            "- **Check for**:\n"
            "  - Missing key constraints (遗漏关键约束)\n"
            "  - Misinterpreted relationships (关系理解错误)\n"
            "  - Oversimplified logic (逻辑过度简化)\n\n"
            "### 3. Innovation Assessment (创新性评估) - ENCOURAGEMENT MODE\n"
            "- **Philosophy**: Innovation is ENCOURAGED but NOT MANDATORY\n"
            "- **Grading Scale**:\n"
            "  - 🌟 High Innovation (高创新): New visual form + new data structure → EXCELLENT\n"
            "  - ⭐ Medium Innovation (中等创新): Same visual form but different data/context → ACCEPTABLE\n"
            "  - ✨ Low Innovation (低创新): Only number changes but logic preserved → ACCEPTABLE\n"
            "- **CRITICAL**: Even LOW innovation should PASS if logic is sound!\n"
            "- **Only REJECT if**:\n"
            "  - Exact copy of seed question (完全照搬种子题)\n"
            "  - No effort to modify anything (毫无修改)\n"
            "- **Examples of ACCEPTABLE low innovation**:\n"
            "  - Seed: \"3 apples + 5 oranges\" → New: \"4 apples + 6 oranges\" (✅ PASS - numbers changed)\n"
            "  - Seed: \"5×5 grid\" → New: \"6×6 grid\" (✅ PASS - size changed)\n"
            "  - Seed: \"Red circles\" → New: \"Blue squares\" (✅ PASS - color/shape changed)\n\n"
            "## 🚨 Error Severity Classification (NEW - CRITICAL)\n\n"
            "**🔴 CRITICAL ERRORS (MUST REJECT)**:\n"
            "1. **Internal Contradiction Detected** (HIGHEST PRIORITY):\n"
            "   - Same entity has different values in different parts\n"
            "   - Logical states are incoherent (e.g., \"not connected\" + \"won\")\n"
            "   - Counts don't match (e.g., \"4 targets\" but lists 3 items)\n"
            "   - Example: \"Board data is internally inconsistent... contradictory specifications\"\n"
            "2. Logic contradiction detected (e.g., \"Condition A conflicts with Condition B\")\n"
            "3. **No solution exists** (Python validation confirms 0 solutions)\n"
            "4. Insufficient data to solve (missing critical information)\n"
            "5. **Exact copy of seed question** (完全照搬，毫无修改) - REMOVED: Low innovation is now ACCEPTABLE\n\n"
            "**🟡 MAJOR ERRORS (REJECT, but provide SPECIFIC fix instructions)**:\n"
            "1. **Coordinate out of bounds** (e.g., (12, 8) on 10×10 canvas)\n"
            "   - Severity: MAJOR\n"
            "   - Action: Provide exact corrected coordinates\n"
            "   - Example: \"Change Target_A from (12, 8) to (9.0, 7.5)\"\n"
            "2. **Overlapping elements** (distance < minimum spacing)\n"
            "   - Severity: MAJOR\n"
            "   - Action: Provide adjusted positions with spacing calculation\n"
            "3. **Missing key constraints** (problem becomes ambiguous)\n"
            "   - Severity: MAJOR\n"
            "   - Action: Specify exact constraint to add\n\n"
            "**🟢 MINOR ISSUES (ACCEPT with optional suggestions)**:\n"
            "1. **Low innovation level** (only number/color/size changes)\n"
            "   - Severity: MINOR\n"
            "   - Action: ACCEPT, optionally suggest more creative approaches for future\n"
            "   - Example: \"Innovation level: Low (only numbers changed). ACCEPTED. Optional: Consider different visual forms next time.\"\n"
            "2. **Slightly insufficient margin** (e.g., 0.25 instead of 0.3)\n"
            "   - Severity: MINOR\n"
            "   - Action: ACCEPT, provide optional improvement suggestion\n"
            "3. **Minor spacing issues** (e.g., 0.15 instead of 0.2)\n"
            "   - Severity: MINOR\n"
            "   - Action: ACCEPT, note as \"non-critical\"\n"
            "4. **Stylistic preferences** (color choices, font sizes)\n"
            "   - Severity: MINOR\n"
            "   - Action: ACCEPT without comment\n\n"
            "**MUST INFORM (NOT REJECT) if**:\n"
            "1. **Multiple Solutions Detected** (Python validation confirms 2+ solutions):\n"
            "   - Provide exact solution count and sample solutions\n"
            "   - Recommend answer format: \"Any of: [solution1, solution2, ...]\"\n"
            "   - Example: \"This 24-point problem has 12 solutions. Suggest answer format: 'Any valid expression using [3,3,8,8] that equals 24'\"\n"
            "2. **Infinite Solutions Detected** (Python validation confirms infinite solutions):\n"
            "   - Recommend adding constraints or adjusting answer format\n"
            "   - Example: \"This equation system has infinite solutions. Suggest: Add one more constraint OR answer format: 'Any (x,y) satisfying 2x+3y=10'\"\n\n"
            "## 📤 Output Format (ENHANCED with Severity & Preservation)\n\n"
            "Return a JSON object:\n"
            "```json\n"
            "{\n"
            "  \"pass_audit\": true/false,\n"
            "  \"audit_score\": 1-10,\n"
            "  \"innovation_level\": \"HIGH\" | \"MEDIUM\" | \"LOW\",  // NEW: Innovation assessment (all levels acceptable)\n"
            "  \"error_severity\": \"CRITICAL\" | \"MAJOR\" | \"MINOR\",  // NEW: Error severity level\n"
            "  \"feedback\": \"Brief diagnosis (1-2 sentences)\",\n"
            "  \"issues_found\": [\n"
            "    {\"issue\": \"Issue description\", \"severity\": \"CRITICAL\" | \"MAJOR\" | \"MINOR\"}  // NEW: Each issue has severity\n"
            "  ],\n"
            "  \"preserved_fields\": [  // NEW: Fields that are CORRECT and should NOT be modified\n"
            "    \"core_logic_kernel\",\n"
            "    \"concept_design.logic_description\",\n"
            "    \"expected_answer\"\n"
            "  ],\n"
            "  \"fields_to_modify\": [  // NEW: ONLY these fields need modification\n"
            "    {\"field\": \"concept_design.data_specifications\", \"reason\": \"Coordinate out of bounds\", \"severity\": \"MAJOR\"},\n"
            "    {\"field\": \"ascii_board_check\", \"reason\": \"Winning path not connected\", \"severity\": \"CRITICAL\"}\n"
            "  ],\n"
            "  \"correction_instructions\": [\n"
            "    \"SPECIFIC instruction 1: e.g., 'PRESERVE: core_logic_kernel, concept_design.logic_description (these are correct)'\",\n"
            "    \"SPECIFIC instruction 2: e.g., 'MODIFY ONLY: concept_design.data_specifications line 5 - Change Target_A coordinate from (12, 8) to (9.0, 7.5)'\",\n"
            "    \"SPECIFIC instruction 3: e.g., 'MODIFY ONLY: ascii_board_check - Redraw row 3 to connect (C,3) and (D,3)'\"\n"
            "  ],\n"
            "  \"consistency_violations\": [\n"
            "    {\"entity\": \"White pieces\", \"location1\": \"main description\", \"value1\": \"not connected\", \"location2\": \"notes\", \"value2\": \"won\", \"severity\": \"CRITICAL\"},\n"
            "    {\"entity\": \"Target count\", \"location1\": \"logic kernel\", \"value1\": \"4\", \"location2\": \"badge\", \"value2\": \"3\", \"severity\": \"CRITICAL\"}\n"
            "  ],\n"
            "  \"forbidden_patterns\": [\"Pattern to avoid\"],\n"
            "  \"required_patterns\": [\"Pattern to follow\"],\n"
            "  \"math_validation_result\": {\n"
            "    \"validated\": true/false,\n"
            "    \"solution_count\": 0/1/12/-1,\n"
            "    \"sample_solutions\": [\"solution1\", \"solution2\", ...],\n"
            "    \"recommendation\": \"Specific recommendation for answer format\"\n"
            "  }\n"
            "}\n"
            "```\n\n"
            "**CRITICAL RULES for correction_instructions (ENHANCED)**:\n"
            "1. ❌ FORBIDDEN: \"Your logic is not closed\" (too vague)\n"
            "2. ✅ REQUIRED: \"PRESERVE: core_logic_kernel, expected_answer (correct). MODIFY ONLY: data_specifications line 5 - Change Target_A from (12,8) to (9.0,7.5)\" (specific + preservation)\n"
            "3. ❌ FORBIDDEN: \"Data is inconsistent\" (too vague)\n"
            "4. ✅ REQUIRED: \"PRESERVE: All logic descriptions (correct). MODIFY ONLY: Badge number from '3' to '4' in data_specifications to match logic kernel\" (specific + preservation)\n"
            "5. **NEW**: Always start with \"PRESERVE: [list of correct fields]\" to prevent full regeneration\n"
            "6. **NEW**: Then specify \"MODIFY ONLY: [specific field] - [exact change]\" for surgical fixes\n"
            "7. Each instruction must be DIRECTLY ACTIONABLE (copy-paste ready)\n"
            "8. **NEW**: For MINOR errors, use \"OPTIONAL: [suggestion]\" instead of \"MODIFY\""
        )
        
        # 🚨 NEW: 强制验证所有数值计算题(第二层防护)
        math_validation_result = None

        # 优先使用 ConceptDesigner 的自验证结果
        self_validation = concept_design.get('self_validation_result')
        if self_validation and self_validation.get('validated'):
            print(f"   ✅ 使用 ConceptDesigner 自验证结果")
            math_validation_result = {
                'solution_count': self_validation.get('solution_count', 0),
                'recommendation': self_validation.get('recommendation', ''),
                'validation_result': {
                    'sample_solutions': self_validation.get('sample_solutions', [])
                }
            }
        else:
            # 如果没有自验证结果,尝试使用 math_verification_hint
            math_hint = concept_design.get('math_verification_hint')
            if math_hint and isinstance(math_hint, dict):
                problem_type = math_hint.get('type')
                if problem_type:
                    print(f"   🔧 Auditor 主动验证数学逻辑: {problem_type}")
                    try:
                        validation = self.math_validator.detect_multiple_solutions(
                            problem_type=problem_type,
                            problem_data=math_hint
                        )
                        math_validation_result = validation
                        print(f"   🔧 Python 验证结果: {validation.get('solution_count')} 个解")
                    except Exception as e:
                        print(f"   ⚠️ Python 验证失败: {e}")

        # 🚨 NEW: 棋盘逻辑验证(第三层防护)
        board_validation_result = None
        ascii_board = concept_design.get('ascii_board_check', '')

        if ascii_board:
            print(f"   🎯 检测到ASCII棋盘,启动棋盘逻辑验证...")
            try:
                board_validation = self.board_validator.validate_concept_with_reflection(
                    concept_design=concept_design,
                    expected_winner=None,  # 从concept_design中推断
                    required_length=5  # 默认五子棋
                )
                board_validation_result = board_validation

                if not board_validation['is_valid']:
                    print(f"   ❌ 棋盘逻辑验证失败!")
                    print(f"   💡 反思提示: {board_validation['reflection_prompt'][:200]}...")
                else:
                    print(f"   ✅ 棋盘逻辑验证通过")
            except Exception as e:
                print(f"   ⚠️ 棋盘验证失败: {e}")

        user_prompt = (
            f"## 📊 Concept Design to Audit\n\n"
            f"**Difficulty**: {difficulty}\n\n"
            f"**Core Logic Kernel**:\n{concept_design.get('core_logic_kernel', 'N/A')}\n\n"
            f"**Concept Design**:\n{concept_design.get('concept_design', 'N/A')}\n\n"
            f"**Expected Answer**:\n{concept_design.get('expected_answer', 'N/A')}\n\n"
            f"**Design Rationale**:\n{concept_design.get('design_rationale', 'N/A')}\n\n"
        )

        # 🚨 NEW: 如果有ASCII棋盘,添加到提示中
        if ascii_board:
            user_prompt += (
                f"## 🎯 ASCII Board Check (CRITICAL)\n\n"
                f"**ConceptDesigner provided an ASCII board**:\n"
                f"```\n{ascii_board}\n```\n\n"
            )

        # 🚨 NEW: 如果有棋盘验证结果,优先显示(最高优先级)
        if board_validation_result:
            is_valid = board_validation_result['is_valid']
            reflection = board_validation_result['reflection_prompt']

            user_prompt += (
                f"## 🎯 Board Logic Validation Result (HIGHEST PRIORITY)\n\n"
                f"**Validation Status**: {'✅ PASSED' if is_valid else '❌ FAILED'}\n\n"
            )

            if not is_valid:
                user_prompt += (
                    f"**⚠️ CRITICAL FAILURE - Board logic is INVALID**:\n\n"
                    f"{reflection}\n\n"
                    f"**MANDATORY ACTION**: You MUST REJECT this concept design and provide the reflection prompt to ConceptDesigner.\n"
                    f"**DO NOT PROCEED** until the board logic is fixed.\n\n"
                )

        # 🚨 如果有 Python 验证结果，添加到提示中
        if math_validation_result:
            solution_count = math_validation_result.get('solution_count', 0)
            recommendation = math_validation_result.get('recommendation', '')
            sample_solutions = math_validation_result.get('validation_result', {}).get('sample_solutions', [])

            user_prompt += (
                f"## 🔧 Python Validation Result (CRITICAL)\n\n"
                f"**Solution Count**: {solution_count}\n"
                f"**Sample Solutions**: {sample_solutions[:3]}\n"
                f"**Recommendation**: {recommendation}\n\n"
                f"**⚠️ IMPORTANT**: \n"
                f"- If solution_count = 0 → REJECT (no solution)\n"
                f"- If solution_count = 1 → PASS (unique solution)\n"
                f"- If solution_count > 1 → PASS, but INFORM ConceptDesigner to adjust answer format\n"
                f"- If solution_count = -1 → PASS, but INFORM ConceptDesigner about infinite solutions\n\n"
            )

        user_prompt += (
            f"## 🌱 Seed Question Reference\n\n"
            f"**Seed Question Type**: {seed_questions[0].get('question_type', 'N/A')}\n"
            f"**Seed Question**: {seed_questions[0].get('question', 'N/A')[:500]}\n"
            f"**Seed Answer**: {seed_questions[0].get('answer', 'N/A')}\n\n"
            f"## 🔍 Your Task\n\n"
            f"Conduct a thorough audit of the concept design. Focus on:\n"
            f"1. **PRIORITY 1**: Check for INTERNAL CONTRADICTIONS (same entity with different values)\n"
            f"   - Extract all entities and their values from ALL parts of the design\n"
            f"   - Verify the SAME entity has the SAME value everywhere\n"
            f"   - Check logical coherence (e.g., \"not connected\" should NOT imply \"won\")\n"
            f"2. Is the problem SOLVABLE? (Use Python validation result if available)\n"
            f"3. Is the logic kernel truly equivalent to the seed question?\n"
            f"4. Does the design show genuine innovation (not just number changes)?\n\n"
            f"**Be EXTRA strict on internal consistency. This is the #1 cause of \"dead questions\".**\n"
            f"**If Python validation shows multiple solutions, INFORM (don't reject) and provide specific answer format recommendations.**"
        )
        
        try:
            result = chat_completion(
                system_prompt=sys_prompt,
                user_prompt=user_prompt,
                json_mode=True,  # 🔧 Stage 1 审计需要 JSON 格式返回
                timeout=60.0,
                temperature=0.3,  # 低温度确保审计严谨
                model=AGENT_MODELS.get("auditor")
            )
            
            pass_audit = result.get("pass_audit", False)
            feedback = result.get("feedback", "")
            audit_score = result.get("audit_score", 5)
            issues = result.get("issues_found", [])
            # 🆕 提取错误严重性,默认为 CRITICAL
            error_severity = result.get("error_severity", "CRITICAL")

            # 🚨 NEW: 如果棋盘验证失败,强制拒绝(最高优先级)
            if board_validation_result and not board_validation_result['is_valid']:
                print(f"   ❌ 棋盘逻辑验证失败,强制拒绝!")
                reflection_prompt = board_validation_result['reflection_prompt']

                # 记录审计历史
                self.audit_history.append({
                    "stage": "Stage1_Concept",
                    "pass": False,
                    "score": 0,
                    "issues": ["Board logic validation failed"],
                    "board_validation": board_validation_result
                })

                return False, (
                    f"❌ Stage 1 Audit Failed - Board Logic Invalid\n\n"
                    f"**Python Validator detected critical board logic errors**:\n\n"
                    f"{reflection_prompt}\n\n"
                    f"**You MUST redraw the ASCII board and fix the coordinate errors before proceeding.**"
                )

            # 记录审计历史
            self.audit_history.append({
                "stage": "Stage1_Concept",
                "pass": pass_audit,
                "score": audit_score,
                "issues": issues,
                "board_validation": board_validation_result if board_validation_result else None
            })

            if not pass_audit:
                # 🆕 优化 2: 细化审计反馈 - 返回结构化的REVISION_GUIDE
                structured_feedback = f"❌ Stage 1 Audit Failed (Score: {audit_score}/10)\n\n"
                structured_feedback += f"## 🚨 REVISION GUIDE - 强制修正指南\n\n"
                structured_feedback += f"**审计诊断**: {feedback}\n\n"

                # 🆕 提取 correction_instructions (最高优先级)
                correction_instructions = result.get("correction_instructions", [])
                if correction_instructions:
                    structured_feedback += "### ✅ 强制修正要求 (MANDATORY):\n\n"
                    for i, instruction in enumerate(correction_instructions, 1):
                        structured_feedback += f"{i}. {instruction}\n"
                    structured_feedback += "\n"

                # 提取具体的矛盾点
                if issues:
                    structured_feedback += "### 📋 具体问题列表:\n\n"
                    for i, issue in enumerate(issues, 1):
                        structured_feedback += f"{i}. {issue}\n"
                    structured_feedback += "\n"

                # 🆕 提取内部一致性违规 (HIGHEST PRIORITY)
                consistency_violations = result.get("consistency_violations", [])
                if consistency_violations:
                    structured_feedback += "### 🚨 内部一致性违规 (CRITICAL):\n\n"
                    for violation in consistency_violations:
                        entity = violation.get("entity", "Unknown")
                        loc1 = violation.get("location1", "")
                        val1 = violation.get("value1", "")
                        loc2 = violation.get("location2", "")
                        val2 = violation.get("value2", "")
                        structured_feedback += f"- **{entity}**: 在 '{loc1}' 中为 '{val1}'，但在 '{loc2}' 中为 '{val2}' (矛盾!)\n"
                    structured_feedback += "\n"

                # 🆕 提取禁止模式和必需模式
                forbidden_patterns = result.get("forbidden_patterns", [])
                required_patterns = result.get("required_patterns", [])

                if forbidden_patterns:
                    structured_feedback += "### ❌ 禁止使用的模式:\n\n"
                    for pattern in forbidden_patterns:
                        structured_feedback += f"- {pattern}\n"
                    structured_feedback += "\n"

                if required_patterns:
                    structured_feedback += "### ✅ 必须遵循的模式:\n\n"
                    for pattern in required_patterns:
                        structured_feedback += f"- {pattern}\n"
                    structured_feedback += "\n"

                # 🆕 NEW: 根据错误严重性决定是否拒绝
                if error_severity == "MINOR":
                    structured_feedback += "### ℹ️ 决策: ACCEPT with warnings\n\n"
                    structured_feedback += "虽然存在小问题,但不影响整体质量,建议接受并继续。\n"
                    # MINOR 错误不打回,返回 True 但附带警告
                    return True, structured_feedback

                # 根据问题类型提供针对性建议 (降低优先级,放在最后)
                structured_feedback += "### 💡 针对性建议:\n\n"

                if any("坐标" in str(issue) or "越界" in str(issue) for issue in issues):
                    structured_feedback += "🎯 **坐标越界问题**: 请检查所有坐标是否在画布范围内，建议先画ASCII棋盘再提取坐标。\n"

                if any("重叠" in str(issue) or "间距" in str(issue) for issue in issues):
                    structured_feedback += "🎯 **点位重叠问题**: 请增加元素间距，确保每个元素有足够的空间，避免视觉遮挡。\n"

                if any("逻辑" in str(issue) or "矛盾" in str(issue) or "不通" in str(issue) for issue in issues):
                    structured_feedback += "🎯 **逻辑不通问题**: 请检查数据规格和逻辑内核是否一致，确保问题有唯一解或明确的答案。\n"

                structured_feedback += f"\n**🚨 CRITICAL**: 只修正上述问题,保留所有正确的字段!\n"

                return False, structured_feedback

            return True, None
            
        except Exception as e:
            # 审计失败时默认通过（避免阻塞流程）
            print(f"⚠️ Stage 1 Audit Error: {e}")
            return True, None
    
    # ========================================================================
    # 阶段 2 审计：VisualSpecifier 设计审计
    # ========================================================================
    def audit_stage2_visual(
        self,
        visual_spec: str,  # 🔧 改为字符串类型
        concept_design: dict,
        seed_image_paths: List[str]
    ) -> Tuple[bool, Optional[str]]:
        """
        阶段 2 审计：对 VisualSpecifier 的设计审计

        身份：视觉传达与空间几何专家

        审查重点：
        1. 逻辑映射：视觉形式能否精准表达数学逻辑？
        2. 空间防遮挡：坐标位置是否会导致元素重叠？
        3. 视觉纯净度：是否混入了文字描述？
        4. 形式创新性：视觉形式是否真的与种子题迥异？

        Args:
            visual_spec: VisualSpecifier 的输出
            concept_design: ConceptDesigner 的输出
            seed_image_paths: 种子题图片路径列表

        Returns:
            (pass_check, feedback)
        """
        sys_prompt = (
            "You are a **Visual Communication and Spatial Geometry Expert** conducting Stage 2 Audit.\n\n"
            "## 🎯 Your Mission\n\n"
            "Audit the **visual design quality and logic-to-visual translation accuracy**.\n\n"
            "## 📋 Audit Checklist\n\n"
            "### 1. Logic Mapping (逻辑映射)\n"
            "- **Question**: Can the chosen visual form (e.g., gears, balance) accurately express the mathematical logic?\n"
            "- **Check for**:\n"
            "  - Visual metaphor mismatch (视觉隐喻不匹配)\n"
            "  - Logic lost in translation (逻辑翻译丢失)\n"
            "  - Ambiguous visual representation (视觉表达模糊)\n\n"
            "### 2. Design Completeness (设计完整性) - RELAXED STANDARDS\n"
            "- **Question**: Does the specification provide sufficient design details for Painter?\n"
            "- **RECOMMENDED (NOT MANDATORY)**:\n"
            "  1. Canvas size is helpful but NOT required (Painter can use default 12x12)\n"
            "  2. Coordinates are helpful but NOT required (Painter can auto-layout)\n"
            "  3. Element descriptions should be clear and specific\n"
            "- **ONLY REJECT if**:\n"
            "  - Design is completely vague (e.g., 'draw some shapes')\n"
            "  - Missing critical element descriptions (e.g., 'draw objects' without specifying what)\n"
            "  - Contradictory design instructions (e.g., 'place A at center' and 'place A at corner')\n"
            "- **ACCEPT**: Designs with general layout descriptions (Painter will handle specifics)\n\n"
            "### 3. Design Feasibility (设计可行性) - TRUST PAINTER\n"
            "- **Philosophy**: Stage 2 focuses on DESIGN INTENT, not implementation details\n"
            "- **Question**: Is the design conceptually sound and implementable?\n"
            "- **DO NOT CHECK**:\n"
            "  - Exact coordinate calculations (Painter will handle this)\n"
            "  - Element spacing calculations (Painter will auto-adjust)\n"
            "  - Canvas boundary checks (Painter will ensure elements fit)\n"
            "- **ONLY CHECK**:\n"
            "  - Design logic makes sense (e.g., 'balance scale' for weight comparison)\n"
            "  - Element relationships are clear (e.g., 'A connects to B')\n"
            "  - No impossible requirements (e.g., '100 elements on 5x5 canvas')\n\n"
            "### 4. Visual Purity (视觉纯净度)\n"
            "- **Question**: Is the design pure visual (no question text in image)?\n"
            "- **Check for**:\n"
            "  - Question text in specification (规格中包含题目文字)\n"
            "  - Instructions in image (图中包含指令)\n"
            "  - Excessive text annotations (过多文字标注)\n\n"
            "### 5. Form Innovation (形式创新性)\n"
            "- **Question**: Is the visual form DRASTICALLY DIFFERENT from the seed question?\n"
            "- **Check for**:\n"
            "  - Same visual structure (相同视觉结构)\n"
            "  - Minor variations only (仅微小变化)\n"
            "  - Lack of creative thinking (缺乏创意思维)\n\n"
            "## 🚨 Rejection Criteria (RELAXED - TRUST PAINTER)\n\n"
            "**MUST REJECT ONLY if**:\n"
            "1. **Data Drift Detected** (HIGHEST PRIORITY):\n"
            "   - Any locked field value modified from Agent 1's specification\n"
            "   - Example: Agent 1 says '4 targets' but Agent 2 specifies '3 targets'\n"
            "2. **Design Completely Vague**:\n"
            "   - No clear element descriptions (e.g., 'draw something')\n"
            "   - Missing critical design intent (e.g., 'show relationship' without specifying how)\n"
            "3. **Visual Form Mismatch**:\n"
            "   - Visual form fundamentally doesn't match logic\n"
            "   - Question text found in specification (pure visual violated)\n"
            "4. **Lack of Innovation**:\n"
            "   - Visual form identical or highly similar to seed question\n\n"
            "**DO NOT REJECT for** (Painter will handle these):\n"
            "- Missing canvas size (Painter uses default 12x12)\n"
            "- Missing exact coordinates (Painter will auto-layout)\n"
            "- Potential spacing issues (Painter will adjust)\n"
            "- Potential overlap concerns (Painter will prevent)\n"
            "- Edge margin concerns (Painter will ensure fit)\n\n"
            "**ACCEPT (Minor Issues)**:\n"
            "- Slight visual style variations\n"
            "- Non-critical annotation placement adjustments\n\n"
            "## 📤 Output Format\n\n"
            "Return a JSON object:\n"
            "```json\n"
            "{\n"
            "  \"pass_audit\": true/false,\n"
            "  \"audit_score\": 1-10,\n"
            "  \"feedback\": \"Brief diagnosis (1-2 sentences)\",\n"
            "  \"issues_found\": [\"Issue 1\", \"Issue 2\"],\n"
            "  \"layout_conflicts\": [\"Specific conflict with coordinates\"],\n"
            "  \"data_drift_violations\": [\n"
            "    {\"locked_field\": \"target_count\", \"locked_value\": \"4\", \"actual_value\": \"3\", \"severity\": \"critical\"},\n"
            "    {\"locked_field\": \"object_A_weight\", \"locked_value\": \"5kg\", \"actual_value\": \"6kg\", \"severity\": \"critical\"}\n"
            "  ],\n"
            "  \"correction_instructions\": [\n"
            "    \"SPECIFIC instruction: e.g., 'Move Element B from (2.5, 5) to (3.0, 5) to ensure 0.2+ units spacing'\",\n"
            "    \"SPECIFIC calculation: e.g., 'Canvas: 12x10, Element radius: 0.4, Label: 0.6, Min spacing: 0.2, Min margin: 0.3'\",\n"
            "    \"DATA CONSISTENCY: e.g., 'Change target count from 3 to 4 to match Agent 1 locked_data_fields'\"\n"
            "  ],\n"
            "  \"canvas_completeness_check\": {\n"
            "    \"canvas_size_specified\": true/false,\n"
            "    \"all_elements_have_coordinates\": true/false,\n"
            "    \"coordinates_within_bounds\": true/false,\n"
            "    \"missing_coordinates\": [\"Element_A\", \"Element_B\"],\n"
            "    \"out_of_bounds_coordinates\": [{\"element\": \"Element_C\", \"position\": [15, 8], \"canvas\": [12, 12]}]\n"
            "  },\n"
            "  \"spatial_requirements\": {\n"
            "    \"min_spacing\": \"0.2 units (between element centers) - RELAXED\",\n"
            "    \"min_margin\": \"0.3 units (from canvas edges) - RELAXED\",\n"
            "    \"element_size\": \"radius + label width + padding\",\n"
            "    \"canvas_size\": \"MUST be explicitly specified (e.g., 12x12)\"\n"
            "  }\n"
            "}\n"
            "```\n\n"
            "**CRITICAL RULES for correction_instructions**:\n"
            "1. ❌ FORBIDDEN: \"Elements are too close\" (too vague)\n"
            "2. ✅ REQUIRED: \"Element A at (2,5), Element B at (2.3,5), distance=0.3 > 0.2 required ✅\" (specific)\n"
            "3. Must include EXACT coordinates and EXACT calculations\n"
            "4. Must show the MATH: current distance, required distance, proposed new position"
        )
        
        # 提取 locked_data_fields 用于数据一致性检查
        locked_data = concept_design.get('locked_data_fields', {})
        locked_data_str = str(locked_data) if locked_data else "N/A"

        # 🔧 visual_spec 现在是纯自然语言字符串
        user_prompt = (
            f"## 🎨 Visual Specification to Audit (Natural Language)\n\n"
            f"{visual_spec}\n\n"
            f"## 🧠 Logic Context (from ConceptDesigner)\n\n"
            f"**Core Logic**: {concept_design.get('core_logic_kernel', 'N/A')}\n\n"
            f"## 🔒 LOCKED DATA FIELDS (Reference for Verification)\n\n"
            f"**Agent 1's Locked Data**: {locked_data_str}\n\n"
            f"**CRITICAL AUDIT TASK**: Verify data consistency in Agent 2's specification\n"
            f"- Extract ALL key-value pairs from locked_data_fields\n"
            f"- For EACH locked field, verify Agent 2's specification mentions the EXACT same value\n"
            f"- Flag ANY mismatch as CRITICAL data drift\n\n"
            f"## 🔍 Your Task\n\n"
            f"Audit the visual design. Check in this order:\n"
            f"1. **PRIORITY 1**: DATA CONSISTENCY - Verify data values match locked_data_fields\n"
            f"   - Extract all locked fields from Agent 1's locked_data_fields\n"
            f"   - Verify Agent 2's specification contains the EXACT same values\n"
            f"   - Flag ANY mismatch (e.g., locked says '4 targets' but spec shows '3')\n"
            f"2. **PRIORITY 2**: DESIGN CLARITY - Is the design intent clear?\n"
            f"   - Are element descriptions specific and actionable?\n"
            f"   - Is the visual form choice appropriate for the logic?\n"
            f"   - Are there any contradictory instructions?\n"
            f"3. Does the visual form accurately represent the logic?\n"
            f"4. Is the design pure visual (no question text)?\n"
            f"5. Is the visual form truly different from the seed question?\n\n"
            f"**IMPORTANT: Trust Painter to handle layout details (canvas size, coordinates, spacing).**\n"
            f"**Focus on design intent and data consistency, not implementation specifics.**"
        )
        
        try:
            # 如果有种子图片，使用视觉模型进行对比审计
            if seed_image_paths:
                result = multi_vision_completion(
                    system_prompt=sys_prompt,
                    image_paths=seed_image_paths,
                    user_prompt=user_prompt,
                    timeout=60.0,
                    temperature=0.3,
                    json_mode=True,  # 🔧 添加 json_mode 参数
                    model=AGENT_MODELS.get("auditor")
                )
            else:
                result = chat_completion(
                    system_prompt=sys_prompt,
                    user_prompt=user_prompt,
                    json_mode=True,
                    timeout=60.0,
                    temperature=0.3,
                    model=AGENT_MODELS.get("auditor")
                )
            
            pass_audit = result.get("pass_audit", False)
            feedback = result.get("feedback", "")
            audit_score = result.get("audit_score", 5)
            issues = result.get("issues_found", [])
            layout_conflicts = result.get("layout_conflicts", [])
            
            self.audit_history.append({
                "stage": "Stage2_Visual",
                "pass": pass_audit,
                "score": audit_score,
                "issues": issues,
                "layout_conflicts": layout_conflicts
            })
            
            if not pass_audit:
                conflict_info = "\n".join([f"  - {c}" for c in layout_conflicts]) if layout_conflicts else ""
                return False, f"❌ Stage 2 Audit Failed (Score: {audit_score}/10)\n\n{feedback}\n\n**Layout Conflicts**:\n{conflict_info}"
            
            return True, None
            
        except Exception as e:
            print(f"⚠️ Stage 2 Audit Error: {e}")
            return True, None
    
    # ========================================================================
    # 阶段 3 审计：Painter 图像质量审计
    # ========================================================================
    def audit_stage3_image(
        self,
        image_path: str,
        visual_spec: str,  # 🔧 改为字符串类型
        python_code: str
    ) -> Tuple[bool, Optional[str]]:
        """
        阶段 3 审计：对 Painter 的图像质量审计（增强版）

        身份：图像质量控制员（QC）

        审查重点（严格检查）：
        1. 渲染完整性：5个要素是否全部正确绘制？
        2. 视觉可读性：线条、颜色、标注是否清晰？
        3. 合规性检查：是否有多余元素或Bug？
        4. 🚨 严重问题检测：大面积重叠、元素缺失、图片损坏等

        Args:
            image_path: 生成的图片路径
            visual_spec: VisualSpecifier 的输出
            python_code: Painter 生成的代码

        Returns:
            (pass_check, feedback)
        """
        sys_prompt = (
            "You are an **EXTREMELY STRICT Image Quality Control Officer (QC)** conducting Stage 3 Audit.\n\n"
            "## 🎯 Your Mission\n\n"
            "Audit the **generated image quality and specification compliance** with ZERO TOLERANCE for flaws.\n\n"
            "## 📋 Audit Checklist\n\n"
            "### 1. Rendering Completeness (渲染完整性)\n"
            "- **Question**: Are all 5 required elements correctly rendered?\n"
            "  1. Graphic Elements (图形元素)\n"
            "  2. Layout (布局方式)\n"
            "  3. Coordinates (坐标位置)\n"
            "  4. Color Scheme (配色方案)\n"
            "  5. Annotations (标注内容)\n"
            "- **Check for**:\n"
            "  - Missing elements (元素缺失)\n"
            "  - Incorrect positions (位置错误)\n"
            "  - Wrong colors (颜色错误)\n\n"
            "### 2. Visual Readability (视觉可读性) - IMAGE-BASED VALIDATION (EXTREMELY STRICT)\n"
            "- **Question**: Is the ACTUAL generated image clear, professional, and completely free from overlapping or occlusion?\n"
            "- **CRITICAL**: Analyze the ACTUAL IMAGE, not the specification!\n"
            "- **VISUAL CHECKS** (based on what you SEE in the image):\n"
            "  1. **Element Visibility**: Can you clearly see all main elements in the image?\n"
            "  2. **🚨 Actual Overlapping & Occlusion (CRITICAL)**: Are elements VISUALLY overlapping, touching, or covering each other?\n"
            "     - **ZERO TOLERANCE FOR OVERLAP**: Even the slightest overlap or touching of text/shapes MUST BE REJECTED.\n"
            "     - All labels MUST have clear spacing from graphics to avoid any visual confusion.\n"
            "  3. **Label Readability**: Are labels/annotations completely clear and highly readable?\n"
            "  4. **Canvas Fit**: Are elements completely within the canvas without touching the edges?\n"
            "  5. **Professional Quality**: Does the image look professional and crystal clear?\n"
            "  6. **🚨 Image Integrity**: Is the image file valid and high quality?\n"
            "- **MUST REJECT and SCORE < 5 if**:\n"
            "  - 🚨 **ANY OVERLAPPING OR OCCLUSION**: Elements touching, overlapping, or occluding each other in any way. Text unreadable.\n"
            "  - 🚨 **CRITICAL ELEMENTS MISSING**: Main graphics or data points are absent.\n"
            "  - 🚨 **IMAGE CORRUPTED or UNCLEAR**: Image file is damaged, blurry, or difficult to read.\n"
            "  - Elements are clipped by canvas edges.\n\n"
            "### 3. Compliance Check (合规性检查)\n"
            "- **Question**: Are there any unwanted elements or bugs?\n"
            "- **Check for**:\n"
            "  - Extra axis ticks (多余坐标刻度)\n"
            "  - Unnecessary legends (不必要图例)\n"
            "  - Text watermarks (文字水印)\n"
            "  - Code rendering errors (代码渲染错误)\n\n"
            "## 🚨 Rejection Criteria (EXTREMELY STRICT)\n\n"
            "**MUST REJECT AND SCORE VERY LOW (< 5) if**:\n"
            "1. 🚨 **ANY OVERLAPPING / OCCLUSION**: Elements covering each other even slightly, text overlapping shapes or other text.\n"
            "2. 🚨 **LACK OF CLARITY**: Any part of the image is blurry, hard to distinguish, or confusing.\n"
            "3. 🚨 **CRITICAL ELEMENTS MISSING**: Main graphics or data completely absent.\n"
            "4. Code rendering completely failed (no image generated).\n\n"
            "**ACCEPT (Minor Issues)**:\n"
            "- Slightly thin lines or minor visual imperfections\n"
            "- Minor annotation misalignment (< 0.5 units off)\n"
            "- Slight element proximity to edges (margin > 0.3 units)\n"
            "- Non-critical rendering artifacts\n\n"
            "## 📤 Output Format\n\n"
            "Return a JSON object:\n"
            "```json\n"
            "{\n"
            "  \"pass_audit\": true/false,\n"
            "  \"audit_score\": 1-10,\n"
            "  \"feedback\": \"Brief diagnosis (1-2 sentences)\",\n"
            "  \"missing_elements\": [\"Element 1 with expected position\", ...],\n"
            "  \"quality_issues\": [\"Issue 1 with specific metric\", ...],\n"
            "  \"correction_instructions\": [\n"
            "    \"SPECIFIC code fix: e.g., 'Line 15: Change plt.text(x, y, label) to plt.text(x, y+0.3, label, ha=center)'\",\n"
            "    \"SPECIFIC parameter: e.g., 'Add linewidth=2 to all plt.plot() calls for better visibility'\"\n"
            "  ],\n"
            "  \"code_line_fixes\": [\n"
            "    {\"line\": 15, \"current\": \"plt.text(x, y, label)\", \"fixed\": \"plt.text(x, y+0.3, label, ha='center')\"}\n"
            "  ]\n"
            "}\n"
            "```\n\n"
            "**CRITICAL RULES for correction_instructions**:\n"
            "1. ❌ FORBIDDEN: \"Image quality is poor\" (too vague)\n"
            "2. ✅ REQUIRED: \"Line 12: Add linewidth=2.5 to plt.plot() for thicker lines\" (specific)\n"
            "3. Must reference EXACT line numbers or function calls\n"
            "4. Must provide EXACT code snippets (copy-paste ready)"
        )
        
        # 🔧 visual_spec 现在是纯自然语言字符串
        visual_spec_truncated = visual_spec[:1000] if isinstance(visual_spec, str) else str(visual_spec)[:1000]
        python_code_str = str(python_code) if python_code is not None else ''
        python_code_truncated = python_code_str[:1500] if isinstance(python_code_str, str) else ''

        user_prompt = (
            f"## 🖼️ Generated Image to Audit\n\n"
            f"**Image Path**: {image_path}\n\n"
            f"## 📐 Visual Specification (Expected - Natural Language)\n\n"
            f"{visual_spec_truncated}\n\n"
            f"## 💻 Python Code (for reference)\n\n"
            f"```python\n{python_code_truncated}\n```\n\n"
            f"## 🔍 Your Task\n\n"
            f"Audit the generated image. Check:\n"
            f"1. Are all required elements (graphics, layout, coordinates, colors, annotations) present?\n"
            f"2. Is the image clear and readable?\n"
            f"3. Are there any rendering errors or unwanted elements?\n\n"
            f"**Be thorough but practical. Minor imperfections are acceptable.**"
        )
        
        try:
            result = vision_completion(
                system_prompt=sys_prompt,
                image_path=image_path,
                user_prompt=user_prompt,
                timeout=60.0,
                temperature=0.1,  # 🔧 降低温度至0.1让模型在审计时保持极其稳定和严格的态度
                model=AGENT_MODELS.get("auditor")
            )

            pass_audit = result.get("pass_audit", False)
            feedback = result.get("feedback", "")
            audit_score = result.get("audit_score", 5)
            missing = result.get("missing_elements", [])
            quality_issues = result.get("quality_issues", [])

            self.audit_history.append({
                "stage": "Stage3_Image",
                "pass": pass_audit,
                "score": audit_score,
                "missing_elements": missing,
                "quality_issues": quality_issues
            })

            # 🔧 提高分数阈值，低于 8 分直接打回
            if not pass_audit or audit_score < 8:
                missing_info = "\n".join([f"  - {m}" for m in missing]) if missing else "None"
                quality_info = "\n".join([f"  - {q}" for q in quality_issues]) if quality_issues else "None"
                return False, (
                    f"❌ Stage 3 Audit Failed (Score: {audit_score}/10)\n\n"
                    f"{feedback}\n\n"
                    f"**Missing Elements**:\n{missing_info}\n\n"
                    f"**Quality Issues**:\n{quality_info}\n\n"
                    f"**Requirement**: Score must be >= 8 to pass. Please rigorously fix all overlapping and clarify all visuals."
                )
            
            return True, None
            
        except Exception as e:
            print(f"⚠️ Stage 3 Audit Error: {e}")
            return True, None
    
    # ========================================================================
    # 阶段 4 审计：QA Generator 图文一致性审计
    # ========================================================================
    def audit_stage4_qa(
        self,
        qa_result: dict,
        image_path: str,
        concept_design: dict,
        visual_spec: str  # 🔧 改为字符串类型
    ) -> Tuple[bool, Optional[str]]:
        """
        阶段 4 审计：对 QA Generator 的图文一致性审计（增强版）

        身份：资深教研员/终审总编

        审查重点（严格检查）：
        1. 图文一致性：题目文字与图片实际元素是否完全对应？
        2. 解题逻辑严谨性：分步解题步骤是否逻辑清晰？
        3. 难度适配性：最终题目难度是否符合设定？
        4. 🚨 再次检查图片质量：确保图片无严重问题（重叠、缺失等）
        5. 🚨 答案正确性：验证答案是否与图片和逻辑一致

        Args:
            qa_result: QA Generator 的输出
            image_path: 生成的图片路径
            concept_design: ConceptDesigner 的输出
            visual_spec: VisualSpecifier 的输出

        Returns:
            (pass_check, feedback)
        """
        sys_prompt = (
            "You are an **EXTREMELY STRICT Senior Educational Researcher / Chief Editor** conducting Stage 4 Audit.\n\n"
            "## 🎯 Your Mission\n\n"
            "Audit the **text-image consistency and overall question quality** with ZERO TOLERANCE for any errors. Any flaw MUST result in a very low score (< 5) and rejection.\n\n"
            "## 📋 Audit Checklist\n\n"
            "### 1. Text-Image Consistency (图文一致性) - ABSOLUTE PERFECTION REQUIRED\n"
            "- **Question**: Does the question text ABSOLUTELY PERFECTLY match the actual image content?\n"
            "- **Check for**:\n"
            "  - Number mismatch (e.g., text says 5 apples, image shows 4)\n"
            "  - Direction mismatch (e.g., text says clockwise, image shows counterclockwise)\n"
            "  - Element mismatch (e.g., text mentions circles, image has squares)\n"
            "  - Position mismatch (e.g., text says \"top\", image shows \"bottom\")\n"
            "  - 🚨 **Image Quality Re-check**: Verify image has absolutely NO overlapping, occluded, or missing elements. The image MUST BE crystal clear and perfectly correspond to the text.\n\n"
            "### 2. Solution Logic Rigor (解题逻辑严谨性) - 100% CORRECTNESS REQUIRED\n"
            "- **Question**: Are the solution steps logically flawless and mathematically accurate?\n"
            "- **Check for**:\n"
            "  - Missing steps (步骤缺失)\n"
            "  - Calculation errors (计算错误)\n"
            "  - Logic jumps (逻辑跳跃)\n"
            "  - Unclear reasoning (推理不清)\n\n"
            "### 3. Difficulty Alignment (难度适配性)\n"
            "- **Question**: Does the final question match the required difficulty?\n"
            "- **Check for**:\n"
            "  - Too simple for \"difficult\" setting (困难题过于简单)\n"
            "  - Too complex for \"simple\" setting (简单题过于复杂)\n"
            "  - Step count mismatch (步骤数量不匹配)\n\n"
            "## 🚨 Rejection Criteria (MUST REJECT AND SCORE < 5 IF ANY FLAW EXISTS)\n\n"
            "**MUST REJECT and give LOW SCORE if** (CRITICAL issues):\n"
            "1. 🚨 **IMAGE QUALITY ISSUES** (Re-check from Stage 3):\n"
            "   - ANY overlapping or occlusion: Elements touching or covering each other even slightly\n"
            "   - ANY unreadable text or numbers\n"
            "   - Critical elements missing: Main graphics or data points absent\n"
            "2. 🚨 **TEXT-IMAGE MISMATCH** (CRITICAL):\n"
            "   - ANY mismatch between the text description and the image visuals\n"
            "   - The image contains elements not mentioned in the text that cause confusion\n"
            "3. 🚨 **SOLUTION LOGIC ERRORS**:\n"
            "   - Solution steps contain ANY logical errors, calculation mistakes, or jumps in reasoning\n"
            "   - Steps don't lead perfectly to the stated answer\n"
            "4. 🚨 **ANSWER CORRECTNESS**:\n"
            "   - Answer is INCORRECT, ambiguous, or lacks solid proof from the steps\n"
            "5. 🚨 **DIFFICULTY MISMATCH**:\n"
            "   - Simple question with 10+ steps, or difficult with 1 step\n\n"
            "**NOTE**: Stage 4 is the FINAL checkpoint. Be EXTREMELY thorough and strict! ZERO TOLERANCE for errors.\n\n"
            "## 📤 Output Format\n\n"
            "Return a JSON object:\n"
            "```json\n"
            "{\n"
            "  \"pass_audit\": true/false,\n"
            "  \"audit_score\": 1-10,\n"
            "  \"feedback\": \"Detailed diagnosis explaining the exact flaw if rejected\",\n"
            "  \"consistency_issues\": [\"Specific mismatch with exact values\", ...],\n"
            "  \"logic_issues\": [\"Specific logic error with step number\", ...],\n"
            "  \"correction_instructions\": [\n"
            "    \"SPECIFIC text fix: e.g., 'Question text line 2: Change 顺时针 to 逆时针 to match image'\",\n"
            "    \"SPECIFIC number fix: e.g., 'Answer: Change 5 to 4 (image shows 4 apples, not 5)'\"\n"
            "  ],\n"
            "  \"text_replacements\": [\n"
            "    {\"location\": \"Question line 2\", \"wrong\": \"顺时针\", \"correct\": \"逆时针\", \"reason\": \"Image shows counterclockwise\"}\n"
            "  ]\n"
            "}\n"
            "```\n\n"
            "**CRITICAL RULES for correction_instructions**:\n"
            "1. ❌ FORBIDDEN: \"Text doesn't match image\" (too vague)\n"
            "2. ✅ REQUIRED: \"Question says '5 apples' but image shows 4. Change '5' to '4' in question text\" (specific)\n"
            "3. Must identify EXACT word/number to change\n"
            "4. Must provide EXACT replacement value\n"
            "5. Must explain WHY (reference to image content)"
        )
        
        user_prompt = (
            f"## 📝 QA Result to Audit\n\n"
            f"**Question Text**: {qa_result.get('question_text', 'N/A')}\n\n"
            f"**Answer Text**: {qa_result.get('answer_text', 'N/A')}\n\n"
            f"**Solution Steps**:\n"
        )
        
        solution_steps = qa_result.get('solution_steps', [])
        if isinstance(solution_steps, list):
            for i, step in enumerate(solution_steps, 1):
                user_prompt += f"{i}. {step}\n"
        else:
            user_prompt += f"{solution_steps}\n"
        
        user_prompt += (
            f"\n## 🧠 Logic Context\n\n"
            f"**Expected Answer**: {concept_design.get('expected_answer', 'N/A')}\n"
            f"**Core Logic**: {concept_design.get('core_logic_kernel', 'N/A')[:500]}\n\n"
            f"## 🎨 Visual Context (Natural Language)\n\n"
            f"{visual_spec[:500] if isinstance(visual_spec, str) else str(visual_spec)[:500]}\n\n"
            f"## 🔍 Your Task (ENHANCED - FINAL CHECKPOINT)\n\n"
            f"Audit the QA result comprehensively. Check in this order:\n"
            f"1. 🚨 **PRIORITY 1 - IMAGE QUALITY RE-CHECK**:\n"
            f"   - Look at the ACTUAL image carefully\n"
            f"   - Are there any severe overlapping issues? (elements covering each other)\n"
            f"   - Are all critical elements visible and clear?\n"
            f"   - Is the image professional and readable?\n"
            f"2. **TEXT-IMAGE CONSISTENCY**:\n"
            f"   - Does the question text accurately describe what's in the image?\n"
            f"   - Do numbers, directions, positions match?\n"
            f"3. **SOLUTION LOGIC**:\n"
            f"   - Are the solution steps logically sound and complete?\n"
            f"   - Do the steps lead to the stated answer?\n"
            f"4. **ANSWER CORRECTNESS**:\n"
            f"   - Is the answer correct based on the image?\n"
            f"   - Does it match the expected answer from concept design?\n"
            f"5. **DIFFICULTY MATCH**:\n"
            f"   - Does the difficulty match the requirement?\n\n"
            f"**🚨 CRITICAL: This is the FINAL checkpoint before quality rating.**\n"
            f"**If you find ANY severe issues (especially image quality problems), REJECT immediately!**"
        )
        
        try:
            result = vision_completion(
                system_prompt=sys_prompt,
                image_path=image_path,
                user_prompt=user_prompt,
                timeout=60.0,
                temperature=0.1,  # 🔧 降低温度至0.1保持严格的审计态度
                model=AGENT_MODELS.get("auditor")
            )

            pass_audit = result.get("pass_audit", False)
            feedback = result.get("feedback", "")
            audit_score = result.get("audit_score", 5)
            consistency_issues = result.get("consistency_issues", [])
            logic_issues = result.get("logic_issues", [])

            self.audit_history.append({
                "stage": "Stage4_QA",
                "pass": pass_audit,
                "score": audit_score,
                "consistency_issues": consistency_issues,
                "logic_issues": logic_issues
            })

            # 🔧 提高审计标准，低于 8 分直接打回
            if not pass_audit or audit_score < 8:
                consistency_info = "\n".join([f"  - {c}" for c in consistency_issues]) if consistency_issues else "None"
                logic_info = "\n".join([f"  - {l}" for l in logic_issues]) if logic_issues else "None"
                return False, (
                    f"❌ Stage 4 Audit Failed (Score: {audit_score}/10)\n\n"
                    f"{feedback}\n\n"
                    f"**Consistency Issues**:\n{consistency_info}\n\n"
                    f"**Logic Issues**:\n{logic_info}\n\n"
                    f"**Requirement**: Score must be >= 8 to pass. Please rigorously fix all consistency and logic issues."
                )
            
            return True, None
            
        except Exception as e:
            print(f"⚠️ Stage 4 Audit Error: {e}")
            return True, None
    
    # ========================================================================
    # 最终评分：综合质量评分（保留原职能）
    # ========================================================================
    def final_quality_rating(
        self,
        concept_design: dict,
        visual_spec: dict,
        qa_result: dict,
        image_path: str,
        difficulty: str
    ) -> dict:
        """
        最终质量评分（保留 Agent 5 原有职能）
        
        在所有阶段审计通过后，进行综合质量评分
        
        Args:
            concept_design: ConceptDesigner 的输出
            visual_spec: VisualSpecifier 的输出
            qa_result: QA Generator 的输出
            image_path: 生成的图片路径
            difficulty: 难度要求
        
        Returns:
            Dictionary containing quality_score, feedback, pass_check
        """
        # 规则检查（30%权重）
        rule_score = self._rule_based_check(concept_design, visual_spec, qa_result, image_path, difficulty)
        
        # LLM 评估（70%权重）
        llm_score = self._llm_based_rating(concept_design, visual_spec, qa_result, image_path, difficulty)
        
        # 加权平均
        final_score = rule_score * 0.3 + llm_score * 0.7
        final_score = max(1, min(10, round(final_score, 1)))
        
        # 生成审计摘要
        audit_summary = self._generate_audit_summary()
        
        return {
            "quality_score": final_score,
            "rule_score": rule_score,
            "llm_score": llm_score,
            "pass_check": final_score >= 6,
            "audit_summary": audit_summary,
            "evaluation_focus": "Full-process audit passed + Comprehensive quality rating"
        }
    
    def _rule_based_check(
        self,
        concept_design: dict,
        visual_spec: dict,
        qa_result: dict,
        image_path: str,
        difficulty: str
    ) -> float:
        """规则检查，返回评分（1-10）"""
        score = 10.0
        
        # 图片质量检查
        try:
            import os
            from PIL import Image
            
            if os.path.exists(image_path):
                file_size = os.path.getsize(image_path)
                if file_size < 5 * 1024:
                    score -= 2
                elif file_size < 20 * 1024:
                    score -= 1
                
                try:
                    img = Image.open(image_path)
                    width, height = img.size
                    if width < 600 or height < 400:
                        score -= 1
                except:
                    pass
            else:
                score -= 3
        except:
            pass
        
        # 创新性检查
        design_rationale = str(concept_design.get("design_rationale", "")).lower()
        # 🔧 visual_spec 现在是字符串，直接转小写
        visual_rationale = visual_spec.lower() if isinstance(visual_spec, str) else ""
        
        innovation_keywords = [
            "logic", "kernel", "visual", "different", "innovation", "distinct",
            "creative", "novel", "unique", "contrast", "drastically", "completely"
        ]
        innovation_count = sum(1 for kw in innovation_keywords if kw in design_rationale or kw in visual_rationale)
        
        if innovation_count >= 5:
            score += 1
        elif innovation_count < 3:
            score -= 1
        
        # 完整性检查
        question_text = qa_result.get("question_text", "")
        answer_text = qa_result.get("answer_text", "")
        solution_steps = qa_result.get("solution_steps", [])
        
        if len(question_text) < 30:
            score -= 0.5
        if len(answer_text) < 5:
            score -= 0.5
        if isinstance(solution_steps, list) and len(solution_steps) < 2:
            score -= 1
        
        return max(1, min(10, score))
    
    def _llm_based_rating(
        self,
        concept_design: dict,
        visual_spec: dict,
        qa_result: dict,
        image_path: str,
        difficulty: str
    ) -> float:
        """LLM 评估，返回评分（1-10）"""
        sys_prompt = (
            "You are an EXTREMELY STRICT quality evaluation expert. Rate the question quality from these dimensions, applying SEVERE penalties for any flaws:\n\n"
            "## 📊 Scoring Dimensions (Total 10 points)\n\n"
            "1. **Image Quality & Clarity (3 points)**:\n"
            "   - Layout: ABSOLUTELY NO overlapping or occluded elements, clear spacing, professional arrangement.\n"
            "   - Visual: Pure visual representation (no question text).\n"
            "   - Aesthetics: Professional colors, clear graphics, highly readable labels.\n"
            "   - 🚨 PENALTY: If there is ANY overlap, occlusion, or unclarity, score 0 here.\n\n"
            "2. **Text-Image Consistency (2 points)**:\n"
            "   - Question description PERFECTLY matches image. No contradictions.\n"
            "   - 🚨 PENALTY: Any mismatch means score 0 here.\n\n"
            "3. **Logic & Answer Correctness (3 points)**:\n"
            "   - Sufficient conditions to solve. Unique answer, no ambiguity.\n"
            "   - Answer and solution steps are ABSOLUTELY correct without any logic/calculation errors.\n"
            "   - 🚨 PENALTY: Any logic hole, calculation error, or wrong answer means score 0 here.\n\n"
            "4. **Innovation & Difficulty (2 points)**:\n"
            "   - Matches the required difficulty level and has acceptable innovation.\n\n"
            "**CRITICAL RULE**: If you detect ANY image occlusion, ANY text-image mismatch, or ANY logic/calculation error, the total score MUST be set below 5 to strictly reject the output.\n\n"
            "Return a JSON object with:\n"
            "```json\n"
            "{\n"
            "  \"total_score\": 1-10,\n"
            "  \"dimension_scores\": {\n"
            "    \"image_quality\": 0-3,\n"
            "    \"consistency\": 0-2,\n"
            "    \"logic_correctness\": 0-3,\n"
            "    \"innovation_difficulty\": 0-2\n"
            "  },\n"
            "  \"feedback\": \"Detailed evaluation justifying the score\"\n"
            "}\n"
            "```"
        )
        
        user_prompt = (
            f"## 📊 Question to Rate\n\n"
            f"**Difficulty**: {difficulty}\n\n"
            f"**Question**: {qa_result.get('question_text', 'N/A')[:500]}\n\n"
            f"**Answer**: {qa_result.get('answer_text', 'N/A')}\n\n"
            f"**Visual Specification**: {visual_spec[:200] if isinstance(visual_spec, str) else 'N/A'}...\n\n"
            f"Please rate this question comprehensively."
        )
        
        try:
            result = vision_completion(
                system_prompt=sys_prompt,
                image_path=image_path,
                user_prompt=user_prompt,
                timeout=60.0,
                temperature=0.5,
                model=AGENT_MODELS.get("auditor")
            )
            
            total_score = result.get("total_score", 7)
            return max(1, min(10, float(total_score)))
            
        except Exception as e:
            print(f"⚠️ LLM Rating Error: {e}")
            return 7.0
    
    def _generate_audit_summary(self) -> str:
        """生成审计摘要"""
        if not self.audit_history:
            return "No audit history available."
        
        summary_lines = ["## 🔍 Full-Process Audit Summary\n"]
        
        for record in self.audit_history:
            stage = record.get("stage", "Unknown")
            passed = record.get("pass", False)
            score = record.get("score", 0)
            status = "✅ PASSED" if passed else "❌ FAILED"
            
            summary_lines.append(f"- **{stage}**: {status} (Score: {score}/10)")
        
        return "\n".join(summary_lines)
    
    def clear_history(self):
        """清空审计历史（用于新题目）"""
        self.audit_history = []

