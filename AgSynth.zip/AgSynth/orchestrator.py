"""
orchestrator.py
Orchestrator for multi-agent collaboration (4+1 Architecture)
"""
import os
import re
import traceback
from typing import Dict, Any, Optional, List

from agents import (
    ConceptDesignerAgent,
    VisualSpecifierAgent,
    PainterAgent,
    QAGeneratorAgent,
    QualityRaterAgent
)
from audit_agent import FullProcessAuditorAgent


class Orchestrator:
    """
    Orchestrator - Coordinate 5 agents to generate questions
    """

    def __init__(self, enhancement_prompts: dict = None, use_advanced_model: bool = False, question_id: str = None):
        """
        Initialize Orchestrator

        Args:
            enhancement_prompts: Enhancement prompts from CKO (global rulebook)
            use_advanced_model: Whether to use advanced model (higher temperature + longer timeout)
            question_id: Question ID for reflection system isolation
        """
        self.enhancement_prompts = enhancement_prompts or {}
        self.use_advanced_model = use_advanced_model
        self.question_id = question_id or "default"

        # Initialize agents
        self.concept_designer = ConceptDesignerAgent(
            enhancement_prompt=self.enhancement_prompts.get("concept_designer", "")
        )
        self.visual_specifier = VisualSpecifierAgent(
            enhancement_prompt=self.enhancement_prompts.get("visual_specifier", "")
        )
        self.painter = PainterAgent(
            enhancement_prompt=self.enhancement_prompts.get("painter", "")
        )
        self.qa_generator = QAGeneratorAgent(
            enhancement_prompt=self.enhancement_prompts.get("qa_generator", "")
        )
        self.quality_rater = QualityRaterAgent()


        # 🚨 Initialize audit agent (full-process auditor)
        self.auditor = FullProcessAuditorAgent()

    def execute_python_code(self, code: str, save_path: str = None) -> None:
        """
        Execute Python code to generate image

        Args:
            code: Python code string
            save_path: Image save path

        Raises:
            Exception: If code execution fails
        """
        # 🔧 使用代码清洗器预处理代码
        from code_cleaner import preprocess_code_before_exec

        try:
            cleaned_code = preprocess_code_before_exec(code, verbose=True)
        except ValueError as e:
            # 清洗器检测到错误,直接抛出
            raise ValueError(f"Code validation failed: {e}")

        # 准备执行环境
        exec_globals = {"save_path": save_path}

        try:
            exec(cleaned_code, exec_globals)
        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}"
            raise RuntimeError(f"Code execution failed: {error_msg}\n\nCode:\n{cleaned_code[:500]}...")

    @staticmethod
    def _rule_based_concept_check(concept: dict, difficulty: str) -> Optional[str]:
        """Concept design basic check

        Returns:
        - None: Passed
        - str: Error message
        """
        required_fields = ["core_logic_kernel", "difficulty_requirements",
                          "concept_design", "expected_answer"]

        for field in required_fields:
            if field not in concept or not concept[field]:
                return f"Missing required field: {field}"

        # Check core_logic_kernel length
        if len(str(concept.get("core_logic_kernel", ""))) < 20:
            return "core_logic_kernel too short (< 20 chars)"

        # Check concept_design structure
        concept_design = concept.get("concept_design", {})
        if not isinstance(concept_design, dict):
            return "concept_design must be a dict"

        required_sub_fields = ["logic_description", "data_specifications"]
        for field in required_sub_fields:
            if field not in concept_design or not concept_design[field]:
                return f"concept_design missing field: {field}"

            # Check sub-field length
            if len(str(concept_design[field])) < 10:
                return f"concept_design.{field} too short (< 10 chars)"

        return None

    @staticmethod
    def _validate_data_consistency(concept_design: dict, visual_spec: dict) -> Optional[str]:
        """Validate data consistency between concept and visual spec

        Returns:
        - None: Passed
        - str: Error message
        """
        # Extract data from concept_design
        concept_data_specs = concept_design.get("concept_design", {}).get("data_specifications", "")

        # 🔧 visual_spec 现在是字符串，无法提取 data_values
        # 数据一致性检查已移至 audit_stage2_visual
        return None

    @staticmethod
    def _rule_based_visual_check(visual_spec) -> Optional[str]:
        """Visual specification basic check (Natural language format)

        Returns:
        - None: Passed
        - str: Error message
        """
        # 🔧 Updated: visual_spec 现在是纯自然语言字符串
        if not visual_spec or not isinstance(visual_spec, str):
            return "visual_spec must be a non-empty string"

        # Check length (must be detailed enough)
        if len(visual_spec) < 100:
            return f"visual_spec too short (< 100 chars, got {len(visual_spec)}). Must include positions, colors, and sizes."

        # Check if description contains essential information
        desc_lower = visual_spec.lower()
        essential_keywords = [
            ("position", "coordinate", "at (", "at(", "x", "y"),  # Position info
            ("color", "red", "blue", "green", "#", "rgb"),        # Color info
        ]

        missing_info = []
        for keywords in essential_keywords:
            if not any(kw in desc_lower for kw in keywords):
                missing_info.append(keywords[0])

        if missing_info:
            return f"visual_spec missing essential info: {', '.join(missing_info)}. Must specify positions and colors."

        return None

    @staticmethod
    def _rule_based_code_check(code: str) -> Optional[str]:
        """Code basic check - Simplified Version (移除所有符号检测)

        Returns:
        - None: Passed
        - str: Detailed error message with suggestions
        """
        if not code or len(code.strip()) < 50:
            return "❌ Code too short (< 50 chars)\n💡 建议: 确保生成了完整的绘图代码"

        # 🔧 检查 1: 必需语句（保留，这是功能性检查）
        if "plt.savefig" not in code:
            return "❌ Missing plt.savefig() statement\n💡 建议: 代码末尾必须包含 plt.savefig(save_path)"

        if "plt.close" not in code:
            return "❌ Missing plt.close() statement\n💡 建议: plt.savefig() 之后必须调用 plt.close() 释放内存"

        # 🔧 检查 2: 检测危险模式（保留，这会导致代码不执行）
        if "if __name__" in code:
            return "❌ Code contains 'if __name__' block (will not execute in exec())\n💡 建议: 移除 if __name__ 判断,直接编写绘图代码"

        # 🔧 已移除所有符号检测逻辑
        # - 不再检测括号匹配（validate_brackets）
        # - 不再检测未定义变量（detect_undefined_variables）
        # - 不再检测未定义函数（detect_undefined_functions）
        #
        # 原因：
        # 1. LLM 正常输出不会出现这些问题
        # 2. 强制检测反而容易误判，破坏代码结构
        # 3. 依赖 Python exec() 的异常信息反馈给 LLM，让其自我修正

        return None

    @staticmethod
    def _rule_based_qa_check(qa: dict, difficulty: str) -> Optional[str]:
        """QA basic check

        Returns:
        - None: Passed
        - str: Error message
        """
        # 🔧 字段名兼容性处理: 支持 question_text/question 和 answer_text/answer
        question = qa.get("question_text") or qa.get("question") or ""
        answer = qa.get("answer_text") or qa.get("answer") or ""
        solution_steps = qa.get("solution_steps", [])

        if not question or len(question) < 5:
            return "Question text empty or too short (< 20 chars)"

        if not answer or len(answer) < 1:
            return "Answer text empty"

        # Check solution steps
        if not solution_steps:
            return "Solution steps empty"

        # 🔧 移除字符长度限制：字符数量不再作为质量判断标准
        # 只检查 solution_steps 是否为空，不再限制长度

        return None

    # 🔧 已彻底移除幻觉值检测和修复机制
    # 原因：
    # 1. 正则 \b([1-9]\d{3,})\b 会误判十六进制颜色代码（如 #315366 → 315366）
    # 2. 正则替换会破坏代码结构，导致括号消失（如 ax.set_xlim(0, 3153) → ax.set_xlim(0, 9）
    # 3. 递归替换逻辑过于激进，可能连带删除右括号
    #
    # 新策略：
    # - 依赖 LLM 自身的逻辑能力生成合理的坐标值
    # - 通过提示词约束（如 "canvas size is 12x12"）引导 LLM
    # - 如果仍出现大数，通过重试机制让 LLM 自我修正
    # - 不再使用正则强制替换，避免破坏代码结构

    def _is_retryable_error(self, e: Exception) -> bool:
        """Check if error is retryable (network/temporary issues)

        Args:
            e: Exception object

        Returns:
            True if retryable, False otherwise
        """
        error_msg = str(e).lower()

        # Retryable errors (network/temporary issues)
        retryable_patterns = [
            "connection", "timeout", "reset by peer",
            "502", "503", "504",
            "429", "rate limit"
        ]

        for pattern in retryable_patterns:
            if pattern in error_msg:
                return True

        return False

    def run_with_retry(
        self,
        stage_name: str,
        func,
        max_attempts: int = 3,
        *args,
        **kwargs
    ) -> Any:
        """Run function with retry logic and reflection

        Args:
            stage_name: Stage name (for reflection system)
            func: Function to execute
            max_attempts: Maximum number of attempts
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Function result

        Raises:
            Exception: If all attempts fail
        """
        last_error = None

        for attempt in range(1, max_attempts + 1):
            try:
                # Execute function
                result = func(*args, **kwargs)

                return result

            except Exception as e:
                last_error = e
                error_msg = str(e)

                # Check if retryable
                if not self._is_retryable_error(e):
                    # Non-retryable error, fail immediately
                    raise Exception(f"{stage_name} failed (non-retryable): {error_msg}")

                if attempt < max_attempts:
                    print(f"⚠️ {stage_name} attempt {attempt} failed: {error_msg}")
                    print(f"⏳ Retrying ({attempt + 1}/{max_attempts})...")
                else:
                    raise Exception(f"{stage_name} failed after {max_attempts} attempts: {error_msg}")

        # Should not reach here
        raise last_error

    @staticmethod
    def _get_bool(d: Any, key: str, default: bool = False) -> bool:
        """Safely get boolean value from dict"""
        if not isinstance(d, dict):
            return default
        val = d.get(key, default)
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            return val.lower() in ("true", "yes", "1")
        return bool(val)

    @staticmethod
    def _get_str(d: Any, key: str, default: str = "") -> str:
        """Safely get string value from dict"""
        if not isinstance(d, dict):
            return default
        val = d.get(key)
        return str(val) if val is not None else default

    @staticmethod
    def _ensure_image_ok(image_path: str) -> None:
        """Ensure image file exists and is valid"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file does not exist: {image_path}")

        file_size = os.path.getsize(image_path)
        if file_size < 1024:  # Less than 1KB
            raise ValueError(f"Image file too small ({file_size} bytes): {image_path}")

    def run(
        self,
        seed_questions: List[Dict[str, Any]],
        output_image_dir: str,
        image_filename: str,
        difficulty: str,
        memory_logs_dir: str = None
    ) -> Dict[str, Any]:
        """
        Run the full pipeline

        Args:
            seed_questions: List of seed questions
            output_image_dir: Output directory for generated images
            image_filename: Image filename (e.g., "generated_question_1.png")
            difficulty: "简单" or "困难"
            memory_logs_dir: Memory logs directory (for reflection system)

        Returns:
            Dictionary containing:
            - design_detail: Concept design + Visual spec
            - qa_result: Question and answer
            - quality_score: Quality rating (1-10)
        """
        print(f"\n🎯 开始生成题目: {image_filename}")
        print(f"   难度: {difficulty}")
        print(f"   种子题数量: {len(seed_questions)}")

        # ========== Stage 1: Concept Design ==========
        def concept_design_with_check():
            concept_design = self.concept_designer.generate(
                seed_questions=seed_questions,
                difficulty=difficulty
            )

            # Rule-based pre-check
            error = self._rule_based_concept_check(concept_design, difficulty)
            if error:
                raise ValueError(f"Concept check failed: {error}")

            return concept_design

        concept_design = self.run_with_retry(
            stage_name="ConceptDesigner",
            func=concept_design_with_check,
            max_attempts=3
        )

        print(f"✅ Stage 1 完成: Concept Design")

        # ========== Stage 2: Visual Specification ==========
        def visual_spec_with_check():
            visual_spec = self.visual_specifier.generate(
                seed_questions=seed_questions,
                concept_design=concept_design,
                difficulty=difficulty
            )

            # Rule-based pre-check
            error = self._rule_based_visual_check(visual_spec)
            if error:
                raise ValueError(f"Visual spec check failed: {error}")

            # Data consistency check
            consistency_error = self._validate_data_consistency(concept_design, visual_spec)
            if consistency_error:
                raise ValueError(f"Data consistency check failed: {consistency_error}")

            # 🔧 已彻底禁用幻觉值检测和修复机制
            # 原因：
            # 1. 正则 \b([1-9]\d{3,})\b 会误判十六进制颜色代码（如 #315366 → 315366）
            # 2. 正则替换会破坏代码结构，导致括号消失（如 ax.set_xlim(0, 3153) → ax.set_xlim(0, 9）
            # 3. 递归替换逻辑过于激进，可能连带删除右括号
            # 4. 会导致代码生成到一半被截断（例如：color = '#315366' 被误判为幻觉值）
            #
            # 新策略：
            # - 完全信任 LLM 的逻辑能力生成合理的坐标值
            # - 通过提示词约束（如 "canvas size is 12x12"）引导 LLM
            # - 如果仍出现大数，通过重试机制让 LLM 自我修正
            # - 不再使用正则强制替换，避免破坏代码结构
            #
            # hallucinations = self._detect_hallucinated_values(visual_spec)
            # if hallucinations:
            #     print(f"⚠️ Detected hallucinated values: {hallucinations}")
            #     print(f"🔧 Auto-fixing hallucinated values...")
            #     visual_spec = self._fix_hallucinated_values(visual_spec)

            return visual_spec

        visual_spec = self.run_with_retry(
            stage_name="VisualSpecifier",
            func=visual_spec_with_check,
            max_attempts=3
        )

        print(f"✅ Stage 2 完成: Visual Specification")

        # ========== Stage 3: Painter (Code Generation + Execution) ==========
        def paint_with_check():
            # Generate code
            python_code = self.painter.generate_code(
                visual_spec=visual_spec,
                concept_design=concept_design
            )

            # Rule-based code check
            code_error = self._rule_based_code_check(python_code)
            if code_error:
                raise ValueError(f"Code check failed: {code_error}")

            # Execute code
            image_path = os.path.join(output_image_dir, image_filename)
            self.execute_python_code(python_code, save_path=image_path)

            # Ensure image is valid
            self._ensure_image_ok(image_path)

            return image_path, python_code

        image_path, python_code = self.run_with_retry(
            stage_name="Painter",
            func=paint_with_check,
            max_attempts=3
        )

        print(f"✅ Stage 3 完成: Painter (Image saved to {image_filename})")

        # 🚨 Stage 3 后置审计：图片质量检查
        print(f"🔍 Stage 3 后置审计: 检查图片质量...")
        audit_pass, audit_feedback = self.auditor.audit_stage3_image(
            image_path=image_path,
            visual_spec=visual_spec,
            python_code=python_code
        )

        if not audit_pass:
            print(f"❌ Stage 3 审计失败: 图片质量不合格")
            raise ValueError(f"Image quality audit failed:\n{audit_feedback}")

        print(f"✅ Stage 3 审计通过: 图片质量合格")

        # ========== Stage 4: QA Generation ==========
        def qa_with_check():
            qa = self.qa_generator.generate(
                concept_design=concept_design,
                visual_spec=visual_spec,
                difficulty=difficulty
            )

            # Rule-based QA check
            qa_error = self._rule_based_qa_check(qa, difficulty)
            if qa_error:
                raise ValueError(f"QA check failed: {qa_error}")

            return qa

        qa_result = self.run_with_retry(
            stage_name="QA_Generator",
            func=qa_with_check,
            max_attempts=3
        )

        print(f"✅ Stage 4 完成: QA Generation")

        # 🚨 Stage 4 后置审计：图文一致性检查 + 再次检查图片质量
        print(f"🔍 Stage 4 后置审计: 检查图文一致性和图片质量...")
        audit_pass, audit_feedback = self.auditor.audit_stage4_qa(
            qa_result=qa_result,
            image_path=image_path,
            concept_design=concept_design,
            visual_spec=visual_spec
        )

        if not audit_pass:
            print(f"❌ Stage 4 审计失败: 图文不一致或图片质量问题")
            raise ValueError(f"QA audit failed:\n{audit_feedback}")

        print(f"✅ Stage 4 审计通过: 图文一致且图片质量合格")

        # ========== Stage 4.5: Text Masking (让题目必须依赖图片) ==========
        from utils import rewrite_question_for_figure_dependency, validate_masked_question, MASKING_MAX_RETRIES

        original_question_text = qa_result.get("question_text") or qa_result.get("question") or ""
        print(f"🔍 Stage 4.5: 题目内容遮盖 (Text Masking)...")

        masking_success = False
        for masking_attempt in range(1, MASKING_MAX_RETRIES + 1):
            try:
                rewrite_result = rewrite_question_for_figure_dependency(original_question_text, image_path)

                if rewrite_result["already_figure_dependent"]:
                    print(f"✅ Stage 4.5: 题目已依赖图片，无需改写")
                    masking_success = True
                    break

                rewritten_question = rewrite_result["rewritten_question"]
                if not rewritten_question.strip():
                    print(f"⚠️ Stage 4.5 attempt {masking_attempt}: 改写结果为空，重试...")
                    continue

                # 获取 image_composition 用于验证
                masking_image_composition = visual_spec if isinstance(visual_spec, str) else str(visual_spec)

                is_valid, reason = validate_masked_question(
                    original_question=original_question_text,
                    rewritten_question=rewritten_question,
                    image_composition=masking_image_composition,
                )

                if is_valid:
                    # 替换 qa_result 中的题目文字
                    if "question_text" in qa_result:
                        qa_result["question_text"] = rewritten_question
                    elif "question" in qa_result:
                        qa_result["question"] = rewritten_question
                    print(f"✅ Stage 4.5: 题目遮盖成功 (attempt {masking_attempt})")
                    masking_success = True
                    break
                else:
                    print(f"⚠️ Stage 4.5 attempt {masking_attempt} 验证未通过: {reason}")

            except Exception as masking_error:
                print(f"⚠️ Stage 4.5 attempt {masking_attempt} 异常: {masking_error}")

        if not masking_success:
            print(f"⚠️ Stage 4.5: {MASKING_MAX_RETRIES}次尝试均未成功，保留原始题目文字")

        # ========== Stage 5: Quality Rating ==========
        quality_rating = self.quality_rater.rate_quality(
            seed_question=seed_questions[0] if seed_questions else {},
            concept_design=concept_design,
            visual_spec=visual_spec,
            qa=qa_result,
            image_path=image_path,
            difficulty=difficulty
        )

        quality_score = quality_rating.get("quality_rating", 7)
        print(f"✅ Stage 5 完成: Quality Rating = {quality_score}/10")

        # Return results
        return {
            "design_detail": {
                "concept_design": concept_design,
                "image_design": visual_spec  # 🔧 visual_spec 现在是字符串
            },
            "qa_result": qa_result,
            "quality_score": quality_score
        }
