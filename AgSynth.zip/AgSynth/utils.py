import os
import io
import json
import base64
import mimetypes
import logging
import re
from typing import List, Union, Dict, Any, Optional
from openai import OpenAI, APIError, APIConnectionError, RateLimitError
from PIL import Image

# --- 配置日志 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("LLMUtils")
# --- API Configuration (read from environment variables) ---
# --- 硬���码配置 (测试阶段) ---
API_KEY = os.environ.get("OPENAI_API_KEY", "your-api-key-here")
BASE_URL = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")

# --- 模型配置（支持为每个智能体指定不同模型）---
# 默认模型（请替换为你实际使用的模型名称）
DEFAULT_MODEL = "your-default-model"

# 智能体模型配置字典（可以为每个智能体指定不同的模型）
AGENT_MODELS = {
    "concept_designer": "your-agent-model",     # Agent 1: 概念设计智能体
    "visual_specifier": "your-agent-model",     # Agent 2: 视觉规格设计智能体
    "painter": "your-agent-model",              # Agent 3: 数据可视化专家
    "qa_generator": "your-agent-model",         # Agent 4: 试题文本生成器
    "quality_rater": "your-agent-model",        # Agent 5: 质量评分与审查专家
    "auditor": "your-agent-model"               # 审计智能体
}

# --- 图片缓存（避免重复编码）---
_image_cache: Dict[str, str] = {}


def get_client():
    """初始化并返回 OpenAI 客户端（优化：减少超时时间）"""
    return OpenAI(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=90.0,  # 从 120s 降低到 90s
        max_retries=2  # 从 3 次降低到 2 次
    )


def _model_supports_temperature(model_name: str) -> bool:
    """判断模型是否支持 temperature 参数（claude 系列不支持）"""
    if not model_name:
        return True
    return "claude" not in model_name.lower()


def _safe_json_parse(content: str) -> Dict[str, Any]:
    """
    安全解析 JSON，支持清洗常见格式问题

    增强功能：
    1. 支持清洗 ```json 和 ```python 代码块标签
    2. 支持正则提取 JSON 对象
    3. 支持多种格式容错
    4. 正确转义 LaTeX 公式和特殊字符
    """
    if not content:
        return {}

    # 快速路径：直接尝试解析（大多数情况下有效）
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass

    # 慢速路径：清洗后再解析
    clean_content = content.strip()

    # 方法1：移除代码块标签（```json, ```python, ```）
    if clean_content.startswith("```"):
        lines = clean_content.split('\n')
        # 移除第一行（```json 或 ```python 或 ```）
        if len(lines) > 1:
            clean_content = '\n'.join(lines[1:])
        # 移除结尾的 ```
        if clean_content.endswith("```"):
            clean_content = clean_content[:-3]
        clean_content = clean_content.strip()

    # 🔧 修复：LaTeX 公式转义处理（核心修复）
    # 策略：将所有 LaTeX 反斜杠 \ 替换为双反斜杠 \\，确保 JSON 解析正确
    #
    # 问题分析：
    # - LLM 输出：\(8 \times 7\)
    # - JSON 要求：\\(8 \\times 7\\)  （反斜杠必须转义）
    # - 如果不转义，json.loads() 会报错：invalid escape sequence
    #
    # 解决方案：
    # 1. 先保护已经正确转义的内容（如 \\n, \\t, \\", \\\\）
    # 2. 将单个反斜杠 \ 替换为双反斜杠 \\
    # 3. 恢复被保护的转义序列

    # 步骤1：保护标准 JSON 转义序列（使用占位符）
    protected_escapes = {
        r'\\n': '\x00NEWLINE\x00',
        r'\\t': '\x00TAB\x00',
        r'\\r': '\x00RETURN\x00',
        r'\\"': '\x00QUOTE\x00',
        r'\\\\': '\x00BACKSLASH\x00',
        r'\\\/': '\x00SLASH\x00',
        r'\\b': '\x00BACKSPACE\x00',
        r'\\f': '\x00FORMFEED\x00',
    }

    for escape_seq, placeholder in protected_escapes.items():
        clean_content = clean_content.replace(escape_seq, placeholder)

    # 步骤2：将所有单个反斜杠转义为双反斜杠
    # 这会处理 LaTeX 公式中的 \(, \), \times, \frac 等
    clean_content = clean_content.replace('\\', '\\\\')

    # 步骤3：恢复被保护的标准转义序列
    for escape_seq, placeholder in protected_escapes.items():
        clean_content = clean_content.replace(placeholder, escape_seq)

    # 方法2：尝试直接解析
    try:
        return json.loads(clean_content)
    except json.JSONDecodeError:
        pass

    # 方法3：正则提取 JSON 对象（支持嵌套结构）
    # 🔧 增强：使用递归正则匹配嵌套 JSON
    def extract_json_recursive(text: str) -> Optional[dict]:
        """递归提取嵌套 JSON 对象"""
        stack = []
        start_idx = -1

        for i, char in enumerate(text):
            if char == '{':
                if not stack:
                    start_idx = i
                stack.append(char)
            elif char == '}':
                if stack:
                    stack.pop()
                    if not stack and start_idx >= 0:
                        # 找到完整的 JSON 对象
                        json_str = text[start_idx:i+1]
                        try:
                            result = json.loads(json_str)
                            if isinstance(result, dict):
                                return result
                        except json.JSONDecodeError:
                            pass
                        start_idx = -1
        return None

    extracted = extract_json_recursive(clean_content)
    if extracted:
        logger.info("通过递归提取成功解析 JSON")
        return extracted

    # 方法4：尝试查找 python_code 和 code_explanation 字段（针对 Painter 输出）
    try:
        # 尝试提取关键字段
        code_match = re.search(r'"python_code"\s*:\s*"((?:[^"\\]|\\.)*)"', clean_content, re.DOTALL)
        explanation_match = re.search(r'"code_explanation"\s*:\s*"((?:[^"\\]|\\.)*)"', clean_content, re.DOTALL)

        if code_match:
            result = {
                "python_code": code_match.group(1).replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\'),
                "code_explanation": explanation_match.group(1) if explanation_match else "Code generated"
            }
            logger.info("通过字段提取成功解析 JSON")
            return result
    except Exception as e:
        logger.warning(f"字段提取失败: {e}")

    # 所有方法都失败 - 确保返回字典而不是字符串
    logger.error(f"JSON 解析失败，已尝试所有方法。内容前200字符: {content[:200]}")
    # 尝试将整个内容作为单个字段返回
    return {"error": "json_parse_failed", "raw_content": content[:500], "content": content}


def get_image_mime_type(image_path: str) -> str:
    """获取图片的 MIME 类型"""
    mime_type, _ = mimetypes.guess_type(image_path)
    if not mime_type:
        if image_path.lower().endswith('.png'):
            return "image/png"
        return "image/jpeg"
    return mime_type


def encode_image_to_base64(image_path: str, use_cache: bool = True, max_size_kb: int = 512) -> Optional[str]:
    """将图片转换为 base64 字符串，激进压缩以防止 API 400 错误

    Args:
        image_path: 图片路径
        use_cache: 是否使用缓存
        max_size_kb: 最大图片大小（KB），默认 512KB

    Returns:
        base64 编码的图片字符串

    压缩策略（激进版）：
    1. 提高 PIL 像素限制，防止解压炸弹错误
    2. 预缩放：长边超过 1024px 直接缩到 1024px 以内
    3. 像素预缩放阈值降至 500万像素（约 2236×2236）
    4. 压缩梯度从质量 70 + 缩放 0.7 起步，快速收敛到目标大小
    5. 最终兜底：长边限制 512px + 质量 20
    """
    if use_cache and image_path in _image_cache:
        return _image_cache[image_path]

    try:
        Image.MAX_IMAGE_PIXELS = 500_000_000

        img = Image.open(image_path)
        original_size = os.path.getsize(image_path) / 1024  # KB
        original_pixels = img.width * img.height

        # 第一步：像素预缩放——超过 500万像素先强制缩小
        max_pixels = 5_000_000  # 500万像素（约 2236×2236）
        if original_pixels > max_pixels:
            logger.warning(f"⚠️ 图片像素过大 ({original_pixels:,} > {max_pixels:,})，先缩放到安全尺寸...")
            scale = (max_pixels / original_pixels) ** 0.5
            new_width = int(img.width * scale)
            new_height = int(img.height * scale)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            logger.info(f"✅ 像素预缩放: {original_pixels:,}px → {new_width}×{new_height} ({img.width * img.height:,}px)")

        # 第二步：长边预缩放——长边超过 1024px 直接缩到 1024px
        max_long_edge = 1024
        long_edge = max(img.width, img.height)
        if long_edge > max_long_edge:
            scale = max_long_edge / long_edge
            new_width = int(img.width * scale)
            new_height = int(img.height * scale)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            logger.info(f"✅ 长边预缩放: 长边 {long_edge}px → {max(new_width, new_height)}px ({new_width}×{new_height})")

        # 第三步：转换为 RGB 模式（确保 JPEG 兼容）
        if img.mode in ("RGBA", "P", "LA", "L"):
            img = img.convert("RGB")

        # 第四步：激进压缩梯度——从质量 70 + 缩放 0.7 起步
        logger.info(f"开始激进压缩 (原始文件 {original_size:.1f}KB，目标 ≤{max_size_kb}KB)...")

        compression_steps = [
            (70, 1.0),
            (60, 0.8),
            (50, 0.65),
            (40, 0.5),
            (30, 0.4),
            (20, 0.3),
        ]

        for quality, scale in compression_steps:
            if scale < 1.0:
                new_width = max(1, int(img.width * scale))
                new_height = max(1, int(img.height * scale))
                resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            else:
                resized_img = img

            buffer = io.BytesIO()
            resized_img.save(buffer, format="JPEG", quality=quality, optimize=True)
            compressed_size = len(buffer.getvalue()) / 1024

            if compressed_size <= max_size_kb:
                logger.info(f"✅ 压缩成功: {original_size:.1f}KB → {compressed_size:.1f}KB (质量={quality}, 缩放={scale:.0%}, 尺寸={resized_img.width}×{resized_img.height})")
                encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
                if use_cache:
                    _image_cache[image_path] = encoded
                return encoded

        # 第五步：终极兜底——长边限制 512px + 质量 20
        logger.warning("⚠️ 使用终极兜底压缩（长边 512px + 质量 20）")
        fallback_long_edge = 512
        current_long_edge = max(img.width, img.height)
        fallback_scale = fallback_long_edge / current_long_edge
        fallback_width = max(1, int(img.width * fallback_scale))
        fallback_height = max(1, int(img.height * fallback_scale))
        fallback_img = img.resize((fallback_width, fallback_height), Image.Resampling.LANCZOS)
        buffer = io.BytesIO()
        fallback_img.save(buffer, format="JPEG", quality=20, optimize=True)
        final_size = len(buffer.getvalue()) / 1024
        logger.info(f"终极兜底结果: {final_size:.1f}KB ({fallback_width}×{fallback_height})")
        encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
        if use_cache:
            _image_cache[image_path] = encoded
        return encoded

    except FileNotFoundError:
        logger.error(f"图片文件不存在: {image_path}")
        return None
    except Exception as e:
        logger.error(f"图片编码失败: {e}")
        return None


def get_image_mime_type_for_encoded(image_path: str) -> str:
    """encode_image_to_base64 压缩后统一输出 JPEG 格式，MIME 必须匹配实际内容"""
    return "image/jpeg"


def chat_completion(system_prompt: str, user_prompt: str, json_mode: bool = True, timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 8192, model: str = None) -> Union[
    Dict[str, Any], str]:
    """
    调用大模型进行对话补全（优化版）

    Args:
        system_prompt: 系统提示词
        user_prompt: 用户提示词
        json_mode: 是否启用 JSON 模式
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 8192，确保长代码不被截断）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        JSON 模式返回字典，文本模式返回字符串
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    try:
        # 构建API参数（claude系列不支持temperature）
        api_params = dict(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            timeout=timeout,
            max_tokens=max_tokens,
            extra_body={"model": model_name}
        )
        if "claude" not in model_name.lower():
            api_params["temperature"] = temperature

        response = client.chat.completions.create(**api_params)

        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        finish_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
            # 提取 finish_reason
            if hasattr(response.choices[0], 'finish_reason'):
                finish_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # Claude 格式的 stop_reason
            if hasattr(response, 'stop_reason'):
                finish_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码（如颜色值 #315366）
        # 原因：finish_reason='length' 可能是正常结束，不应强制中断
        # if finish_reason in ['length', 'max_tokens']:
        #     logger.warning(f"⚠️ API 响应被截断（finish_reason={finish_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        if json_mode:
            return _safe_json_parse(content)
        else:
            return content

    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise


def vision_completion(system_prompt: str, image_path: str, user_prompt: str, timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 16384, json_mode: bool = True, model: str = None) -> Union[dict, str]:
    """
    调用大模型进行视觉理解（单图片）

    Args:
        system_prompt: 系统提示词
        image_path: 图片路径
        user_prompt: 用户提示词
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 16384，确保长输出不被截断）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        解析后的 JSON 字典
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    # 编码图片（自动处理 RGBA→RGB→JPEG 转换）
    base64_image = encode_image_to_base64(image_path)
    if not base64_image:
        raise ValueError(f"无法读取图片: {image_path}")

    mime_type = get_image_mime_type_for_encoded(image_path)

    try:
        # 确保 model 参数正确传递
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime_type};base64,{base64_image}"
                            }
                        },
                        {
                            "type": "text",
                            "text": user_prompt
                        }
                    ]
                }
            ],
            **({"temperature": temperature} if _model_supports_temperature(model_name) else {}),
            timeout=timeout,
            max_tokens=max_tokens,
            # 添加额外参数确保兼容性
            extra_body={"model": model_name}
        )

        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        stop_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
                # 检查是否有 finish_reason
                if hasattr(response.choices[0], 'finish_reason'):
                    stop_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # 检查 Claude 的 stop_reason
            if hasattr(response, 'stop_reason'):
                stop_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码
        # if stop_reason in ['max_tokens', 'length']:
        #     logger.warning(f"⚠️ API 响应被截断（stop_reason={stop_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        # 根据 json_mode 决定返回格式
        if json_mode:
            result = _safe_json_parse(content)
            # 确保返回的是字典
            if not isinstance(result, dict):
                logger.error(f"_safe_json_parse 返回了非字典类型: {type(result)}")
                return {"error": "invalid_response_type", "content": str(result)}
            return result
        else:
            return content  # 文本模式直接返回字符串

    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise


def multi_vision_completion(system_prompt: str, image_paths: List[str], user_prompt: str,
                             timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 16384,
                             json_mode: bool = True, model: str = None) -> Union[dict, str]:
    """
    调用大模型进行视觉理解（多图片）

    Args:
        system_prompt: 系统提示词
        image_paths: 图片路径列表
        user_prompt: 用户提示词
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 16384，确保长输出不被截断）
        json_mode: 是否启用 JSON 模式（默认 True）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        JSON 模式返回字典，文本模式返回字符串
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    # 构建内容列表
    content_list = []

    # 添加所有图片
    for image_path in image_paths:
        base64_image = encode_image_to_base64(image_path)
        if not base64_image:
            logger.warning(f"跳过无法读取的图片: {image_path}")
            continue

        mime_type = get_image_mime_type_for_encoded(image_path)
        content_list.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:{mime_type};base64,{base64_image}"
            }
        })

    # 添加文本提示
    content_list.append({
        "type": "text",
        "text": user_prompt
    })

    try:
        # 确保 model 参数正确传递
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": content_list
                }
            ],
            **({"temperature": temperature} if _model_supports_temperature(model_name) else {}),
            timeout=timeout,
            max_tokens=max_tokens,
            # 添加额外参数确保兼容性
            extra_body={"model": model_name}
        )

        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        stop_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
                # 检查是否有 finish_reason
                if hasattr(response.choices[0], 'finish_reason'):
                    stop_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # 检查 Claude 的 stop_reason
            if hasattr(response, 'stop_reason'):
                stop_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码
        # if stop_reason in ['max_tokens', 'length']:
        #     logger.warning(f"⚠️ API 响应被截断（stop_reason={stop_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        # 根据 json_mode 决定返回格式
        if json_mode:
            result = _safe_json_parse(content)
            # 确保返回的是字典
            if not isinstance(result, dict):
                logger.error(f"_safe_json_parse 返回了非字典类型: {type(result)}")
                return {"error": "invalid_response_type", "content": str(result)}
            return result
        else:
            return content  # 文本模式直接返回字符串

    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise


def get_client():
    """初始化并返回 OpenAI 客户端（优化：减少超时时间）"""
    return OpenAI(
        api_key=API_KEY,
        base_url=BASE_URL,
        timeout=90.0,  # 从 120s 降低到 90s
        max_retries=2  # 从 3 次降低到 2 次
    )


def _model_supports_temperature(model_name: str) -> bool:
    """判断模型是否支持 temperature 参数（claude 系列不支持）"""
    if not model_name:
        return True
    return "claude" not in model_name.lower()


def _safe_json_parse(content: str) -> Dict[str, Any]:
    """
    安全解析 JSON，支持清洗常见格式问题

    增强功能：
    1. 支持清洗 ```json 和 ```python 代码块标签
    2. 支持正则提取 JSON 对象
    3. 支持多种格式容错
    4. 正确转义 LaTeX 公式和特殊字符
    """
    if not content:
        return {}

    # 快速路径：直接尝试解析（大多数情况下有效）
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass

    # 慢速路径：清洗后再解析
    clean_content = content.strip()

    # 方法1：移除代码块标签（```json, ```python, ```）
    if clean_content.startswith("```"):
        lines = clean_content.split('\n')
        # 移除第一行（```json 或 ```python 或 ```）
        if len(lines) > 1:
            clean_content = '\n'.join(lines[1:])
        # 移除结尾的 ```
        if clean_content.endswith("```"):
            clean_content = clean_content[:-3]
        clean_content = clean_content.strip()

    # 🔧 修复：LaTeX 公式转义处理（核心修复）
    # 策略：将所有 LaTeX 反斜杠 \ 替换为双反斜杠 \\，确保 JSON 解析正确
    #
    # 问题分析：
    # - LLM 输出：\(8 \times 7\)
    # - JSON 要求：\\(8 \\times 7\\)  （反斜杠必须转义）
    # - 如果不转义，json.loads() 会报错：invalid escape sequence
    #
    # 解决方案：
    # 1. 先保护已经正确转义的内容（如 \\n, \\t, \\", \\\\）
    # 2. 将单个反斜杠 \ 替换为双反斜杠 \\
    # 3. 恢复被保护的转义序列

    # 步骤1：保护标准 JSON 转义序列（使用占位符）
    protected_escapes = {
        r'\\n': '\x00NEWLINE\x00',
        r'\\t': '\x00TAB\x00',
        r'\\r': '\x00RETURN\x00',
        r'\\"': '\x00QUOTE\x00',
        r'\\\\': '\x00BACKSLASH\x00',
        r'\\\/': '\x00SLASH\x00',
        r'\\b': '\x00BACKSPACE\x00',
        r'\\f': '\x00FORMFEED\x00',
    }

    for escape_seq, placeholder in protected_escapes.items():
        clean_content = clean_content.replace(escape_seq, placeholder)

    # 步骤2：将所有单个反斜杠转义为双反斜杠
    # 这会处理 LaTeX 公式中的 \(, \), \times, \frac 等
    clean_content = clean_content.replace('\\', '\\\\')

    # 步骤3：恢复被保护的标准转义序列
    for escape_seq, placeholder in protected_escapes.items():
        clean_content = clean_content.replace(placeholder, escape_seq)

    # 方法2：尝试直接解析
    try:
        return json.loads(clean_content)
    except json.JSONDecodeError:
        pass

    # 方法3：正则提取 JSON 对象（支持嵌套结构）
    # 🔧 增强：使用递归正则匹配嵌套 JSON
    def extract_json_recursive(text: str) -> Optional[dict]:
        """递归提取嵌套 JSON 对象"""
        stack = []
        start_idx = -1

        for i, char in enumerate(text):
            if char == '{':
                if not stack:
                    start_idx = i
                stack.append(char)
            elif char == '}':
                if stack:
                    stack.pop()
                    if not stack and start_idx >= 0:
                        # 找到完整的 JSON 对象
                        json_str = text[start_idx:i+1]
                        try:
                            result = json.loads(json_str)
                            if isinstance(result, dict):
                                return result
                        except json.JSONDecodeError:
                            pass
                        start_idx = -1
        return None

    extracted = extract_json_recursive(clean_content)
    if extracted:
        logger.info("通过递归提取成功解析 JSON")
        return extracted
    
    # 方法4：尝试查找 python_code 和 code_explanation 字段（针对 Painter 输出）
    try:
        # 尝试提取关键字段
        code_match = re.search(r'"python_code"\s*:\s*"((?:[^"\\]|\\.)*)"', clean_content, re.DOTALL)
        explanation_match = re.search(r'"code_explanation"\s*:\s*"((?:[^"\\]|\\.)*)"', clean_content, re.DOTALL)
        
        if code_match:
            result = {
                "python_code": code_match.group(1).replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\'),
                "code_explanation": explanation_match.group(1) if explanation_match else "Code generated"
            }
            logger.info("通过字段提取成功解析 JSON")
            return result
    except Exception as e:
        logger.warning(f"字段提取失败: {e}")

    # 所有方法都失败 - 确保返回字典而不是字符串
    logger.error(f"JSON 解析失败，已尝试所有方法。内容前200字符: {content[:200]}")
    # 尝试将整个内容作为单个字段返回
    return {"error": "json_parse_failed", "raw_content": content[:500], "content": content}


def get_image_mime_type(image_path: str) -> str:
    """获取图片的 MIME 类型"""
    mime_type, _ = mimetypes.guess_type(image_path)
    if not mime_type:
        if image_path.lower().endswith('.png'):
            return "image/png"
        return "image/jpeg"
    return mime_type




def chat_completion(system_prompt: str, user_prompt: str, json_mode: bool = True, timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 8192, model: str = None) -> Union[
    Dict[str, Any], str]:
    """
    调用大模型进行对话补全（优化版）

    Args:
        system_prompt: 系统提示词
        user_prompt: 用户提示词
        json_mode: 是否启用 JSON 模式
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 8192，确保长代码不被截断）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        JSON 模式返回字典，文本模式返回字符串
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    try:
        # 确保 model 参数正确传递
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            **({"temperature": temperature} if _model_supports_temperature(model_name) else {}),
            timeout=timeout,
            max_tokens=max_tokens,
            # 添加额外参数确保兼容性
            extra_body={"model": model_name}
        )
        
        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        finish_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
            # 提取 finish_reason
            if hasattr(response.choices[0], 'finish_reason'):
                finish_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # Claude 格式的 stop_reason
            if hasattr(response, 'stop_reason'):
                finish_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码（如颜色值 #315366）
        # 原因：finish_reason='length' 可能是正常结束，不应强制中断
        # if finish_reason in ['length', 'max_tokens']:
        #     logger.warning(f"⚠️ API 响应被截断（finish_reason={finish_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        if json_mode:
            return _safe_json_parse(content)
        else:
            return content
            
    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise


def vision_completion(system_prompt: str, image_path: str, user_prompt: str, timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 16384, json_mode: bool = True, model: str = None) -> Union[dict, str]:
    """
    调用大模型进行视觉理解（单图片）

    Args:
        system_prompt: 系统提示词
        image_path: 图片路径
        user_prompt: 用户提示词
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 16384，确保长输出不被截断）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        解析后的 JSON 字典
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    # 编码图片
    base64_image = encode_image_to_base64(image_path)
    if not base64_image:
        raise ValueError(f"无法读取图片: {image_path}")

    mime_type = get_image_mime_type_for_encoded(image_path)

    try:
        # 确保 model 参数正确传递
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime_type};base64,{base64_image}"
                            }
                        },
                        {
                            "type": "text",
                            "text": user_prompt
                        }
                    ]
                }
            ],
            **({"temperature": temperature} if _model_supports_temperature(model_name) else {}),
            timeout=timeout,
            max_tokens=max_tokens,
            # 添加额外参数确保兼容性
            extra_body={"model": model_name}
        )

        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        stop_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
                # 检查是否有 finish_reason
                if hasattr(response.choices[0], 'finish_reason'):
                    stop_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # 检查 Claude 的 stop_reason
            if hasattr(response, 'stop_reason'):
                stop_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码
        # if stop_reason in ['max_tokens', 'length']:
        #     logger.warning(f"⚠️ API 响应被截断（stop_reason={stop_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        # 根据 json_mode 决定返回格式
        if json_mode:
            result = _safe_json_parse(content)
            # 确保返回的是字典
            if not isinstance(result, dict):
                logger.error(f"_safe_json_parse 返回了非字典类型: {type(result)}")
                return {"error": "invalid_response_type", "content": str(result)}
            return result
        else:
            return content  # 文本模式直接返回字符串

    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise


def multi_vision_completion(system_prompt: str, image_paths: List[str], user_prompt: str,
                             timeout: float = 120.0, temperature: float = 1.0, max_tokens: int = 16384,
                             json_mode: bool = True, model: str = None) -> Union[dict, str]:
    """
    调用大模型进行视觉理解（多图片）

    Args:
        system_prompt: 系统提示词
        image_paths: 图片路径列表
        user_prompt: 用户提示词
        timeout: 超时时间（秒）
        temperature: 温度参数
        max_tokens: 最大生成 token 数（默认 16384，确保长输出不被截断）
        json_mode: 是否启用 JSON 模式（默认 True）
        model: 模型名称（可选，默认使用 DEFAULT_MODEL）

    Returns:
        JSON 模式返回字典，文本模式返回字符串
    """
    client = get_client()

    # 使用传入的模型或默认模型
    model_name = model or DEFAULT_MODEL

    # 构建内容列表
    content_list = []

    # 添加所有图片
    for image_path in image_paths:
        base64_image = encode_image_to_base64(image_path)
        if not base64_image:
            logger.warning(f"跳过无法读取的图片: {image_path}")
            continue

        mime_type = get_image_mime_type_for_encoded(image_path)
        content_list.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:{mime_type};base64,{base64_image}"
            }
        })

    # 添加文本提示
    content_list.append({
        "type": "text",
        "text": user_prompt
    })

    try:
        # 确保 model 参数正确传递
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": content_list
                }
            ],
            **({"temperature": temperature} if _model_supports_temperature(model_name) else {}),
            timeout=timeout,
            max_tokens=max_tokens,
            # 添加额外参数确保兼容性
            extra_body={"model": model_name}
        )

        # 🔧 兼容两种响应格式：OpenAI 和 Claude
        content = None
        stop_reason = None

        # 方式1：尝试 OpenAI 格式（response.choices[0].message.content）
        if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
            if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                content = response.choices[0].message.content
                # 检查是否有 finish_reason
                if hasattr(response.choices[0], 'finish_reason'):
                    stop_reason = response.choices[0].finish_reason

        # 方式2：尝试 Claude 格式（response.content[0]['text']）
        if content is None and hasattr(response, 'content') and response.content:
            if isinstance(response.content, list) and len(response.content) > 0:
                first_item = response.content[0]
                if isinstance(first_item, dict) and 'text' in first_item:
                    content = first_item['text']
                elif isinstance(first_item, str):
                    content = first_item
            # 检查 Claude 的 stop_reason
            if hasattr(response, 'stop_reason'):
                stop_reason = response.stop_reason

        # 检查是否成功提取内容
        if content is None:
            logger.error(f"API 返回空响应（无法提取内容）: {response}")
            return {"error": "empty_response", "message": "API returned empty content"}

        # 🔧 已禁用截断检测：避免误判正常代码
        # if stop_reason in ['max_tokens', 'length']:
        #     logger.warning(f"⚠️ API 响应被截断（stop_reason={stop_reason}），内容可能不完整")
        #     ...
        # 现在直接继续处理，不做任何截断判断

        # 根据 json_mode 决定返回格式
        if json_mode:
            result = _safe_json_parse(content)
            # 确保返回的是字典
            if not isinstance(result, dict):
                logger.error(f"_safe_json_parse 返回了非字典类型: {type(result)}")
                return {"error": "invalid_response_type", "content": str(result)}
            return result
        else:
            return content  # 文本模式直接返回字符串

    except (APIConnectionError, APIError, RateLimitError) as e:
        logger.error(f"API 调用失败: {e}")
        raise
    except Exception as e:
        logger.error(f"未知错误: {e}")
        raise



# =====================================================================
# -------- Text Masking: Make questions figure-dependent --------
# =====================================================================

TEXT_MASKING_REWRITE_SYSTEM_PROMPT = """You are an expert math problem editor. Your task is to analyze a math problem and its accompanying figure, then either rewrite it or confirm it already requires the figure.

First, assess whether the original problem ALREADY requires the figure to be solved - meaning key numerical values, coordinates, geometric data, or labels are missing from the text and can only be obtained by looking at the figure.

If the original problem ALREADY depends on the figure (i.e., it cannot be solved from text alone), respond with this JSON:
{"already_figure_dependent": true, "rewritten_question": ""}

If the problem does NOT yet depend on the figure, rewrite it so that all specific numerical values, coordinates, ratios, lengths, angles, or labels that appear in the figure are REMOVED from the text and replaced with figure references.

Rewriting rules:
1. Any specific numerical values, coordinates, ratios, lengths, angles, or labels that appear in the figure must be removed from the text and replaced with figure references.
2. The problem must remain logically consistent and solvable ONLY by looking at the figure.
3. The final answer and the core mathematical question must remain unchanged.
4. Do NOT change the language of the problem (keep it in the same language as the original).
5. Use natural phrases like "as shown in the figure", "from the figure", "as indicated in the diagram", "refer to the figure" to replace removed information.
6. Keep the problem structure and solution steps logically intact.

When rewriting is needed, respond with this JSON:
{"already_figure_dependent": false, "rewritten_question": "<the full rewritten problem text here>"}

Only respond with the JSON object, nothing else."""

TEXT_MASKING_VALIDATE_SYSTEM_PROMPT = """You are a strict math problem quality checker. You will be given:
1. An original math problem
2. A modified version of the problem
3. An image description (Image composition) that describes what information is visible in the figure

Your task is to verify that the modified problem:
1. Cannot be solved using ONLY the text (without looking at the figure) - key data must be missing from text
2. Remains logically consistent and the final answer is still achievable
3. The core mathematical question and final answer are unchanged
4. References to the figure are natural and appropriate

Respond with a JSON object:
{"is_valid": true/false, "reason": "brief explanation of why it passes or fails"}

Only respond with the JSON object, nothing else."""

MASKING_REWRITE_MODEL = "your-rewrite-model"
MASKING_VALIDATE_MODEL = "your-validate-model"
MASKING_MAX_RETRIES = 5


def rewrite_question_for_figure_dependency(question_text: str, image_path: str) -> dict:
    """Rewrite question to be figure-dependent.

    Returns dict with keys:
      - already_figure_dependent (bool)
      - rewritten_question (str)
    """
    user_text = (
        f"Here is the original math problem:\n\n{question_text}\n\n"
        "First assess whether this problem ALREADY requires the figure to solve it. "
        'If yes, respond with {"already_figure_dependent": true, "rewritten_question": ""}. '
        "If no, rewrite it so all specific values visible in the figure are removed and replaced "
        "with figure references, then respond with "
        '{"already_figure_dependent": false, "rewritten_question": "<rewritten text>"}. '
        "Return ONLY the JSON object."
    )

    result = vision_completion(
        system_prompt=TEXT_MASKING_REWRITE_SYSTEM_PROMPT,
        image_path=image_path,
        user_prompt=user_text,
        json_mode=True,
        model=MASKING_REWRITE_MODEL,
        temperature=0.3,
        max_tokens=8192,
    )

    if isinstance(result, dict):
        return {
            "already_figure_dependent": bool(result.get("already_figure_dependent", False)),
            "rewritten_question": result.get("rewritten_question", ""),
        }
    raise ValueError(f"Text masking rewrite returned non-dict: {result}")


def validate_masked_question(
    original_question: str,
    rewritten_question: str,
    image_composition: str,
) -> tuple:
    """Validate that the rewritten question requires the figure to solve.

    Returns (is_valid: bool, reason: str)
    """
    user_text = (
        f"Original problem:\n{original_question}\n\n"
        f"Modified problem:\n{rewritten_question}\n\n"
        f"Figure description (what is visible in the image):\n{image_composition}\n\n"
        "Please verify if the modified problem meets all the requirements."
    )

    result = chat_completion(
        system_prompt=TEXT_MASKING_VALIDATE_SYSTEM_PROMPT,
        user_prompt=user_text,
        json_mode=True,
        model=MASKING_VALIDATE_MODEL,
        temperature=0.1,
        max_tokens=8192,
    )

    if isinstance(result, dict):
        is_valid = bool(result.get("is_valid", False))
        reason = result.get("reason", "No reason provided")
        return is_valid, reason
    raise ValueError(f"Text masking validation returned non-dict: {result}")
