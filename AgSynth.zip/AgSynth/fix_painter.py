#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
临时脚本：为 PainterAgent 添加代码后缀强制机制
"""

def fix_painter_agent():
    """在 PainterAgent.generate_code 方法中添加代码后缀强制逻辑"""
    
    # 读取文件
    with open('/home/project/agents.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 查找目标位置：return _ensure_dict(result, "PainterAgent")
    target = 'return _ensure_dict(result, "PainterAgent")'
    
    if target not in content:
        print("❌ 未找到目标代码位置")
        return False
    
    # 替换代码
    replacement = '''result_dict = _ensure_dict(result, "PainterAgent")
        
        # 🚨 强制添加代码后缀(防御性编程)
        if "python_code" in result_dict:
            code = result_dict["python_code"]
            
            # 检查是否已包含必需语句
            has_tight_layout = "plt.tight_layout()" in code
            has_savefig = "plt.savefig(" in code
            has_close = "plt.close()" in code
            
            # 强制添加缺失的语句
            code_suffix = []
            if not has_tight_layout:
                code_suffix.append("plt.tight_layout()")
            if not has_savefig:
                code_suffix.append("plt.savefig(save_path, dpi=100, bbox_inches='tight')")
            if not has_close:
                code_suffix.append("plt.close()")
            
            # 如果有缺失的语句,追加到代码末尾
            if code_suffix:
                # 确保代码末尾有换行符
                if not code.endswith("\\n"):
                    code += "\\n"
                code += "\\n".join(code_suffix)
                result_dict["python_code"] = code
        
        return result_dict'''
    
    # 执行替换
    new_content = content.replace(target, replacement)
    
    # 写回文件
    with open('/home/project/agents.py', 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print("✅ 成功添加代码后缀强制机制")
    return True

if __name__ == "__main__":
    fix_painter_agent()
