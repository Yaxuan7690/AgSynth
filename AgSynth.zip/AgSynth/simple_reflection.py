"""
simple_reflection.py
轻量级反思管理器 - 支持并发执行的简单反思机制

核心设计：
1. 每个题目独立管理反思历史（通过 question_id 隔离）
2. 每个 Agent 独立管理尝试历史（通过 agent_name 隔离）
3. 失败时记录：设计思路 + 失败原因
4. 重试时注入：历史失败经验作为反思 prompt
5. 题目完成或放弃时，自动清理该题目的所有反思数据
"""
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import threading


@dataclass
class AttemptRecord:
    """单次尝试记录"""
    attempt_number: int
    design_thought: str  # 本次设计思路
    failure_reason: str  # 失败原因（如果失败）
    output: Optional[Dict[str, Any]] = None  # 成功输出（如果成功）


class SimpleReflectionManager:
    """
    轻量级反思管理器
    
    特点：
    - 线程安全（支持并发执行）
    - 每个题目独立管理
    - 每个 Agent 独立管理
    - 题目完成后自动清理
    """
    
    def __init__(self, max_attempts: int = 5):
        """
        初始化反思管理器

        Args:
            max_attempts: 每个阶段最大尝试次数（Painter 为 5 次，其他为 3 次）
        """
        self.max_attempts = max_attempts
        
        # 数据结构：{question_id: {agent_name: [AttemptRecord, ...]}}
        self._history: Dict[str, Dict[str, List[AttemptRecord]]] = {}
        
        # 线程锁（支持并发）
        self._lock = threading.Lock()
    
    def record_attempt(
        self,
        question_id: str,
        agent_name: str,
        attempt_number: int,
        design_thought: str,
        failure_reason: Optional[str] = None,
        output: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        记录一次尝试
        
        Args:
            question_id: 题目ID
            agent_name: Agent名称（如 "ConceptDesigner", "VisualSpecifier"）
            attempt_number: 尝试次数（1, 2, 3）
            design_thought: 本次设计思路
            failure_reason: 失败原因（如果失败）
            output: 成功输出（如果成功）
        """
        with self._lock:
            # 确保数据结构存在
            if question_id not in self._history:
                self._history[question_id] = {}
            if agent_name not in self._history[question_id]:
                self._history[question_id][agent_name] = []
            
            # 记录尝试
            record = AttemptRecord(
                attempt_number=attempt_number,
                design_thought=design_thought,
                failure_reason=failure_reason or "",
                output=output
            )
            self._history[question_id][agent_name].append(record)
    
    def generate_reflection_prompt(
        self,
        question_id: str,
        agent_name: str
    ) -> str:
        """
        生成反思 prompt（基于历史失败经验）
        
        Args:
            question_id: 题目ID
            agent_name: Agent名称
        
        Returns:
            反思 prompt（如果没有历史记录，返回空字符串）
        """
        with self._lock:
            # 获取历史记录
            if question_id not in self._history:
                return ""
            if agent_name not in self._history[question_id]:
                return ""
            
            attempts = self._history[question_id][agent_name]
            if not attempts:
                return ""
            
            # 构建反思 prompt
            reflection_parts = [
                "\n\n🔄 **REFLECTION FROM PREVIOUS ATTEMPTS**\n",
                "Learn from these failures and avoid repeating the same mistakes:\n"
            ]
            
            for record in attempts:
                reflection_parts.append(
                    f"\n**Attempt {record.attempt_number}:**\n"
                    f"- Design Thought: {record.design_thought}\n"
                    f"- Failure Reason: {record.failure_reason}\n"
                )
            
            reflection_parts.append(
                "\n⚠️ **CRITICAL**: Analyze the patterns above and adjust your approach accordingly.\n"
            )
            
            return "".join(reflection_parts)
    
    def can_retry(
        self,
        question_id: str,
        agent_name: str
    ) -> bool:
        """
        判断是否可以重试
        
        Args:
            question_id: 题目ID
            agent_name: Agent名称
        
        Returns:
            是否可以重试
        """
        with self._lock:
            if question_id not in self._history:
                return True
            if agent_name not in self._history[question_id]:
                return True
            
            attempts = self._history[question_id][agent_name]
            return len(attempts) < self.max_attempts
    
    def get_attempt_count(
        self,
        question_id: str,
        agent_name: str
    ) -> int:
        """
        获取当前尝试次数
        
        Args:
            question_id: 题目ID
            agent_name: Agent名称
        
        Returns:
            当前尝试次数
        """
        with self._lock:
            if question_id not in self._history:
                return 0
            if agent_name not in self._history[question_id]:
                return 0
            
            return len(self._history[question_id][agent_name])
    
    def clear_question(self, question_id: str) -> None:
        """
        清理指定题目的所有反思数据
        
        Args:
            question_id: 题目ID
        """
        with self._lock:
            if question_id in self._history:
                del self._history[question_id]
    
    def get_summary(self, question_id: str) -> Dict[str, Any]:
        """
        获取指定题目的反思摘要
        
        Args:
            question_id: 题目ID
        
        Returns:
            反思摘要
        """
        with self._lock:
            if question_id not in self._history:
                return {}
            
            summary = {}
            for agent_name, attempts in self._history[question_id].items():
                summary[agent_name] = {
                    "total_attempts": len(attempts),
                    "attempts": [
                        {
                            "attempt_number": record.attempt_number,
                            "design_thought": record.design_thought[:100] + "..." if len(record.design_thought) > 100 else record.design_thought,
                            "failure_reason": record.failure_reason[:100] + "..." if len(record.failure_reason) > 100 else record.failure_reason,
                            "success": record.output is not None
                        }
                        for record in attempts
                    ]
                }
            
            return summary
