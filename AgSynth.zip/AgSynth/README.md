# 多智能体自动出题流水线系统（ReAct 架构 4+1）

本项目使用 **5 个大语言模型**构建多智能体自动协作系统，采用 **ReAct 架构**（Reasoning + Acting），支持记忆学习、反思修正和自我进化，确保出题逻辑严密、配图准确以及题目答案无误。

## 🚀 架构优化亮点

### ReAct 架构核心能力
- **🧠 记忆学习**：每个阶段记录错误历史，避免重复犯错
- **🔄 反思修正**：基于历史错误生成反思提示，指导下一次尝试
- **🎯 自我进化**：每阶段3次机会，自动学习和改进
- **📊 错误分析**：智能分析错误模式，提供针对性改进策略
- **💾 记忆导出**：支持导出记忆数据用于调试和分析

### 4+1 架构设计
- **规则预检 + 质量评分**：保证输出质量
- **架构清晰**：职责明确，便于维护
- **逻辑内核提取 + 视觉形式重构**：增强创新性
- **专门的视觉设计智能体**：确保布局合理、无遮挡、纯视觉化

## 智能体职责说明（ReAct 架构 4+1）

### ReAct 核心组件

- **MemoryManager（记忆管理器）**：记录每个阶段的执行历史、错误信息和解决方案
- **ReflectionEngine（反思引擎）**：分析错误模式，生成改进策略和智能建议
- **每阶段3次机会**：失败后自动重试，每次尝试都会学习前一次的错误

### 核心智能体（4 个）

1. **Agent 1 (ConceptDesigner)**: **概念设计智能体**（逻辑内核提取专家）
   - **核心使命**：深度理解种子题，提取数学逻辑内核
   - **主要职责**：
     - 深度分析种子题的数学逻辑、推理过程和解题方法
     - 提取逻辑内核（数量关系、空间关系、逻辑关系、变化规律、约束条件）
     - 设计新题目的概念框架（保持逻辑等价，但允许数据创新）
     - 提供清晰的需求规格说明
   - **输出内容**：
     - 逻辑内核描述
     - 概念设计方案
     - 数据规格说明
     - 预期答案格式
   - **优势**：专注于逻辑分析，不被视觉形式干扰，确保数学逻辑严密

2. **Agent 2 (VisualSpecifier)**: **视觉规格设计智能体**（视觉形式创新专家）
   - **核心使命**：将概念转化为具体的视觉规格说明
   - **主要职责**：
     - 接收 ConceptDesigner 的概念设计
     - 选择与种子题截然不同的视觉呈现形式
     - 设计详细的图片规格（5个必需元素：图形元素、布局方式、坐标位置、配色方案、标注内容）
     - 确保布局合理、无遮挡、纯视觉化（无题目文字）
   - **视觉形式库**：数阵迷宫、天平平衡、流程图逻辑、坐标点位、断码电子钟、容器液体、齿轮传动、拼图碎片等
   - **输出内容**：
     - 视觉形式选择
     - 详细图片规格说明
     - 具体数据值
     - 布局质量要求
   - **优势**：专注于视觉创新，与 Painter 精准沟通，确保图片质量

3. **Agent 3 (Painter)**: **数据可视化专家**
   - 编写 Python 代码使用 `matplotlib` 绘制并导出题目配图
   - 严格遵循 VisualSpecifier 的规格说明
   - 确保图片清晰、元素完整、布局合理、无遮挡、纯视觉化

4. **Agent 4 (QA Generator)**: **试题文本生成器**
   - 综合 ConceptDesigner 和 VisualSpecifier 的输出
   - 生成精确的问题文本和答案
   - 提供详细的解题步骤

### 质量保障智能体（+1）

5. **Agent 5 (Quality Rater)**: **质量评分与审查专家**（增强版）
   - 对最终生成的题目进行综合质量评分
   - 结合大模型评估和规则检查
   - 从题目清晰度、图片质量、答案准确性、解题步骤、难度匹配五个维度评分
   - 返回 1-10 分的质量评分
   - 评分 < 6 分时提供详细反馈和改进建议
   - **重点关注**：图片质量（无遮挡、纯视觉、专业性）+ 创新性（视觉+数据）+ 逻辑严密性

## 🎯 核心优化机制

### 1. ReAct 架构（Reasoning + Acting）

**架构流程**：
```
ConceptDesigner → VisualSpecifier → Painter → QA Generator → Quality Rater
      ↓                 ↓              ↓            ↓              ↓
  逻辑内核提取      视觉形式设计    代码生成绘图   题目文本生成   综合质量评分
      ↓                 ↓              ↓            ↓              ↓
  记忆学习+反思     记忆学习+反思   记忆学习+反思  记忆学习+反思   规则+LLM评估
      ↓                 ↓              ↓            ↓              ↓
  规则预检          规则预检        规则预检      规则预检       记忆摘要导出
```

**ReAct 工作流程**：
1. **记录尝试**：每次执行前记录尝试次数
2. **生成反思**：基于历史错误生成反思提示
3. **执行任务**：将反思提示传递给 LLM
4. **记录结果**：成功则记录输出，失败则记录错误
5. **智能重试**：失败后自动重试（最多3次），每次都会学习前一次的错误

**优化效果**：
- ✅ 职责分离：ConceptDesigner 专注逻辑，VisualSpecifier 专注视觉
- ✅ 图片质量提升：专门的视觉设计阶段，确保布局合理、无遮挡
- ✅ 创新性增强：视觉形式不受种子题限制，鼓励大胆创新
- ✅ 深度理解：两个智能体都能读取种子题，深度理解题目内核
- ✅ 精准沟通：VisualSpecifier 与 Painter 之间的沟通更精准
- ✅ 维护性提升：每个智能体职责单一，代码更清晰

### 2. 规则预检（Rule-based Pre-check）+ 创新性验证

在调用 LLM 智能体前，先使用 Python 规则进行快速预检，立即发现明显问题：

#### **阶段 1：概念设计预检**（ConceptDesigner 产出）
- 检查必需字段完整性（question_type、core_logic_kernel、difficulty_requirements、concept_design、expected_answer）
- 验证字段内容长度（concept_design 各子字段≥10字符）
- 检查 concept_design 子字段（logic_description、data_specifications）
- 验证逻辑内核描述的完整性

#### **阶段 2：视觉规格预检**（VisualSpecifier 产出）
- 检查必需字段完整性（visual_form_choice、visual_rationale、detailed_image_specification、data_values、expected_answer）
- 验证 detailed_image_specification 包含5个必需元素：
  - 图形元素（Graphic Elements）
  - 布局方式（Layout）
  - 坐标位置（Coordinates）
  - 配色方案（Color）
  - 标注内容（Annotation）
- 检查规格说明长度（≥150字符）
- 验证布局质量要求（间距、边距、尺寸、防遮挡措施）

#### **阶段 3：代码预检**（Painter 产出）
- 检查代码长度（避免空代码或过短代码）
- 验证必需语句（plt.savefig、plt.close）
- 检查语法错误（括号、方括号、花括号匹配）
- 检测危险模式（if __name__ 判断会导致 exec 不执行）

#### **阶段 4：QA 预检**（QA Generator 产出）
- 检查题目、答案、解题步骤长度
- 验证难度匹配（简单题步骤不过长，困难题步骤不过短）
- 检查数学题答案格式（计算题答案应包含数字）

### 4. 快速失败机制（Fast-fail）

优化错误重试逻辑，区分可重试和不可重试错误：

- **不可重试错误**（立即失败，不浪费时间）：
  - 格式错误：invalid_input、invalid_response、json_parse_failed
  - 语法错误：括号不匹配、缺少必需语句
  - 内容错误：字段过短、为空、不符合要求
  - 创新性不足：未明确视觉形式、缺少创新思路说明

- **可重试错误**（网络/临时问题，自动重试）：
  - 网络错误：connection error、timeout、reset by peer
  - 服务错误：502、503、504
  - 限流错误：429、rate limit

### 5. 质量评分增强

**Quality Rater 承担双重职责**：
- **质量评分**：从 5 个维度综合评分（1-10 分）
- **审查反馈**：评分 < 6 分时提供详细改进建议
- **混合评分**：规则检查（40%）+ 大模型评估（60%）

### 🎯 质量保障

- ✅ **规则预检**：快速拦截明显错误
- ✅ **创新性验证**：确保题目视觉形式与种子题迥异
- ✅ **质量评分**：综合评估 5 个维度
- ✅ **详细反馈**：低分时提供改进建议
- ✅ **自动重试**：网络/临时错误自动重试

## 🎨 创新性机制详解

### 逻辑内核提取（5个维度）

1. **数量关系**：加减乘除、比例、倍数、分数、百分比、等式/不等式关系
2. **空间关系**：位置、方向、距离、角度、对称、旋转、平移
3. **逻辑关系**：因果、条件、推理链、排除法、分类、归纳
4. **变化规律**：递增/递减、周期、对称、映射、函数关系
5. **约束条件**：边界、限制、前提、目标

### 视觉形式库（8种创新方案）

1. **数阵迷宫**：用数字矩阵、幻方、数独、填空格等形式呈现数量关系
2. **天平平衡**：用天平、跷跷板、砝码等呈现等式/不等式关系
3. **流程图逻辑**：用流程图、决策树、路径图呈现推理过程
4. **坐标点位**：用坐标系、散点图、向量图呈现空间关系
5. **断码电子钟**：用七段数码管、电子钟、计时器呈现数字规律
6. **容器液体**：用水杯、量筒、容器倒水呈现容量/比例关系
7. **齿轮传动**：用齿轮、滑轮、杠杆呈现比例/倍数关系
8. **拼图碎片**：用拼图、七巧板、图形分割呈现几何关系

### 严格禁止的低创新行为

- ❌ 只改数字（如：3+5=8 → 4+6=10）
- ❌ 只换图形（如：圆形 → 方形）
- ❌ 只调颜色（如：红色 → 蓝色）
- ❌ 只改情境（如：苹果 → 橙子）
- ❌ 保持相同的视觉结构（如：种子题是坐标系，新题也是坐标系）

### 创新性验证标准

生成的题目必须满足：
1. **逻辑等价**：数学逻辑内核与种子题一致
2. **视觉迥异**：图形呈现方式与种子题完全不同
3. **难度匹配**：解题步骤数量符合难度要求
4. **逻辑严密**：条件充分、答案唯一、无歧义

## 运行环境与启动方式
本工程采用纯 Python 构建，您需要在本地 Python 3.10+ 的环境中运行：

1. **安装依赖**
```bash
pip install -r requirements.txt
```

2. **配置环境变量**
请在环境变量中设置 API 配置：
```bash
export OPENAI_API_KEY="your-api-key"
export OPENAI_BASE_URL="https://your-endpoint/v1"
```
模型名称可在 `utils.py` 中的 `DEFAULT_MODEL` 和 `AGENT_MODELS` 处修改。

3. **准备数据**

### 方式一：使用 JSON 配置文件（推荐）

在 `main.py` 中配置以下路径（默认使用相对路径）：

```python
# 1. 图片文件夹路径（相对于 v7 目录的上一级 images 文件夹）
IMAGE_DIR = os.path.join(os.path.dirname(__file__), "..", "images")

# 2. 种子题目 JSON 文件路径
SEED_JSON_PATH = os.path.join(os.path.dirname(__file__), "..", "filtered_questions.json")

# 3. 输出目录
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "output")
```

**JSON 文件格式**：

系统支持**新旧两种格式**，自动智能识别和映射：

#### 格式一：新格式（700+ 题数据集）

```json
[
  {
    "question_id": "benjamin_2009_matematica_q_01",
    "question": "Where is the Kangaroo?",
    "standard_answer": "B",
    "human_sol": "详细的解题思路和步骤...",
    "solution": "",
    "image_path": "benjamin_2009_matematica_q_01.png"
  },
  {
    "question_id": "benjamin_2009_matematica_q_02",
    "question": "...",
    ...
  }
]
```

**新格式字段说明**：
- `question_id`: 题目唯一标识符（例如：`benjamin_2009_matematica_q_01`）
- `question`: 题目文本内容
- `standard_answer`: 标准答案（例如：`B`）
- `human_sol`: 人类提供的详细解题思路和步骤（长文本）
- `solution`: 备用解答字段（可为空）
- `image_path`: 图片文件名（例如：`benjamin_2009_matematica_q_01.png`）

#### 格式二：旧格式（原有数据集）

```json
[
  {
    "Name": "Calculation_easy_1.png",
    "Revised_Question": "题目描述...",
    "Image composition": "图片构成描述...",
    "Solution steps": "解题步骤...",
    "Difficulty level": "简单",
    "Revised_Answer": "答案...",
    "Question_Type": "计算题"
  },
  {
    "ID": "Calculation_easy_2.png",
    "Revised_Question": "...",
    ...
  }
]
```

**旧格式字段说明**（大小写不敏感）：
- `Name` / `ID`: 图片文件名（用于定位图片）
- `Revised_Question`: 题目问题描述
- `Image composition`: 图片构成说明
- `Solution steps`: 解题步骤
- `Difficulty level`: 难度级别
- `Revised_Answer`: 标准答案
- `Question_Type`: 题目类型

#### 智能字段映射规则

系统会自动识别 JSON 格式并进行智能映射：

| 统一字段 | 新格式优先 | 旧格式兼容 |
|---------|-----------|-----------|
| 题目标识符 | `question_id` | `Name/ID` / `Name` / `ID` |
| 图片路径 | `image_path` | `Name/ID` / `Name` / `ID` |
| 题目文本 | `question` | `Revised_Question` |
| 标准答案 | `standard_answer` | `Revised_Answer` |
| 解题步骤 | `human_sol` / `solution` | `Solution steps` |
| 题目类型 | （可选） | `Question_Type` |
| 图片构成 | （可选） | `Image composition` |

**优势**：
- ✅ 无缝支持新旧两种数据集格式
- ✅ 优先使用新格式字段，自动降级到旧格式
- ✅ 700+ 题大规模数据集完美兼容
- ✅ 所有信息自动传递给 5 个智能体作为参考

4. **启动测试**
```bash
python main.py
```

终端会打印全流水线协同流程与打回重做的日志，执行结束后：
- 最终的结构化结果保存到 `OUTPUT_DIR/final_qa_dataset.json`
- 生成的测试配图输出为 `OUTPUT_DIR/generated_question_1.png`、`generated_question_2.png` 等

## 配置说明

在 `main.py` 中可以调整以下参数：

```python
# 生成题目数量
GENERATE_COUNT = 3
```

## 输出结果

生成的 `final_qa_dataset.json` 包含以下字段（与输入种子题格式保持一致）：

```json
[
  {
    "Name/ID": "generated_question_1",
    "Revised_Question": "生成的题目描述...",
    "Image composition": "图片构成描述（由 Designer 智能体生成的图片设计方案）",
    "Solution steps": [
      "Step 1: 第一步解题说明...",
      "Step 2: 第二步解题说明...",
      "Step 3: 第三步解题说明..."
    ],
    "Revised_Answer": "标准答案",
    "Quality rating": "8",
    "Question_Type": "Calculation(Emphasis is placed on assessing computation-related problems.)"
  }
]
```

### 字段说明

- **Name/ID**: 题目标识符，格式为 `generated_question_N`
- **Revised_Question**: 生成的题目描述
- **Image composition**: 图片构成描述，来自 VisualSpecifier 智能体的详细图片规格说明
- **Solution steps**: 解题步骤数组，每个元素是一个步骤说明
- **Revised_Answer**: 标准答案
- **Quality rating**: 质量评分（1-10 分），由 Quality Rater 智能体综合评估
- **Question_Type**: 题目类型，继承自种子题目的类型

## 质量评分机制

系统采用**混合评分机制**，结合大模型评估和规则检查：

### 评分维度（总分 10 分）

1. **题目清晰度（2.5分）**: 题目描述是否清晰、无歧义、符合数学规范
2. **图片质量（2.5分）**: 图片是否清晰、元素完整、布局合理、视觉专业
3. **答案准确性（2.5分）**: 答案是否正确、完整、格式规范
4. **解题步骤（2.5分）**: 步骤是否详细、逻辑清晰、易于理解

### 评分方式

- **规则检查（40%权重）**: 基于客观指标（文本长度、图片大小等）进行基础评分
- **大模型评估（60%权重）**: 调用 Agent 4 (Quality Rater) 进行综合质量评估
- **最终评分**: 两者加权平均，确保评分在 1-10 范围内

### 规则检查标准

- 题目长度不足 20 字符：扣 2 分
- 答案长度不足 5 字符：扣 2 分
- 解题步骤不足 50 字符：扣 2 分
- 图片文件小于 1KB：扣 3 分
