"""查找 main.py 中所有引用 DIFFICULTY 的行"""
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE_DIR, "main.py"), "r", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        if "DIFFICULTY" in line or "difficulty" in line:
            print(f"L{i}: {line.rstrip()[:120]}")
os.remove(os.path.abspath(__file__))
