"""
board_validator.py
棋盘逻辑验证器 - 解决"空间幻觉"问题

核心功能:
1. ASCII棋盘解析与验证
2. 五子棋/井字棋逻辑验证
3. 连线检测(横/竖/斜)
4. 反思链生成(将验证错误转化为修正建议)
5. 代码生成辅助(生成合法坐标的Python脚本)

使用场景:
- ConceptDesigner 设计棋盘题时,强制输出ASCII棋盘自检
- Auditor 审计时,验证棋盘逻辑并生成反思提示
- 支持反思循环:验证失败 → 反馈错误 → Agent修正 → 再次验证
"""

from typing import List, Dict, Any, Optional, Tuple, Set
import re


class BoardValidator:
    """棋盘逻辑验证器 - 支持反思链和ASCII自检"""
    
    def __init__(self):
        """初始化验证器"""
        self.board_symbols = {
            'black': ['B', 'X', '●', '○', '1'],
            'white': ['W', 'O', '◯', '◎', '2'],
            'empty': ['.', '-', '_', ' ', '0']
        }
    
    # ========================================================================
    # 核心功能 A: ASCII棋盘解析与验证
    # ========================================================================
    
    def parse_ascii_board(self, ascii_board: str) -> Tuple[List[List[str]], Dict[str, Any]]:
        """
        解析ASCII棋盘字符串
        
        Args:
            ascii_board: ASCII棋盘字符串,例如:
                ```
                  1 2 3 4 5
                1 . . B . .
                2 . . B . .
                3 . W X . .
                4 . . . . .
                5 . . . . .
                ```
        
        Returns:
            (board_matrix, metadata)
            - board_matrix: 二维数组,每个元素是棋子类型('B'/'W'/'.')
            - metadata: 元数据(行数、列数、黑子数、白子数等)
        """
        lines = [line.strip() for line in ascii_board.strip().split('\n') if line.strip()]
        
        # 跳过表头(如果有)
        board_lines = []
        for line in lines:
            # 检测是否为数据行(包含棋子符号)
            if any(symbol in line for symbols in self.board_symbols.values() for symbol in symbols):
                # 移除行号前缀
                cleaned = re.sub(r'^\d+\s*', '', line)
                board_lines.append(cleaned)
        
        if not board_lines:
            return [], {"error": "无法解析ASCII棋盘:未找到有效的棋盘数据"}
        
        # 解析棋盘矩阵
        board_matrix = []
        for line in board_lines:
            row = []
            # 分割每个字符(忽略空格)
            chars = [c for c in line if c not in [' ', '\t', '|']]
            for char in chars:
                if char in self.board_symbols['black']:
                    row.append('B')
                elif char in self.board_symbols['white']:
                    row.append('W')
                elif char in self.board_symbols['empty']:
                    row.append('.')
                else:
                    # 未知符号,视为空位
                    row.append('.')
            
            if row:  # 只添加非空行
                board_matrix.append(row)
        
        # 计算元数据
        rows = len(board_matrix)
        cols = len(board_matrix[0]) if board_matrix else 0
        black_count = sum(row.count('B') for row in board_matrix)
        white_count = sum(row.count('W') for row in board_matrix)
        
        metadata = {
            "rows": rows,
            "cols": cols,
            "black_count": black_count,
            "white_count": white_count,
            "total_pieces": black_count + white_count
        }
        
        return board_matrix, metadata
    
    def validate_ascii_board(
        self,
        ascii_board: str,
        expected_black: Optional[int] = None,
        expected_white: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        验证ASCII棋盘的基本合法性
        
        Args:
            ascii_board: ASCII棋盘字符串
            expected_black: 期望的黑子数量
            expected_white: 期望的白子数量
        
        Returns:
            {
                "is_valid": bool,
                "board_matrix": List[List[str]],
                "metadata": Dict,
                "errors": List[str],
                "warnings": List[str]
            }
        """
        board_matrix, metadata = self.parse_ascii_board(ascii_board)
        
        errors = []
        warnings = []
        
        # 检查1: 棋盘是否为空
        if not board_matrix:
            errors.append("棋盘解析失败或为空")
            return {
                "is_valid": False,
                "board_matrix": [],
                "metadata": metadata,
                "errors": errors,
                "warnings": warnings
            }
        
        # 检查2: 棋盘是否为矩形
        row_lengths = [len(row) for row in board_matrix]
        if len(set(row_lengths)) > 1:
            errors.append(f"棋盘不是矩形:行长度不一致 {row_lengths}")
        
        # 检查3: 棋子数量是否匹配
        if expected_black is not None and metadata['black_count'] != expected_black:
            errors.append(f"黑子数量不匹配:期望{expected_black},实际{metadata['black_count']}")
        
        if expected_white is not None and metadata['white_count'] != expected_white:
            errors.append(f"白子数量不匹配:期望{expected_white},实际{metadata['white_count']}")
        
        # 检查4: 棋盘尺寸是否合理
        if metadata['rows'] < 3 or metadata['cols'] < 3:
            warnings.append(f"棋盘尺寸过小:{metadata['rows']}x{metadata['cols']}")
        
        if metadata['rows'] > 20 or metadata['cols'] > 20:
            warnings.append(f"棋盘尺寸过大:{metadata['rows']}x{metadata['cols']}")
        
        is_valid = len(errors) == 0
        
        return {
            "is_valid": is_valid,
            "board_matrix": board_matrix,
            "metadata": metadata,
            "errors": errors,
            "warnings": warnings
        }
    
    # ========================================================================
    # 核心功能 B: 五子棋/井字棋逻辑验证
    # ========================================================================
    
    def check_winning_line(
        self,
        board_matrix: List[List[str]],
        player: str,
        required_length: int = 5
    ) -> Tuple[bool, List[Tuple[int, int]]]:
        """
        检查指定玩家是否有获胜连线
        
        Args:
            board_matrix: 棋盘矩阵
            player: 玩家标识('B'或'W')
            required_length: 需要连成的长度(五子棋=5,井字棋=3)
        
        Returns:
            (has_winning_line, winning_positions)
            - has_winning_line: 是否存在获胜连线
            - winning_positions: 获胜连线的坐标列表
        """
        if not board_matrix:
            return False, []
        
        rows = len(board_matrix)
        cols = len(board_matrix[0])
        
        # 检查所有方向:横、竖、斜(左上到右下)、斜(右上到左下)
        directions = [
            (0, 1),   # 横向
            (1, 0),   # 竖向
            (1, 1),   # 斜向(左上到右下)
            (1, -1)   # 斜向(右上到左下)
        ]
        
        for r in range(rows):
            for c in range(cols):
                if board_matrix[r][c] != player:
                    continue
                
                # 从当前位置尝试每个方向
                for dr, dc in directions:
                    positions = [(r, c)]
                    
                    # 沿着当前方向延伸
                    for step in range(1, required_length):
                        nr, nc = r + dr * step, c + dc * step
                        
                        # 检查边界
                        if not (0 <= nr < rows and 0 <= nc < cols):
                            break
                        
                        # 检查是否为同色棋子
                        if board_matrix[nr][nc] != player:
                            break
                        
                        positions.append((nr, nc))
                    
                    # 检查是否达到所需长度
                    if len(positions) == required_length:
                        return True, positions
        
        return False, []
    
    def validate_board_logic(
        self,
        ascii_board: str,
        expected_winner: Optional[str] = None,
        expected_no_winner: bool = False,
        required_length: int = 5
    ) -> Dict[str, Any]:
        """
        验证棋盘逻辑的正确性
        
        Args:
            ascii_board: ASCII棋盘字符串
            expected_winner: 期望的获胜方('B'/'W'/None)
            expected_no_winner: 是否期望无人获胜
            required_length: 获胜所需连线长度
        
        Returns:
            {
                "is_valid": bool,
                "actual_winner": str,  # 'B'/'W'/None
                "black_winning_line": List[Tuple[int, int]],
                "white_winning_line": List[Tuple[int, int]],
                "errors": List[str],
                "reflection_prompt": str  # 反思提示
            }
        """
        # 解析棋盘
        validation = self.validate_ascii_board(ascii_board)
        if not validation['is_valid']:
            return {
                "is_valid": False,
                "actual_winner": None,
                "black_winning_line": [],
                "white_winning_line": [],
                "errors": validation['errors'],
                "reflection_prompt": self._generate_reflection_prompt(validation['errors'])
            }
        
        board_matrix = validation['board_matrix']
        errors = []
        
        # 检查黑方是否获胜
        black_wins, black_line = self.check_winning_line(board_matrix, 'B', required_length)
        
        # 检查白方是否获胜
        white_wins, white_line = self.check_winning_line(board_matrix, 'W', required_length)
        
        # 确定实际获胜方
        actual_winner = None
        if black_wins and white_wins:
            errors.append("逻辑错误:黑白双方同时获胜(不可能)")
            actual_winner = "BOTH"
        elif black_wins:
            actual_winner = "B"
        elif white_wins:
            actual_winner = "W"
        
        # 验证是否符合期望
        if expected_winner is not None:
            if actual_winner != expected_winner:
                errors.append(
                    f"获胜方不匹配:期望{expected_winner}获胜,实际{actual_winner or '无人'}获胜"
                )
        
        if expected_no_winner and actual_winner is not None:
            errors.append(f"期望无人获胜,但实际{actual_winner}获胜")
        
        is_valid = len(errors) == 0
        
        return {
            "is_valid": is_valid,
            "actual_winner": actual_winner,
            "black_winning_line": black_line,
            "white_winning_line": white_line,
            "errors": errors,
            "reflection_prompt": self._generate_reflection_prompt(errors) if errors else ""
        }
    
    # ========================================================================
    # 核心功能 C: 反思链生成
    # ========================================================================
    
    def _generate_reflection_prompt(self, errors: List[str]) -> str:
        """
        根据验证错误生成反思提示
        
        这是反思链的核心:将Python验证结果转化为Agent能理解的修正建议
        """
        if not errors:
            return ""
        
        reflection = "## 🔍 Python验证发现以下问题:\n\n"
        
        for i, error in enumerate(errors, 1):
            reflection += f"{i}. {error}\n"
        
        reflection += "\n## 💡 修正建议:\n\n"
        
        # 根据错误类型生成具体建议
        for error in errors:
            if "获胜方不匹配" in error:
                reflection += "- **重新检查棋盘布局**:用ASCII棋盘画出来,确认哪方真的能连成线\n"
                reflection += "- **验证连线路径**:从起点到终点,逐个检查坐标是否连续\n"
            
            elif "黑白双方同时获胜" in error:
                reflection += "- **移除多余的连线**:确保只有一方能获胜\n"
                reflection += "- **调整棋子位置**:打断其中一方的连线\n"
            
            elif "数量不匹配" in error:
                reflection += "- **重新计算棋子数量**:在ASCII棋盘中数一遍黑子和白子\n"
                reflection += "- **更新data_specifications**:确保数量与ASCII棋盘一致\n"
            
            elif "棋盘不是矩形" in error:
                reflection += "- **检查ASCII棋盘格式**:确保每行的列数相同\n"
                reflection += "- **补齐缺失的空位**:用'.'填充\n"
            
            elif "期望无人获胜,但实际" in error:
                reflection += "- **打断获胜连线**:在连线中插入对方棋子或空位\n"
                reflection += "- **重新设计棋局**:确保双方都无法连成线\n"
        
        reflection += "\n## 🎯 下一步行动:\n\n"
        reflection += "1. 先画出ASCII棋盘(用'B'表示黑子,'W'表示白子,'.'表示空位)\n"
        reflection += "2. 在ASCII棋盘上标记出你认为的获胜连线\n"
        reflection += "3. 逐个检查连线上的坐标是否连续\n"
        reflection += "4. 修正错误后,重新输出完整的concept_design\n"
        
        return reflection
    
    def generate_reflection_for_agent(
        self,
        concept_design: dict,
        validation_result: Dict[str, Any]
    ) -> str:
        """
        为Agent生成完整的反思提示(用于ReAct循环)
        
        Args:
            concept_design: ConceptDesigner的输出
            validation_result: 验证结果
        
        Returns:
            完整的反思提示字符串
        """
        if validation_result.get('is_valid'):
            return "✅ 棋盘逻辑验证通过!无需修正。"
        
        reflection = "## ❌ 棋盘逻辑验证失败\n\n"
        
        # 显示原始设计
        reflection += "### 📋 你的原始设计:\n\n"
        reflection += f"**逻辑内核**: {concept_design.get('core_logic_kernel', 'N/A')[:200]}\n\n"
        reflection += f"**数据规格**: {concept_design.get('concept_design', {}).get('data_specifications', 'N/A')[:300]}\n\n"
        
        # 显示验证错误
        reflection += validation_result.get('reflection_prompt', '')
        
        # 添加示例
        reflection += "\n## 📝 正确的ASCII棋盘示例:\n\n"
        reflection += "```\n"
        reflection += "  1 2 3 4 5\n"
        reflection += "1 . . B . .\n"
        reflection += "2 . . B . .\n"
        reflection += "3 . . B . .\n"
        reflection += "4 . . B . .\n"
        reflection += "5 . . B . .  ← 黑子在(1,3)(2,3)(3,3)(4,3)(5,3)连成竖线\n"
        reflection += "```\n\n"
        
        reflection += "**关键点**:\n"
        reflection += "- 坐标从(1,1)开始,不是(0,0)\n"
        reflection += "- 连线必须是连续的(横/竖/斜)\n"
        reflection += "- 先画ASCII棋盘,再提取坐标,避免空间幻觉\n"
        
        return reflection
    
    # ========================================================================
    # 核心功能 D: 代码生成辅助(可选)
    # ========================================================================
    
    def generate_board_creation_code(
        self,
        board_size: Tuple[int, int],
        black_positions: List[Tuple[int, int]],
        white_positions: List[Tuple[int, int]]
    ) -> str:
        """
        生成创建棋盘的Python代码
        
        这是"代码优先"策略的实现:让Agent生成代码而非直接猜坐标
        
        Args:
            board_size: 棋盘尺寸(rows, cols)
            black_positions: 黑子位置列表
            white_positions: 白子位置列表
        
        Returns:
            Python代码字符串
        """
        code = f"""# 棋盘生成代码
def create_board():
    rows, cols = {board_size}
    board = [['.' for _ in range(cols)] for _ in range(rows)]
    
    # 放置黑子
    black_positions = {black_positions}
    for r, c in black_positions:
        board[r][c] = 'B'
    
    # 放置白子
    white_positions = {white_positions}
    for r, c in white_positions:
        board[r][c] = 'W'
    
    return board

def print_board(board):
    print("  " + " ".join(str(i+1) for i in range(len(board[0]))))
    for i, row in enumerate(board):
        print(f"{{i+1}} " + " ".join(row))

# 执行
board = create_board()
print_board(board)
"""
        return code
    
    def suggest_valid_winning_positions(
        self,
        board_size: Tuple[int, int],
        required_length: int = 5,
        direction: str = "horizontal"
    ) -> List[Tuple[int, int]]:
        """
        建议合法的获胜位置
        
        Args:
            board_size: 棋盘尺寸
            required_length: 获胜所需长度
            direction: 方向("horizontal"/"vertical"/"diagonal")
        
        Returns:
            合法的获胜位置列表
        """
        rows, cols = board_size
        
        if direction == "horizontal":
            # 横向:选择中间行
            mid_row = rows // 2
            if cols >= required_length:
                start_col = (cols - required_length) // 2
                return [(mid_row, start_col + i) for i in range(required_length)]
        
        elif direction == "vertical":
            # 竖向:选择中间列
            mid_col = cols // 2
            if rows >= required_length:
                start_row = (rows - required_length) // 2
                return [(start_row + i, mid_col) for i in range(required_length)]
        
        elif direction == "diagonal":
            # 斜向:左上到右下
            if rows >= required_length and cols >= required_length:
                start_row = (rows - required_length) // 2
                start_col = (cols - required_length) // 2
                return [(start_row + i, start_col + i) for i in range(required_length)]
        
        return []
    
    # ========================================================================
    # 通用验证接口
    # ========================================================================
    
    def validate_concept_with_reflection(
        self,
        concept_design: dict,
        expected_winner: Optional[str] = None,
        required_length: int = 5
    ) -> Dict[str, Any]:
        """
        验证概念设计并生成反思提示(用于ReAct循环)
        
        这是与Orchestrator集成的主要接口
        
        Args:
            concept_design: ConceptDesigner的输出
            expected_winner: 期望的获胜方
            required_length: 获胜所需长度
        
        Returns:
            {
                "is_valid": bool,
                "validation_result": Dict,
                "reflection_prompt": str,  # 用于ReAct循环
                "suggested_fixes": Dict    # 自动修复建议
            }
        """
        # 提取ASCII棋盘(如果有)
        ascii_board = concept_design.get('ascii_board_check', '')
        
        if not ascii_board:
            return {
                "is_valid": False,
                "validation_result": {},
                "reflection_prompt": "❌ 缺少ASCII棋盘自检!请先画出ASCII棋盘,再提取坐标。",
                "suggested_fixes": {
                    "action": "add_ascii_board",
                    "instruction": "在concept_design中添加'ascii_board_check'字段,画出完整的ASCII棋盘"
                }
            }
        
        # 验证棋盘逻辑
        validation_result = self.validate_board_logic(
            ascii_board=ascii_board,
            expected_winner=expected_winner,
            required_length=required_length
        )
        
        # 生成反思提示
        reflection_prompt = self.generate_reflection_for_agent(
            concept_design=concept_design,
            validation_result=validation_result
        )
        
        # 生成修复建议
        suggested_fixes = {}
        if not validation_result['is_valid']:
            suggested_fixes = {
                "action": "fix_board_logic",
                "errors": validation_result['errors'],
                "reflection": reflection_prompt
            }
        
        return {
            "is_valid": validation_result['is_valid'],
            "validation_result": validation_result,
            "reflection_prompt": reflection_prompt,
            "suggested_fixes": suggested_fixes
        }


# ============================================================================
# 使用示例
# ============================================================================
if __name__ == "__main__":
    validator = BoardValidator()
    
    # 示例1:解析ASCII棋盘
    print("=" * 60)
    print("示例1:解析ASCII棋盘")
    print("=" * 60)
    
    ascii_board = """
      1 2 3 4 5
    1 . . B . .
    2 . . B . .
    3 . W B . .
    4 . . B . .
    5 . . B . .
    """
    
    validation = validator.validate_ascii_board(ascii_board)
    print(f"是否有效: {validation['is_valid']}")
    print(f"棋盘尺寸: {validation['metadata']['rows']}x{validation['metadata']['cols']}")
    print(f"黑子数量: {validation['metadata']['black_count']}")
    print(f"白子数量: {validation['metadata']['white_count']}")
    
    # 示例2:验证获胜逻辑
    print("\n" + "=" * 60)
    print("示例2:验证获胜逻辑")
    print("=" * 60)
    
    logic_validation = validator.validate_board_logic(
        ascii_board=ascii_board,
        expected_winner='B',
        required_length=5
    )
    
    print(f"逻辑是否有效: {logic_validation['is_valid']}")
    print(f"实际获胜方: {logic_validation['actual_winner']}")
    print(f"黑方获胜连线: {logic_validation['black_winning_line']}")
    
    if not logic_validation['is_valid']:
        print("\n反思提示:")
        print(logic_validation['reflection_prompt'])
    
    # 示例3:生成合法位置建议
    print("\n" + "=" * 60)
    print("示例3:生成合法获胜位置")
    print("=" * 60)
    
    positions = validator.suggest_valid_winning_positions(
        board_size=(10, 10),
        required_length=5,
        direction="diagonal"
    )
    print(f"建议的对角线获胜位置: {positions}")
