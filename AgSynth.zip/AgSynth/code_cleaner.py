"""
代码清洗器模块
专门修复模型生成的反斜杠（line continuation）错误
"""
import re
from typing import Optional


def clean_python_code(code: str) -> str:
    """
    清洗 Python 代码，修复常见的反斜杠换行错误
    
    Args:
        code: 原始 Python 代码字符串
        
    Returns:
        清洗后的代码字符串
        
    清洗策略：
    1. 移除反斜杠后的多余空格（最常见的报错原因）
    2. 移除行尾的反斜杠（对于绘图脚本通常是安全的）
    3. 保留字符串内的反斜杠（如 LaTeX 公式）
    """
    if not code or not isinstance(code, str):
        return code
    
    # 策略 1：移除反斜杠后紧跟的空格
    # 将 "\ \n" 或 "\  \n" 替换为 "\\\n"
    code = re.sub(r"\\\s+\n", "\\\n", code)
    
    # 策略 2：移除行尾的反斜杠（暴力但有效）
    # 对于绘图脚本，通常可以安全地移除反斜杠换行
    lines = code.split('\n')
    cleaned_lines = []
    
    for line in lines:
        stripped = line.rstrip()
        
        # 如果行尾是反斜杠，检查是否在字符串内
        if stripped.endswith('\\'):
            # 简单启发式：如果这一行包含引号，可能是字符串内的反斜杠
            # 统计引号数量，如果是奇数，说明字符串未闭合，保留反斜杠
            single_quotes = stripped.count("'") - stripped.count("\\'")
            double_quotes = stripped.count('"') - stripped.count('\\"')
            
            # 如果引号数量是偶数（字符串已闭合），移除反斜杠
            if single_quotes % 2 == 0 and double_quotes % 2 == 0:
                # 移除行尾反斜杠
                cleaned_lines.append(stripped.rstrip('\\').rstrip())
            else:
                # 保留反斜杠（可能在字符串内）
                cleaned_lines.append(line)
        else:
            cleaned_lines.append(line)
    
    return '\n'.join(cleaned_lines)


# 🔧 已移除括号检测和修复逻辑
# 原因：
# 1. LLM 正常输出不会出现括号不匹配问题
# 2. 强制检测反而容易误判，导致代码被破坏
# 3. 依赖 LLM 自身的语法能力，通过重试机制自我修正
#
# 新策略：
# - 完全信任 LLM 的代码生成能力
# - 如果出现语法错误，通过 Python exec() 的异常信息反馈给 LLM
# - 让 LLM 自己修正错误，而不是用正则强制修改


def preprocess_code_before_exec(code: str, verbose: bool = True) -> str:
    """
    在执行前预处理代码（已禁用所有清洗逻辑）

    Args:
        code: 原始代码
        verbose: 是否打印清洗信息

    Returns:
        原始代码（不做任何修改）

    Raises:
        ValueError: 如果清洗后仍有语法错误
    """
    # 🔧 已彻底禁用所有代码清洗逻辑
    # 原因：
    # 1. 反斜杠清洗会破坏字符串内容（如 LaTeX 公式、转义字符）
    # 2. LLM 正常输出不会出现格式问题
    # 3. 强制修改反而容易误判，破坏代码结构
    # 4. 完全信任 LLM 的代码生成能力
    # 5. 如果真的有语法错误，通过 Python exec() 的异常信息反馈给 LLM 自我修正
    #
    # 旧逻辑（已禁用）：
    # cleaned_code = clean_python_code(code)
    # if verbose and cleaned_code != code:
    #     print("   🧹 代码清洗器已自动修复反斜杠换行错误")

    # 新策略：完全不修改代码，直接返回原始代码
    return code


def detect_undefined_variables(code: str) -> list:
    """
    启发式检测未定义变量（简单版本）

    Args:
        code: Python 代码字符串

    Returns:
        可能未定义的变量列表
    """
    # 常见的未定义变量模式（基于历史错误）
    suspicious_patterns = [
        r'\bcode_result\b',
        r'\bdraw_fl\b',
        r'\bresult_data\b',
        r'\btemp_var\b',
        r'\bdata_result\b',
    ]

    undefined_vars = []
    for pattern in suspicious_patterns:
        if re.search(pattern, code):
            var_name = pattern.strip(r'\b')
            # 检查是否有定义语句（简单检测：变量名 = ...）
            if not re.search(rf'{var_name}\s*=', code):
                undefined_vars.append(var_name)

    return undefined_vars


def detect_undefined_functions(code: str) -> list:
    """
    检测可能未定义的函数（增强版）

    Args:
        code: Python 代码字符串

    Returns:
        可能未定义的函数列表
    """
    # matplotlib.patches 类（需要 patches. 前缀）
    patches_classes = ['Rectangle', 'Circle', 'Ellipse', 'Polygon', 'Wedge', 'Arc',
                      'FancyBboxPatch', 'FancyArrowPatch', 'Arrow', 'PathPatch']

    # matplotlib.pyplot 函数（需要 plt. 前缀）
    pyplot_functions = ['subplots', 'subplot', 'figure', 'plot', 'scatter', 'bar',
                       'hist', 'pie', 'imshow', 'text', 'xlabel', 'ylabel', 'title',
                       'legend', 'grid', 'xlim', 'ylim', 'axis', 'tight_layout',
                       'savefig', 'close', 'show']

    undefined_funcs = []

    # 检查 patches 类是否缺少前缀
    for cls in patches_classes:
        # 匹配模式：类名后跟 ( 但前面不是 patches.
        pattern = rf'(?<!patches\.)(?<!\.)\b{cls}\s*\('
        if re.search(pattern, code):
            undefined_funcs.append(cls)

    # 检查 pyplot 函数是否缺少前缀（排除已有 plt. 的情况）
    for func in pyplot_functions:
        # 匹配模式：函数名后跟 ( 但前面不是 plt.
        pattern = rf'(?<!plt\.)(?<!\.)\b{func}\s*\('
        if re.search(pattern, code):
            # 进一步检查是否有 plt. 前缀
            if not re.search(rf'plt\.{func}\s*\(', code):
                undefined_funcs.append(func)

    return undefined_funcs
