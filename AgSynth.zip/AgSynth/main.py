import os
import json
import time
from typing import Any, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

from orchestrator import Orchestrator
from seed_manager import SeedManager

# =====================================================================
# -------------------- Configuration --------------------
# =====================================================================

# Project root directory
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# Input: seed question data
IMAGE_DIR = os.path.join(os.path.dirname(__file__), "..", "images")
SEED_JSON_PATH = os.path.join(os.path.dirname(__file__), "..", "filtered_questions.json")

# Output
OUTPUT_BASE_DIR = os.path.join(os.path.dirname(__file__), "..", "output")
OUTPUT_IMAGE_DIR = os.path.join(OUTPUT_BASE_DIR, "generated_images")
RESULT_JSON_PATH = os.path.join(OUTPUT_BASE_DIR, "generated_questions.jsonl")

GENERATE_COUNT = 50000

# Retry settings
PER_QUESTION_MAX_RETRIES = 2
RETRY_BACKOFF_SECONDS = 2.0

# Concurrency settings
MAX_CONCURRENT_WORKERS = 3

# Reflection logs
MEMORY_LOGS_DIR = os.path.join(OUTPUT_BASE_DIR, "memory_logs")

# Seed state config
SEED_STATE_FILE = os.path.join(OUTPUT_BASE_DIR, "seed_state.json")
UPGRADE_MODEL_FOR_HARD_SEEDS = False
SKIP_HARD_SEEDS = False

# =====================================================================

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def atomic_write_json(path: str, data: Any) -> None:
    """Atomic JSON write to avoid corruption on crash."""
    try:
        ensure_dir(os.path.dirname(path) or ".")
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        os.replace(tmp_path, path)
    except Exception as e:
        print(f"Atomic write failed: {e}")
        # Cleanup temp file
        tmp_path = path + ".tmp"
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except:
                pass
        raise

def append_result_to_json(result_path: str, new_result: Dict[str, Any]) -> None:
    """Append a single result to JSON file (thread-safe with file lock)."""
    import threading
    import time

    # Thread lock for concurrency safety
    lock = threading.Lock()

    with lock:
        # Simple file lock (cross-platform)
        lock_file = result_path + ".lock"
        max_retries = 3
        retry_delay = 0.5

        for attempt in range(max_retries):
            try:
                # Try to acquire lock file
                lock_acquired = False
                for _ in range(10):
                    try:
                        # Exclusive create for lock
                        with open(lock_file, 'x') as lf:
                            lf.write(str(os.getpid()))
                        lock_acquired = True
                        break
                    except FileExistsError:
                        time.sleep(0.5)

                if not lock_acquired:
                    if attempt < max_retries - 1:
                        print(f"Lock busy, retrying...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        print(f"Lock unavailable, proceeding without lock")

                try:
                    # Read existing data
                    existing_data = []
                    if os.path.exists(result_path):
                        try:
                            with open(result_path, "r", encoding="utf-8") as f:
                                existing_data = json.load(f)
                            if not isinstance(existing_data, list):
                                print(f"Result file format error, recreating")
                                existing_data = []
                        except json.JSONDecodeError as e:
                            print(f"JSON parse failed, recreating: {e}")
                            existing_data = []
                        except Exception as e:
                            print(f"Failed to read results, creating new: {e}")
                            existing_data = []

                    # Append new result
                    existing_data.append(new_result)

                    # Atomic write
                    atomic_write_json(result_path, existing_data)

                    print(f"Appended to {os.path.basename(result_path)} (total: {len(existing_data)})")
                    break
                finally:
                    # Release lock file
                    try:
                        if os.path.exists(lock_file):
                            os.remove(lock_file)
                    except:
                        pass
            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"Append failed (attempt {attempt + 1}/{max_retries}): {e}")
                    time.sleep(retry_delay)
                else:
                    print(f"Append failed (all retries exhausted): {e}")
                    raise

def cleanup_intermediate_files(memory_logs_dir: str, question_index: int) -> None:
    """Clean up intermediate files."""
    memory_file = os.path.join(memory_logs_dir, "l1_working", f"memory_generated_question_{question_index}.json")
    cleanup_file(memory_file)

def resolve_image_path(image_dir: str, name_or_path: str) -> str:
    """Resolve image path from filename (with/without extension) or absolute path."""
    if os.path.isabs(name_or_path):
        return name_or_path

    # Has extension: join directly
    if os.path.splitext(name_or_path)[1]:
        return os.path.join(image_dir, name_or_path)

    # No extension: try common ones
    exts = [".png", ".jpg", ".jpeg", ".PNG", ".JPG", ".JPEG"]
    for ext in exts:
        p = os.path.join(image_dir, name_or_path + ext)
        if os.path.exists(p):
            return p

    # Not found: return default .png path
    return os.path.join(image_dir, name_or_path + ".png")

def normalize_solution_steps(value: Any) -> str:
    if isinstance(value, list):
        return "\n".join(str(x) for x in value)
    return "" if value is None else str(value)

def load_seed_questions(json_path: str, image_dir: str) -> List[Dict[str, Any]]:
    """Load seed questions from JSON or JSONL file.

    Supported formats:
    1. JSON: standard array [{"field": "value"}, ...]
    2. JSONL: one JSON object per line

    New format fields:
    - id: unique identifier (also used for image path)
    - question: question text
    - answer: standard answer
    - knowledge-level1/2/3/4: knowledge classification
    - knowledge: knowledge description
    - principle: math principle
    - idx: question index

    Legacy format fields:
    - question_id: unique identifier
    - standard_answer: answer
    - human_sol / solution: solution steps
    - image_path: image filename
    - Name/ID/name: question identifier
    - Revised_Question: question text
    - Revised_Answer: answer
    - Solution steps: solution
    - Image composition: image description
    """
    print(f"Loading seed questions from {json_path}...")

    if not os.path.exists(json_path):
        raise FileNotFoundError(f"Seed file not found: {json_path}")
    if not os.path.isdir(image_dir):
        raise NotADirectoryError(f"Image directory not found: {image_dir}")

    # Auto-detect JSON vs JSONL format
    file_ext = os.path.splitext(json_path)[1].lower()
    is_jsonl = file_ext in ['.jsonl', '.ndjson']

    raw_data = []

    if is_jsonl:
        # JSONL format: one JSON object per line
        print(f"Detected JSONL format, parsing line by line...")
        with open(json_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                    raw_data.append(item)
                except json.JSONDecodeError as e:
                    print(f"Skipping line {line_num}: JSON parse error - {e}")
                    continue
    else:
        # Standard JSON array format
        print(f"Detected JSON array format, parsing...")
        with open(json_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)

        if not isinstance(raw_data, list):
            raise ValueError("Seed JSON top-level must be an array.")

    seed_questions: List[Dict[str, Any]] = []
    for idx, item in enumerate(raw_data, 1):
        if not isinstance(item, dict):
            print(f"Skipping entry {idx}: not a dict.")
            continue

        # Smart field mapping: prefer new format, fallback to legacy

        # 1. Question ID
        #    New: id field
        #    Legacy: question_id / Name/ID / Name / ID / name
        raw_id = (item.get("id") or
                  item.get("question_id") or
                  item.get("Name/ID") or item.get("Name") or item.get("ID") or
                  item.get("name") or f"question_{idx}")
        name_id = str(raw_id)

        # 2. Image path
        #    New: {id}.png
        #    Legacy: image_path / Name/ID / Name / ID / name
        if item.get("id") is not None and not item.get("image_path"):
            # New format: construct {id}.png from id field
            image_filename = f"{item['id']}.png"
        else:
            # Legacy: use image_path or identifier field directly
            image_filename = (item.get("image_path") or
                             item.get("Name/ID") or item.get("Name") or item.get("ID") or
                             item.get("name") or name_id)
        image_path = resolve_image_path(image_dir, str(image_filename))

        # 3. Question text
        #    New: question
        #    Legacy: Revised_Question / revised_question
        question_text = (item.get("question") or
                        item.get("Revised_Question") or item.get("revised_question") or "")

        # 4. Answer
        #    New: answer
        #    Legacy: standard_answer / Revised_Answer / revised_answer
        answer_text = (item.get("answer") or
                      item.get("standard_answer") or
                      item.get("Revised_Answer") or item.get("revised_answer") or "")

        # 5. Solution steps
        #    New: knowledge/principle as reference
        #    Legacy: human_sol / solution / Solution steps
        solution_steps = (item.get("human_sol") or
                         item.get("solution") or
                         item.get("Solution steps") or item.get("solution_steps") or "")
        solution_steps = normalize_solution_steps(solution_steps)

        # 6. Image composition
        #    New: not available
        #    Legacy: Image composition / image_composition
        image_composition = (item.get("Image composition") or item.get("image_composition") or
                            item.get("Image Composition") or "(Not provided)")

        # 7. Extra metadata (knowledge classification)
        knowledge_level1 = item.get("knowledge-level1") or ""
        knowledge_level2 = item.get("knowledge-level2") or ""
        knowledge_level3 = item.get("knowledge-level3") or ""
        knowledge_level4 = item.get("knowledge-level4") or ""
        knowledge = item.get("knowledge") or ""
        principle = item.get("principle") or ""
        item_idx = item.get("idx") or ""

        # Build unified seed data structure
        seed_questions.append({
            "id": idx,
            "name": name_id,
            "image": image_path,
            "question": question_text,
            "answer": answer_text,
            "solution_steps": solution_steps,
            "image_composition": image_composition,
            # Extra fields from new format (knowledge classification)
            "knowledge_level1": knowledge_level1,
            "knowledge_level2": knowledge_level2,
            "knowledge_level3": knowledge_level3,
            "knowledge_level4": knowledge_level4,
            "knowledge": knowledge,
            "principle": principle,
            "item_idx": item_idx,
        })

    print(f"Loaded {len(seed_questions)} seed questions (format: {'JSONL' if is_jsonl else 'JSON'})")
    return seed_questions

def cleanup_file(path: str) -> None:
    if os.path.exists(path):
        try:
            os.remove(path)
            print(f"Cleaned up: {os.path.basename(path)}")
        except OSError as e:
            print(f"Cleanup failed: {e}")

def get_next_available_index(output_image_dir: str) -> int:
    """Scan output dir to find next available image index."""
    if not os.path.exists(output_image_dir):
        return 1

    existing_indices = []
    for filename in os.listdir(output_image_dir):
        if filename.startswith("generated_question_") and filename.endswith(".png"):
            try:
                # Extract index from filename
                index_str = filename.replace("generated_question_", "").replace(".png", "")
                index = int(index_str)
                existing_indices.append(index)
            except ValueError:
                continue

    if not existing_indices:
        return 1

    # Return max index + 1
    return max(existing_indices) + 1

def run_one_question(
    i: int,
    seed_questions: List[Dict[str, Any]],
    output_image_dir: str,
    image_name: str,
    difficulty: str,
    result_json_path: str,
    enhancement_prompts: dict,
    memory_logs_dir: str = None,
    seed_manager: Optional['SeedManager'] = None,
) -> Optional[Dict[str, Any]]:
    """Generate a single question. Exceptions propagate for retry.

    - Appends result to JSON immediately on success
    - Uses lightweight reflection for error learning
    """
    print(f"\n{'='*55}")
    print(f"Generating question #{i}")
    print(f"{'='*55}")

    # Single-seed strategy: force model to learn core logic
    
    # Initialize seed manager if not provided
    if seed_manager is None:
        target_per_seed = max(1, GENERATE_COUNT // len(seed_questions))
        seed_manager = SeedManager(state_file=SEED_STATE_FILE, target_count_per_seed=target_per_seed)

    # Select next seed based on quota
    selected_seed = seed_manager.get_next_seed_to_generate(seed_questions)

    if selected_seed is None:
        print(f"All seeds reached target quota")
        print(f"Skipping question #{i}")
        return None

    # Pass only this 1 seed to the model
    single_seed = [selected_seed]

    # Get current seed progress
    seed_id = seed_manager.get_seed_id(selected_seed)
    current_success = seed_manager.seed_states.get(seed_id, {}).get("success_count", 0)
    target_per_seed = seed_manager.target_count_per_seed

    print(f"Selected seed: ID={seed_id}")
    print(f"Progress: {current_success}/{target_per_seed}")
    
    # Define question_id for reflection
    question_id = f"question_{i}"

    # Check if hard seed (3+ consecutive failures)
    is_hard_seed = seed_manager.is_hard_seed(selected_seed)

    if is_hard_seed:
        consecutive_failures = seed_manager.get_consecutive_failures(selected_seed)
        print(f"Warning: Hard seed ({consecutive_failures} consecutive failures)")

        if UPGRADE_MODEL_FOR_HARD_SEEDS:
            print(f"Using enhanced mode for hard seed")

    # Show seed stats
    stats = seed_manager.get_seed_stats(selected_seed)
    print(f"Seed stats: attempts={stats['total_attempts']}, success={stats['success_count']}, rate={stats['success_rate']:.1%}")

    # Use enhanced mode for hard seeds
    use_advanced = UPGRADE_MODEL_FOR_HARD_SEEDS and is_hard_seed
    orch = Orchestrator(
        enhancement_prompts=enhancement_prompts,
        use_advanced_model=use_advanced,
        question_id=question_id
    )

    try:
        result = orch.run(
            single_seed,
            output_image_dir,
            image_filename=image_name,
            difficulty=difficulty,
            memory_logs_dir=memory_logs_dir
        )

        # Success: record in seed manager
        seed_manager.record_success(selected_seed)
        print(f"Seed '{seed_manager.get_seed_id(selected_seed)}' succeeded")

    except Exception as e:
        # Failure: record in seed manager
        failure_reason = str(e)[:200]
        seed_manager.record_failure(selected_seed, failure_reason)
        print(f"Seed '{seed_manager.get_seed_id(selected_seed)}' failed")

        raise

    # Extract fields from orchestrator result
    design_detail = result.get("design_detail", {})
    qa_result = result.get("qa_result", {})
    quality_score = result.get("quality_score", 0)

    # Extract image description
    simple_desc = qa_result.get("simple_image_description", "")
    if simple_desc:
        image_composition = simple_desc
    else:
        # Fallback to design spec if not available
        image_design = design_detail.get("image_design", "")
        if isinstance(image_design, dict):
            image_composition = image_design.get("description", "")
        else:
            image_composition = str(image_design) if image_design else ""

    # Extract seed image filename for traceability
    seed_image_filename = os.path.basename(selected_seed.get("image", ""))

    # Build final result dict
    formatted_result = {
        "Name/ID": image_name.replace(".png", ""),
        "Revised_Question": qa_result.get("question_text") or qa_result.get("question") or "",
        "Image composition": image_composition,
        "Solution steps": qa_result.get("solution_steps", []) if isinstance(qa_result.get("solution_steps"), list) else qa_result.get("solution_steps", "").split("\n"),
        "Difficulty level": difficulty,
        "Revised_Answer": qa_result.get("answer_text") or qa_result.get("answer") or "",
        "Quality rating": str(quality_score),
        "Seed_Image": seed_image_filename,
    }

    # Incremental save: append to result file immediately
    try:
        append_result_to_json(result_json_path, formatted_result)
        print(f"Question #{i} saved")
    except Exception as e:
        print(f"Failed to save question #{i}: {e}")
        # Return result even if save failed

    # Return in legacy format for compatibility
    return {
        "image_name": image_name,
        "question": qa_result.get("question_text", ""),
        "answer": qa_result.get("answer_text", ""),
        "explanation": "\n".join(qa_result.get("solution_steps", [])) if isinstance(qa_result.get("solution_steps"), list) else str(qa_result.get("solution_steps", "")),
        "image_composition": image_composition,
        "difficulty": difficulty,
        "quality_rating": quality_score,
    }

def run_one_question_with_retry(
    i: int,
    seed_questions: List[Dict[str, Any]],
    output_image_dir: str,
    image_name: str,
    difficulty: str,
    result_json_path: str,
    enhancement_prompts: dict,
    memory_logs_dir: str = None,
    max_retries: int = 1,
    seed_manager: Optional['SeedManager'] = None,
) -> Optional[Dict[str, Any]]:
    """Generate single question with retries (for concurrent execution)."""
    last_err: Optional[Exception] = None

    for attempt in range(1, max_retries + 2):
        try:
            result = run_one_question(
                i=i,
                seed_questions=seed_questions,
                output_image_dir=output_image_dir,
                image_name=image_name,
                difficulty=difficulty,
                result_json_path=result_json_path,
                enhancement_prompts=enhancement_prompts,
                memory_logs_dir=memory_logs_dir,
                seed_manager=seed_manager,
            )
            return result
        except Exception as e:
            last_err = e
            if attempt < max_retries + 1:
                print(f"Question #{i} failed (attempt {attempt}/{max_retries + 1}): {e}")
                print(f"Retrying in {RETRY_BACKOFF_SECONDS}s...")
                time.sleep(RETRY_BACKOFF_SECONDS)
            else:
                print(f"Question #{i} failed after {max_retries + 1} attempts: {e}")
                # Delete failed question's image file
                image_full_path = os.path.join(output_image_dir, image_name)
                if os.path.exists(image_full_path):
                    try:
                        os.remove(image_full_path)
                        print(f"Deleted failed image: {image_name}")
                    except Exception as cleanup_err:
                        print(f"Image cleanup error: {cleanup_err}")
                return None

    return None

def main() -> None:
    print("Starting multi-agent question generation pipeline...")
    print("-" * 50)
    print(f"Image dir: {IMAGE_DIR}")
    print(f"Seed JSON: {SEED_JSON_PATH}")
    print(f"Output images: {OUTPUT_IMAGE_DIR}")
    print(f"Output JSONL: {RESULT_JSON_PATH}")
    
    print("-" * 50)

    # Create output directories
    ensure_dir(OUTPUT_IMAGE_DIR)

    # Create reflection log directories
    ensure_dir(MEMORY_LOGS_DIR)
    ensure_dir(os.path.join(MEMORY_LOGS_DIR, "l1_working"))

    print("-" * 50)

    # Initialize enhancement prompts (empty)
    enhancement_prompts = {
        "concept_designer": "",
        "visual_specifier": "",
        "painter": "",
        "qa_generator": ""
    }

    print("\n" + "="*60)
    print("Starting generation...")
    print("="*60 + "\n")

    # === Load seed questions ===
    seed_questions = load_seed_questions(SEED_JSON_PATH, IMAGE_DIR)

    # === Initialize seed manager ===
    print("\n" + "="*60)
    print("Initializing seed quota manager...")
    print("="*60)

    # Calculate target per seed
    target_per_seed = max(1, GENERATE_COUNT // len(seed_questions))
    seed_manager = SeedManager(state_file=SEED_STATE_FILE, target_count_per_seed=target_per_seed)

    print(f"Target per seed: {target_per_seed}")
    print(f"Total target: {len(seed_questions)} seeds x {target_per_seed} = {len(seed_questions) * target_per_seed}")

    # Show seed manager stats
    all_stats = seed_manager.get_all_stats()
    print(f"Seed manager initialized")
    print(f"  Total seeds: {all_stats['total_seeds']}")
    print(f"   - Hard Seeds: {all_stats['hard_seeds']}")
    print(f"  Normal seeds: {all_stats['normal_seeds']}")
    print(f"  Total attempts: {all_stats['total_attempts']}")
    print(f"  Total successes: {all_stats['total_successes']}")
    print(f"  Success rate: {all_stats['overall_success_rate']:.1%}")

    if all_stats['hard_seed_list']:
        print(f"  Hard seeds: {', '.join(all_stats['hard_seed_list'])}")

    # Filter out hard seeds if enabled
    if SKIP_HARD_SEEDS:
        print(f"\nFiltering hard seeds...")
        original_count = len(seed_questions)
        seed_questions = seed_manager.filter_seeds(seed_questions, skip_hard_seeds=True)
        filtered_count = original_count - len(seed_questions)

        if filtered_count > 0:
            print(f"Filtered {filtered_count} hard seeds")
            print(f"Available seeds: {len(seed_questions)}/{original_count}")
        else:
            print(f"All seeds available (no hard seeds)")
    else:
        print(f"\nUsing all seeds (no filtering)")
        print(f"Available seeds: {len(seed_questions)}")

    # Resume logic: scan for existing images to avoid overwrite
    print("\nScanning output directory...")
    next_available_index = get_next_available_index(OUTPUT_IMAGE_DIR)

    # Count existing results in JSON file
    existing_json_count = 0
    if os.path.exists(RESULT_JSON_PATH):
        try:
            with open(RESULT_JSON_PATH, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if isinstance(existing, list):
                existing_json_count = len(existing)
        except Exception as e:
            print(f"Failed to read existing results: {e}")

    print(f"Next available index: {next_available_index}")
    print(f"Existing results in JSON: {existing_json_count}")

    # Check if generation is needed
    if GENERATE_COUNT < next_available_index:
        print(f"\nTarget reached ({next_available_index - 1} >= {GENERATE_COUNT}). No generation needed.")
        print(f"Increase GENERATE_COUNT (currently {GENERATE_COUNT}) to generate more.")
        return

    # Start from next available index
    start_index = next_available_index
    target_end = GENERATE_COUNT

    # Prepare generation list
    questions_to_generate = list(range(start_index, target_end + 1))

    # Show current progress
    progress = seed_manager.get_generation_progress(seed_questions)
    print(f"\nCurrent progress:")
    print(f"  Target: {progress['total_target']}")
    print(f"  Generated: {progress['total_generated']}")
    print(f"  Progress: {progress['progress_percentage']:.1f}%")
    print(f"  Completed seeds: {progress['completed_seeds']}/{progress['total_seeds']}")

    print(f"\nStarting concurrent execution (workers={MAX_CONCURRENT_WORKERS})")
    print(f"Queue: {len(questions_to_generate)} questions (#{start_index} - #{target_end})\n")

    # Thread pool execution
    with ThreadPoolExecutor(max_workers=MAX_CONCURRENT_WORKERS) as executor:
        # Submit all tasks
        future_to_index = {}
        for i in questions_to_generate:
            image_name = f"generated_question_{i}.png"
            future = executor.submit(
                run_one_question_with_retry,
                i=i,
                seed_questions=seed_questions,
                output_image_dir=OUTPUT_IMAGE_DIR,
                image_name=image_name,
                difficulty="easy",
                result_json_path=RESULT_JSON_PATH,
                enhancement_prompts=enhancement_prompts,
                memory_logs_dir=MEMORY_LOGS_DIR,
                max_retries=PER_QUESTION_MAX_RETRIES,
                seed_manager=seed_manager,
            )
            future_to_index[future] = i

        # Collect results as they complete
        completed_count = 0
        failed_count = 0

        for future in as_completed(future_to_index):
            i = future_to_index[future]
            try:
                result = future.result()
                if result is None:
                    # All seeds reached quota
                    print(f"Question #{i} skipped (all seeds at quota)")
                    continue
                elif result:
                    completed_count += 1
                    print(f"Question #{i} done ({completed_count}/{len(questions_to_generate)})")

                    # Real-time progress
                    progress = seed_manager.get_generation_progress(seed_questions)
                    print(f"Progress: {progress['total_generated']}/{progress['total_target']} ({progress['progress_percentage']:.1f}%)")
                else:
                    failed_count += 1
                    print(f"Question #{i} failed (all retries exhausted)")
            except Exception as e:
                failed_count += 1
                print(f"Question #{i} error: {e}")

    # Final statistics
    print(f"\n{'='*55}")
    print(f"Execution complete")
    print(f"{'='*55}")
    print(f"Succeeded: {completed_count}")
    print(f"Failed: {failed_count}")

    # Read final count from JSON
    try:
        with open(RESULT_JSON_PATH, "r", encoding="utf-8") as f:
            final_data = json.load(f)
        total_count = len(final_data) if isinstance(final_data, list) else 0
        print(f"Total in output file: {total_count}")
    except Exception as e:
        print(f"Failed to read output file: {e}")

    # === Final progress ===
    print("\n" + "="*60)
    print("Final progress:")
    print("="*60)

    final_progress = seed_manager.get_generation_progress(seed_questions)
    print(f"\nOverall:")
    print(f"  Target: {final_progress['total_target']}")
    print(f"  Generated: {final_progress['total_generated']}")
    print(f"  Progress: {final_progress['progress_percentage']:.1f}%")
    print(f"  Completed seeds: {final_progress['completed_seeds']}/{final_progress['total_seeds']}")

    print(f"\nPer-seed progress:")
    for seed_info in final_progress['seed_progress']:
        status = "✅" if seed_info['completed'] else "⏳"
        print(f"   {status} {seed_info['seed_id']}: {seed_info['progress']}")

    # === Export seed report ===
    print("\n" + "="*60)
    print("Exporting seed analysis report...")
    print("="*60)

    seed_report_path = os.path.join(MEMORY_LOGS_DIR, "seed_report.json")
    try:
        seed_manager.export_report(seed_report_path)
        print(f"Seed report exported")

        # Key statistics
        final_seed_stats = seed_manager.get_all_stats()
        print(f"\nFinal seed stats:")
        print(f"  Total seeds: {final_seed_stats['total_seeds']}")
        print(f"   - Hard Seeds: {final_seed_stats['hard_seeds']}")
        print(f"  Normal seeds: {final_seed_stats['normal_seeds']}")
        print(f"  Success rate: {final_seed_stats['overall_success_rate']:.1%}")

        if final_seed_stats['hard_seed_list']:
            print(f"  Hard seeds: {', '.join(final_seed_stats['hard_seed_list'])}")
    except Exception as e:
        print(f"Failed to export seed report: {e}")

    print("="*60)

    print("\n" + "=" * 55)
    print(f"Generation complete!")
    print(f"Results saved to: {RESULT_JSON_PATH}")
    
    print("=" * 55)

if __name__ == "__main__":
    main()
