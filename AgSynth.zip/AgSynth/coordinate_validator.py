"""
coordinate_validator.py
坐标验证器 - 解决问题 A（逻辑一致性）和问题 B（几何布局）

核心功能：
1. 验证棋盘类题目的坐标逻辑正确性（五子棋、井字棋等）
2. 验证画布边界约束（防止元素超出边界或重叠）
3. 提供自动修复建议
"""
from typing import Dict, Any, List, Tuple, Optional
import re


class CoordinateValidator:
    """坐标验证器 - 数学规则验证"""
    
    def __init__(self, canvas_width: float = 12.0, canvas_height: float = 12.0):
        """
        初始化验证器
        
        Args:
            canvas_width: 画布宽度（默认 12）
            canvas_height: 画布高度（默认 12）
        """
        self.canvas_width = canvas_width
        self.canvas_height = canvas_height
    
    # ========================================================================
    # 问题 A：棋盘逻辑验证（五子棋、井字棋等）
    # ========================================================================
    
    def validate_board_game_logic(
        self,
        concept_design: dict,
        board_size: Tuple[int, int] = (15, 15)
    ) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """
        验证棋盘类游戏的逻辑正确性
        
        检查项：
        1. 坐标是否在棋盘范围内
        2. 是否存在重复坐标
        3. 获胜路径是否真的能连成线
        4. 候选选项是否真的不能获胜
        
        Args:
            concept_design: ConceptDesigner 的输出
            board_size: 棋盘大小 (rows, cols)
        
        Returns:
            (is_valid, error_message, fix_suggestions)
        """
        # 提取棋盘相关数据
        data_specs = concept_design.get('concept_design', {}).get('data_specifications', '')
        
        # 检测是否为棋盘类题目
        if not self._is_board_game(concept_design):
            return True, None, None  # 不是棋盘题，跳过验证
        
        # 提取坐标数据
        coordinates = self._extract_coordinates(data_specs)
        if not coordinates:
            return True, None, None  # 没有坐标数据，跳过验证
        
        # 验证 1：坐标范围检查
        out_of_bounds = []
        for coord_name, (x, y) in coordinates.items():
            if not (0 <= x < board_size[0] and 0 <= y < board_size[1]):
                out_of_bounds.append(f"{coord_name}: ({x}, {y}) 超出棋盘范围 {board_size}")
        
        if out_of_bounds:
            error_msg = "坐标超出棋盘范围：\n" + "\n".join(out_of_bounds)
            fix_suggestions = {
                "action": "adjust_coordinates",
                "out_of_bounds": out_of_bounds,
                "board_size": board_size
            }
            return False, error_msg, fix_suggestions
        
        # 验证 2：重复坐标检查
        coord_values = list(coordinates.values())
        duplicates = []
        for i, coord1 in enumerate(coord_values):
            for j, coord2 in enumerate(coord_values[i+1:], i+1):
                if coord1 == coord2:
                    names = [k for k, v in coordinates.items() if v == coord1]
                    duplicates.append(f"坐标 {coord1} 重复出现在：{', '.join(names)}")
        
        if duplicates:
            error_msg = "检测到重复坐标：\n" + "\n".join(duplicates)
            fix_suggestions = {
                "action": "remove_duplicates",
                "duplicates": duplicates
            }
            return False, error_msg, fix_suggestions
        
        # 验证 3：连线逻辑检查（五子棋）
        if "五子棋" in str(concept_design) or "连珠" in str(concept_design):
            winning_path = self._extract_winning_path(data_specs)
            if winning_path and len(winning_path) >= 5:
                if not self._check_line_connection(winning_path, required_length=5):
                    error_msg = "获胜路径无法连成5子：坐标不在同一直线上"
                    fix_suggestions = {
                        "action": "fix_winning_path",
                        "current_path": winning_path,
                        "issue": "not_aligned"
                    }
                    return False, error_msg, fix_suggestions
        
        return True, None, None
    
    def _is_board_game(self, concept_design: dict) -> bool:
        """判断是否为棋盘类题目"""
        keywords = ["棋盘", "五子棋", "井字棋", "围棋", "象棋", "chess", "board", "grid"]
        content = str(concept_design).lower()
        return any(kw in content for kw in keywords)
    
    def _extract_coordinates(self, data_specs: str) -> Dict[str, Tuple[int, int]]:
        """从数据规格中提取坐标"""
        coordinates = {}
        
        # 匹配模式：(x, y) 或 [x, y] 或 x,y
        patterns = [
            r'(\w+)[:\s]*\((\d+),\s*(\d+)\)',  # name: (x, y)
            r'(\w+)[:\s]*\[(\d+),\s*(\d+)\]',  # name: [x, y]
            r'(\w+)[:\s]*(\d+),\s*(\d+)',      # name: x, y
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, data_specs)
            for match in matches:
                if len(match) == 3:
                    name, x, y = match
                    coordinates[name] = (int(x), int(y))
        
        return coordinates
    
    def _extract_winning_path(self, data_specs: str) -> List[Tuple[int, int]]:
        """提取获胜路径坐标"""
        # 简化实现：提取所有坐标，假设前5个是获胜路径
        coordinates = self._extract_coordinates(data_specs)
        return list(coordinates.values())[:5] if len(coordinates) >= 5 else []
    
    def _check_line_connection(
        self,
        coordinates: List[Tuple[int, int]],
        required_length: int = 5
    ) -> bool:
        """检查坐标是否能连成一条直线"""
        if len(coordinates) < required_length:
            return False
        
        # 检查是否在同一行、列或对角线
        xs = [c[0] for c in coordinates[:required_length]]
        ys = [c[1] for c in coordinates[:required_length]]
        
        # 同一行
        if len(set(xs)) == 1:
            return self._check_consecutive(ys)
        
        # 同一列
        if len(set(ys)) == 1:
            return self._check_consecutive(xs)
        
        # 对角线（斜率为 1 或 -1）
        if len(set(xs)) == required_length and len(set(ys)) == required_length:
            # 检查是否为对角线
            sorted_coords = sorted(coordinates[:required_length])
            diffs = [(sorted_coords[i+1][0] - sorted_coords[i][0],
                     sorted_coords[i+1][1] - sorted_coords[i][1])
                    for i in range(required_length - 1)]
            
            # 所有差值应该相同（1,1）或（1,-1）
            return len(set(diffs)) == 1 and diffs[0] in [(1, 1), (1, -1)]
        
        return False
    
    def _check_consecutive(self, values: List[int]) -> bool:
        """检查数值是否连续"""
        sorted_values = sorted(values)
        return all(sorted_values[i+1] - sorted_values[i] == 1
                  for i in range(len(sorted_values) - 1))
    
    # ========================================================================
    # 问题 B：画布边界验证
    # ========================================================================
    
    def validate_canvas_layout(
        self,
        visual_spec: dict,
        min_margin: float = 0.3,  # 放宽标准：从 0.6 降到 0.3
        min_spacing: float = 0.2   # 放宽标准：从 0.5 降到 0.2
    ) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """
        验证画布布局的合理性
        
        检查项：
        1. 元素是否超出画布边界（考虑元素尺寸）
        2. 元素之间是否有足够间距
        3. 标注是否会遮挡图形
        
        Args:
            visual_spec: VisualSpecifier 的输出
            min_margin: 最小边距（放宽到 0.5）
            min_spacing: 最小间距（放宽到 0.4）
        
        Returns:
            (is_valid, error_message, fix_suggestions)
        """
        # 提取坐标和尺寸信息
        spec_text = str(visual_spec.get('detailed_image_specification', ''))
        data_values = visual_spec.get('data_values', {})
        
        # 提取所有坐标
        elements = self._extract_element_positions(spec_text, data_values)
        if not elements:
            return True, None, None  # 没有坐标信息，跳过验证
        
        # 验证 1：边界检查（放宽标准）
        out_of_bounds = []
        for elem in elements:
            name = elem['name']
            x, y = elem['position']
            size = elem.get('size', 0.3)  # 默认元素半径 0.3
            
            # 检查是否超出边界（考虑元素尺寸）
            if x - size < min_margin or x + size > self.canvas_width - min_margin:
                out_of_bounds.append(f"{name} at ({x:.2f}, {y:.2f}): X 坐标距离边界过近")
            
            if y - size < min_margin or y + size > self.canvas_height - min_margin:
                out_of_bounds.append(f"{name} at ({x:.2f}, {y:.2f}): Y 坐标距离边界过近")
        
        # 🎯 放宽标准：只有严重超出边界才拦截
        critical_violations = [v for v in out_of_bounds if "过近" in v and 
                              (any(coord < 0.3 or coord > self.canvas_width - 0.3 
                                   for coord in [x, y]))]
        
        if critical_violations:
            error_msg = "严重边界违规（元素几乎贴边或超出）：\n" + "\n".join(critical_violations)
            fix_suggestions = {
                "action": "adjust_positions",
                "violations": critical_violations,
                "min_margin": min_margin,
                "canvas_size": (self.canvas_width, self.canvas_height)
            }
            return False, error_msg, fix_suggestions
        
        # 验证 2：间距检查（放宽标准）
        overlaps = []
        for i, elem1 in enumerate(elements):
            for elem2 in elements[i+1:]:
                distance = self._calculate_distance(
                    elem1['position'],
                    elem2['position']
                )
                
                required_spacing = elem1.get('size', 0.3) + elem2.get('size', 0.3) + min_spacing
                
                # 🎯 放宽标准：只有严重重叠才拦截
                if distance < required_spacing * 0.7:  # 允许 30% 的间距不足
                    overlaps.append(
                        f"{elem1['name']} 和 {elem2['name']} 间距过小：{distance:.2f} < {required_spacing:.2f}"
                    )
        
        if overlaps:
            error_msg = "严重元素重叠：\n" + "\n".join(overlaps)
            fix_suggestions = {
                "action": "increase_spacing",
                "overlaps": overlaps,
                "min_spacing": min_spacing
            }
            return False, error_msg, fix_suggestions
        
        return True, None, None
    
    def _extract_element_positions(
        self,
        spec_text: str,
        data_values: dict
    ) -> List[Dict[str, Any]]:
        """从规格说明中提取元素位置"""
        elements = []
        
        # 匹配坐标模式
        patterns = [
            r'(\w+)\s+at\s+\(([0-9.]+),\s*([0-9.]+)\)',
            r'position[:\s]+\(([0-9.]+),\s*([0-9.]+)\)',
            r'coordinate[:\s]+\(([0-9.]+),\s*([0-9.]+)\)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, spec_text, re.IGNORECASE)
            for match in matches:
                if len(match) == 3:
                    name, x, y = match
                    elements.append({
                        'name': name,
                        'position': (float(x), float(y)),
                        'size': 0.3  # 默认尺寸
                    })
                elif len(match) == 2:
                    x, y = match
                    elements.append({
                        'name': f'Element_{len(elements)}',
                        'position': (float(x), float(y)),
                        'size': 0.3
                    })
        
        return elements
    
    def _calculate_distance(
        self,
        pos1: Tuple[float, float],
        pos2: Tuple[float, float]
    ) -> float:
        """计算两点之间的欧几里得距离"""
        return ((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)**0.5
    
    # ========================================================================
    # 通用验证接口
    # ========================================================================
    
    def validate_all(
        self,
        concept_design: dict,
        visual_spec: dict
    ) -> Tuple[bool, List[str], Dict[str, Any]]:
        """
        执行所有验证
        
        Returns:
            (all_valid, error_messages, all_fix_suggestions)
        """
        errors = []
        fixes = {}
        
        # 验证 1：棋盘逻辑
        valid1, error1, fix1 = self.validate_board_game_logic(concept_design)
        if not valid1:
            errors.append(f"[棋盘逻辑] {error1}")
            if fix1:
                fixes['board_logic'] = fix1
        
        # 验证 2：画布布局
        valid2, error2, fix2 = self.validate_canvas_layout(visual_spec)
        if not valid2:
            errors.append(f"[画布布局] {error2}")
            if fix2:
                fixes['canvas_layout'] = fix2
        
        all_valid = valid1 and valid2
        return all_valid, errors, fixes
