"""查找所有文件中涉及 DIFFICULTY / difficulty 的代码"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
keywords = ["DIFFICULTY", "difficulty", "Difficulty"]

for fname in sorted(os.listdir(BASE_DIR)):
    if not fname.endswith((".py", ".md")) or fname.startswith("_"):
        continue
    fpath = os.path.join(BASE_DIR, fname)
    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f, 1):
            for kw in keywords:
                if kw in line:
                    print(f"[{fname}] L{i}: {line.rstrip()[:120]}")
                    break

os.remove(os.path.abspath(__file__))
